// ============================================================================
// env.ts — Centralized, validated environment configuration.
//
// The app runs in two environments, both driven by the same `.env` file:
//   1. Localhost development  — `bun run dev`  (NODE_ENV=development)
//   2. Intranet production     — `bun run start` (NODE_ENV=production)
//
// Both use a SQLite file database (`file:...`) and a persistent filesystem,
// so the SAME three variables configure either environment — only the VALUES
// differ between `.env` on your laptop and `.env` on the intranet server.
//
// This module:
//   1. Validates every required variable at startup (fail-fast with a clear
//      message — no silent fallbacks that would make tokens forgeable).
//   2. Provides a single typed source of truth (`env` object).
//   3. Documents each variable inline.
//
// See `.env.example` for a copy-paste template and `DEPLOYMENT.md` for the
// full setup guide for both environments.
// ============================================================================

import path from "path";

type EnvShape = {
  /** SQLite connection string. Always `file:<path>` for both dev and prod. */
  DATABASE_URL: string;
  /** Secret (≥16 chars) used to sign JWT session tokens (HS256). */
  NEXTAUTH_SECRET: string;
  /** Canonical public URL of the deployed app (no trailing slash). */
  NEXTAUTH_URL: string;
  /** Node environment — "development" | "production" | "test". Set by Next.js. */
  NODE_ENV: string;
  /**
   * Absolute path to the upload directory for applicant documents.
   * Defaults to `<project-root>/upload`. Set this on the intranet server if
   * uploads should live on a separate volume (e.g. a mounted NFS share).
   */
  UPLOAD_DIR: string;
  // ── AI / Document Intelligence ──────────────────────────────────────────
  /** API key for the AI provider (NVIDIA, OpenAI-compatible). Required for PDS auto-extract. */
  AI_API_KEY: string;
  /** Base URL of the OpenAI-compatible AI API. Default: NVIDIA integrate endpoint. */
  AI_BASE_URL: string;
  /** Chat/instruct model for structuring extracted text into JSON. */
  AI_TEXT_MODEL: string;
  /** Vision/OCR model for extracting text from images. */
  AI_VISION_MODEL: string;
  // ── Two-tier access control (public web vs intranet staff) ─────────────
  /**
   * "on" (default) — ADMIN/EVALUATOR logins, sessions and APIs only work
   * from intranet IPs; applicants work from any network. "off" disables all
   * tier checks (emergency recovery switch). See src/lib/access-tier.ts.
   */
  INTRANET_ENFORCEMENT: string;
  /**
   * Comma-separated extra IPv4 CIDRs always treated as intranet (allowlist
   * for an office egress IP behind NAT or an admin VPN range).
   * Example: INTRANET_CIDRS=203.0.113.7/32,198.51.100.0/24
   */
  INTRANET_CIDRS: string;
  // ── Email delivery (applicant/evaluator notices) ───────────────────────
  /**
   * "mock" (default) — every send is only recorded to the email_logs ledger,
   * nothing is delivered. "resend" — delivers via the Resend HTTP API.
   * "middleware" — delivers via the office mirdc_middleware VM gateway.
   * MUST be "middleware" or "resend" in production or notices will
   * silently not send.
   */
  EMAIL_PROVIDER: string;
  /** Resend API key (required when EMAIL_PROVIDER=resend). */
  RESEND_API_KEY: string;
  /** Verified From address for outgoing email, e.g. "RMIS <no-reply@mirdc.gov.ph>". */
  EMAIL_FROM: string;
  /** Base URL of the office mirdc_middleware email gateway (required when
   *  EMAIL_PROVIDER=middleware), e.g. "http://10.10.x.x:3232" — no trailing slash. */
  EMAIL_MIDDLEWARE_URL: string;
  /** Shared middleware token sent as body.api (required when EMAIL_PROVIDER=middleware;
   *  enforced by the VM only when it sets MIDDLEWARE_API_KEY). */
  EMAIL_MIDDLEWARE_API_KEY: string;
  /** From display name at the middleware, e.g. "DOST-MIRDC Recruitment". */
  EMAIL_MIDDLEWARE_SYSTEM: string;
};

const REQUIRED: ReadonlyArray<keyof EnvShape> = [
  "DATABASE_URL",
  "NEXTAUTH_SECRET",
  "NEXTAUTH_URL",
];

function readEnv(): EnvShape {
  const rawUrl = (process.env.NEXTAUTH_URL ?? "").replace(/\/+$/, "");

  const env: EnvShape = {
    DATABASE_URL: process.env.DATABASE_URL ?? "",
    NEXTAUTH_SECRET: process.env.NEXTAUTH_SECRET ?? "",
    NEXTAUTH_URL: rawUrl,
    NODE_ENV: process.env.NODE_ENV ?? "development",
    UPLOAD_DIR: process.env.UPLOAD_DIR ?? "",
    AI_API_KEY: process.env.AI_API_KEY ?? "",
    AI_BASE_URL: (process.env.AI_BASE_URL ?? "https://integrate.api.nvidia.com/v1").replace(/\/+$/, ""),
    AI_TEXT_MODEL: process.env.AI_TEXT_MODEL ?? "nvidia/llama-3.3-nemotron-super-49b-v1",
    AI_VISION_MODEL: process.env.AI_VISION_MODEL ?? "nvidia/nemotron-nano-12b-v2-vl",
    INTRANET_ENFORCEMENT: (process.env.INTRANET_ENFORCEMENT ?? "on").trim().toLowerCase(),
    INTRANET_CIDRS: process.env.INTRANET_CIDRS ?? "",
    EMAIL_PROVIDER: (process.env.EMAIL_PROVIDER ?? "mock").trim().toLowerCase(),
    RESEND_API_KEY: process.env.RESEND_API_KEY ?? "",
    EMAIL_FROM: process.env.EMAIL_FROM ?? "",
    EMAIL_MIDDLEWARE_URL: (process.env.EMAIL_MIDDLEWARE_URL ?? "").trim().replace(/\/+$/, ""),
    EMAIL_MIDDLEWARE_API_KEY: (process.env.EMAIL_MIDDLEWARE_API_KEY ?? "").trim(),
    EMAIL_MIDDLEWARE_SYSTEM: (process.env.EMAIL_MIDDLEWARE_SYSTEM ?? "").trim(),
  };

  // Fail-fast: required vars must be present and non-empty.
  const missing = REQUIRED.filter((k) => !env[k]);
  if (missing.length) {
    throw new Error(
      "[env] Missing required environment variables: " +
        missing.join(", ") +
        ". Copy .env.example to .env and fill in the values. See DEPLOYMENT.md."
    );
  }

  if (env.NEXTAUTH_SECRET.length < 16) {
    throw new Error(
      "[env] NEXTAUTH_SECRET must be at least 16 characters. " +
        "Generate one with: node -e \"console.log(require('crypto').randomBytes(32).toString('hex'))\""
    );
  }

  // DATABASE_URL must be a SQLite file URL for both dev and intranet prod.
  if (!env.DATABASE_URL.startsWith("file:")) {
    throw new Error(
      "[env] DATABASE_URL must be a SQLite file URL (e.g. file:./db/production-data.db). " +
        "Got: " + env.DATABASE_URL
    );
  }

  // Production safety guard — refuse to connect to the legacy dev scratch DB.
  if (env.NODE_ENV === "production" && env.DATABASE_URL.includes("custom.db")) {
    throw new Error(
      "[env] Refusing to connect to 'custom.db' in production — this is the old " +
        "dev scratch database. Set DATABASE_URL to the production database " +
        "(file:./db/production-data.db)."
    );
  }

  // Warn (don't throw) when AI_API_KEY is missing — the app still starts, but
  // the PDS auto-extract feature will fail at runtime with a clear error.
  if (!env.AI_API_KEY) {
    console.warn(
      "[env] AI_API_KEY is not set. Document Intelligence (PDS auto-extract) " +
        "will not work. Set AI_API_KEY in .env to enable AI-powered extraction."
    );
  }

  // Two-tier access guard sanity check — an unknown value should fail loudly
  // rather than silently behaving as "off".
  if (env.INTRANET_ENFORCEMENT !== "on" && env.INTRANET_ENFORCEMENT !== "off") {
    throw new Error(
      "[env] INTRANET_ENFORCEMENT must be 'on' or 'off' (default 'on'). " +
        "Got: " + env.INTRANET_ENFORCEMENT
    );
  }

  // Email provider sanity — fail fast on a config that can never deliver,
  // and warn loudly in production when notices would silently be dropped.
  if (env.EMAIL_PROVIDER !== "mock" && env.EMAIL_PROVIDER !== "resend" && env.EMAIL_PROVIDER !== "middleware") {
    throw new Error(
      "[env] EMAIL_PROVIDER must be 'mock', 'resend' or 'middleware' (default 'mock'). " +
        "Got: " + env.EMAIL_PROVIDER
    );
  }
  if (env.EMAIL_PROVIDER === "resend") {
    if (!env.RESEND_API_KEY) {
      throw new Error(
        "[env] RESEND_API_KEY is required when EMAIL_PROVIDER=resend. " +
          "Get one at https://resend.com and set it in .env."
      );
    }
    if (!env.EMAIL_FROM) {
      throw new Error(
        "[env] EMAIL_FROM is required when EMAIL_PROVIDER=resend " +
          '(e.g. EMAIL_FROM="RMIS <no-reply@mirdc.gov.ph>").'
      );
    }
  } else if (env.EMAIL_PROVIDER === "middleware") {
    if (!env.EMAIL_MIDDLEWARE_URL) {
      throw new Error(
        "[env] EMAIL_MIDDLEWARE_URL is required when EMAIL_PROVIDER=middleware " +
          '(e.g. EMAIL_MIDDLEWARE_URL="http://10.10.x.x:3232" — the mirdc_middleware VM).'
      );
    }
    if (!/^https?:\/\//.test(env.EMAIL_MIDDLEWARE_URL)) {
      throw new Error(
        "[env] EMAIL_MIDDLEWARE_URL must start with http:// or https:// — got: " +
          env.EMAIL_MIDDLEWARE_URL
      );
    }
    if (!env.EMAIL_MIDDLEWARE_API_KEY) {
      throw new Error(
        "[env] EMAIL_MIDDLEWARE_API_KEY is required when EMAIL_PROVIDER=middleware " +
          "(the shared middleware token sent as body.api)."
      );
    }
    // EMAIL_FROM is intentionally NOT required for the middleware: the From
    // header is owned by the office mailbox (systems@mirdc.dost.gov.ph) and
    // the display name comes from EMAIL_MIDDLEWARE_SYSTEM.
  } else if (env.NODE_ENV === "production") {
    console.warn(
      "[env] EMAIL_PROVIDER is 'mock' in production — applicant/evaluator email " +
        "notices will be recorded to the ledger but NEVER delivered. Set " +
        "EMAIL_PROVIDER=middleware (+ EMAIL_MIDDLEWARE_URL + EMAIL_MIDDLEWARE_API_KEY) " +
        "to use the office mail gateway, or EMAIL_PROVIDER=resend + RESEND_API_KEY + " +
        "EMAIL_FROM for the Resend API."
    );
  }

  return env;
}

// ----------------------------------------------------------------------------
// Singleton — read once on first import, cached for the process lifetime.
// In dev (Turbopack/HMR) the module graph can be re-evaluated, so we also cache
// on globalThis to avoid re-running validation on every hot reload.
// ----------------------------------------------------------------------------
const g = globalThis as unknown as { __rmisEnv?: EnvShape };
export const env: EnvShape = g.__rmisEnv ?? (g.__rmisEnv = readEnv());

/** Convenience: is the app running in production mode? */
export const isProduction = env.NODE_ENV === "production";

/** Convenience: is the app running in development mode? */
export const isDevelopment = env.NODE_ENV === "development";

/**
 * Resolve the absolute upload directory. Falls back to `<cwd>/upload` when
 * UPLOAD_DIR is not set (the default for both localhost dev and a standard
 * intranet install).
 */
export function uploadDir(): string {
  return env.UPLOAD_DIR || `${process.cwd()}/upload`;
}

/**
 * Resolve the absolute application root WITHOUT depending on process.cwd().
 *
 * The standalone production server (pm2 → .next/standalone/server.js) runs
 * with CWD = .next/standalone — any path resolved via process.cwd() therefore
 * lands INSIDE the build output (wiped on every rebuild). DATABASE_URL is an
 * absolute `file:` URL pointing at <appRoot>/db/… in production, which gives
 * a cwd-independent anchor. Falls back to CWD for relative-URL dev setups.
 */
export function appRoot(): string {
  const dbFile = sqliteFilePath();
  if (path.isAbsolute(dbFile)) return path.dirname(path.dirname(dbFile));
  return process.cwd();
}

/**
 * Resolve a stored document path to its absolute filesystem location.
 *
 * Document metas store paths relative to the app root ("upload/8/uuid.xlsx",
 * see src/lib/documents.ts), but the file physically lives under UPLOAD_DIR.
 * Resolve against UPLOAD_DIR — stripping the leading "upload/" segment — so
 * reads work under the standalone server regardless of process.cwd(), and
 * even when UPLOAD_DIR is relocated off the app root.
 */
export function resolveStoredDocPath(filePath: string): string {
  if (path.isAbsolute(filePath)) return filePath;
  const rel = filePath.replace(/^(\.\/)?upload[/\\]/, "");
  return path.join(uploadDir(), rel);
}

/**
 * Resolve the SQLite file path from DATABASE_URL (strips the `file:` prefix).
 * Used by better-sqlite3 in raw-json.ts.
 */
export function sqliteFilePath(): string {
  return env.DATABASE_URL.replace(/^file:/, "");
}
