// ============================================================================
// Shared ACTION META — the single registry that turns an AuditAction code
// ("APPLICATION_SUBMITTED") into the friendly, tone-classified label every
// audit surface renders: Settings → Audit Log table and the Analytics
// activity feed. Keeps the two surfaces word-for-word and colour-for-colour
// consistent — and any new audit action only needs one entry here.
// ============================================================================

export type ActionTone = "success" | "danger" | "info" | "neutral" | "primary" | "warning";

/** Pill classes per tone — border + wash on `bg`, ink on `text`. */
export const ACTION_TONE_CLS: Record<ActionTone, { bg: string; text: string }> = {
  success: { bg: "border-success/40 bg-success/10", text: "text-success-ink" },
  danger: { bg: "border-destructive/40 bg-destructive/10", text: "text-danger-ink" },
  info: { bg: "border-info-ink/40 bg-info-ink/10", text: "text-info-ink" },
  neutral: { bg: "border-border bg-secondary", text: "text-muted-foreground" },
  primary: { bg: "border-primary/40 bg-primary/10", text: "text-info-ink" },
  warning: { bg: "border-warning/40 bg-warning/10", text: "text-warning-ink" },
};

export const ACTION_META: Record<string, { label: string; tone: ActionTone }> = {
  LOGIN_SUCCESS: { label: "Login", tone: "success" },
  LOGIN_FAILED: { label: "Login Failed", tone: "danger" },
  LOGIN_LOCKED: { label: "Locked: Sign-in", tone: "warning" },
  LOGIN_BLOCKED_EXTERNAL: { label: "Blocked: Web Staff Login", tone: "danger" },
  STAFF_ACCESS_BLOCKED_EXTERNAL: { label: "Blocked: Staff API (Web)", tone: "danger" },
  LOGOUT: { label: "Logout", tone: "neutral" },
  APPLICATION_SUBMITTED: { label: "Applied", tone: "info" },
  APPLICATION_STATUS_CHANGED: { label: "Status Changed", tone: "info" },
  APPLICATION_WITHDRAWN: { label: "Application Withdrawn", tone: "warning" },
  ASSESSMENT_SUBMITTED: { label: "Assessed", tone: "info" },
  JOB_POSTING_CREATED: { label: "Job Created", tone: "primary" },
  JOB_POSTING_UPDATED: { label: "Job Updated", tone: "primary" },
  POSITION_CREATED: { label: "Position Created", tone: "primary" },
  POSITION_UPDATED: { label: "Position Updated", tone: "primary" },
  DOCUMENT_UPLOADED: { label: "Doc Uploaded", tone: "warning" },
  DOCUMENT_DELETED: { label: "Doc Deleted", tone: "danger" },
  PROFILE_UPDATED: { label: "Profile Updated", tone: "info" },
  PROFILE_COMPLETED: { label: "Profile Completed", tone: "success" },
  PROFILE_CLEARED: { label: "Profile Cleared", tone: "warning" },
  PROFILE_AUTO_FILLED: { label: "Auto-Fill Applied", tone: "primary" },
  MASTER_DATA_UPDATED: { label: "Master Data Updated", tone: "primary" },
  USER_CREATED: { label: "User Created", tone: "info" },
  USER_UPDATED: { label: "User Updated", tone: "neutral" },
  USER_DISABLED: { label: "User Disabled", tone: "danger" },
  USER_DELETED: { label: "User Deleted", tone: "danger" },
  USER_ROLE_CHANGED: { label: "Role Changed", tone: "warning" },
  USER_REGISTERED: { label: "Account Registered", tone: "info" },
  DIRECT_EMAIL_SENT: { label: "Direct Email", tone: "info" },
  NOTICE_SENT: { label: "Notice Sent", tone: "info" },
  REGRET_LETTERS_BULK_SENT: { label: "Regret Letters Sent", tone: "warning" },
  TEST_EMAIL_SENT: { label: "Test Email Sent", tone: "info" },
};

export function getActionMeta(action: string): { label: string; tone: ActionTone } {
  return (
    ACTION_META[action] ?? {
      label: action
        .replace(/_/g, " ")
        .toLowerCase()
        .replace(/\b\w/g, (c) => c.toUpperCase()),
      tone: "neutral",
    }
  );
}
