// Shared file-type constants and helpers for document upload/processing.
// Single source of truth so the upload route and extraction service stay in sync.

export const IMAGE_EXTS = [".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"] as const;
export const EXCEL_EXTS = [".xlsx", ".xls", ".xlsm"] as const;
export const PDF_EXTS = [".pdf"] as const;
export const WORD_EXTS = [".doc", ".docx"] as const;

export const ALLOWED_UPLOAD_EXTS = [
  ...IMAGE_EXTS,
  ...EXCEL_EXTS,
  ...PDF_EXTS,
  ...WORD_EXTS,
] as const;

export const ALLOWED_UPLOAD_MIMES = [
  "image/png", "image/jpeg", "image/jpg", "image/gif", "image/webp", "image/bmp",
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/vnd.ms-excel",
] as const;

export type FileKind = "image" | "excel" | "pdf" | "word" | "unknown";

// Explicit MIME-to-extension map — avoids fragile string splitting.
export const MIME_TO_EXT: Record<string, string> = {
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
  "application/vnd.ms-excel": ".xls",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
  "application/msword": ".doc",
  "application/pdf": ".pdf",
  "image/png": ".png",
  "image/jpeg": ".jpeg",
  "image/jpg": ".jpg",
  "image/gif": ".gif",
  "image/webp": ".webp",
  "image/bmp": ".bmp",
};

export function detectFileKind(filePath: string): FileKind {
  const ext = filePath.slice(filePath.lastIndexOf(".")).toLowerCase();
  if (IMAGE_EXTS.includes(ext as never)) return "image";
  if (EXCEL_EXTS.includes(ext as never)) return "excel";
  if (PDF_EXTS.includes(ext as never)) return "pdf";
  if (WORD_EXTS.includes(ext as never)) return "word";
  return "unknown";
}

// ----------------------------------------------------------------------------
// Magic-byte (file signature) sniffing — server-side upload validation.
//
// SECURITY: a client-declared MIME type and filename extension are trivially
// spoofed (multipart `file.type` comes straight from the browser, and the
// extension is just the name). Before persisting an upload we compare the
// file's leading bytes against the signature family its extension claims —
// a `poster.pdf` that is actually an HTML/PHP payload never reaches disk.
// No dependency: every signature below fits in the first bytes of the buffer.
// ----------------------------------------------------------------------------

/** Signature families and their leading byte patterns. */
const MAGIC_SIGNATURES = {
  pdf: "25 50 44 46 2D",                        // %PDF-
  png: "89 50 4E 47 0D 0A 1A 0A",               // \x89PNG\r\n\x1a\n
  jpeg: "FF D8 FF",                             // JPEG SOI + marker
  zip: "50 4B 03 04",                           // PK\x03\x04 (DOCX/XLSX container)
  ole: "D0 CF 11 E0 A1 B1 1A E1",               // OLE2 compound doc (DOC/XLS)
  bmp: "42 4D",                                 // "BM" — Windows bitmap
  gif: "47 49 46 38",                           // "GIF8" (GIF87a / GIF89a)
  webp: "52 49 46 46",                          // "RIFF" (WEBP tag at offset 8)
} as const;

type MagicFamily = keyof typeof MAGIC_SIGNATURES;

/** Extension → the signature family its content MUST carry. */
const EXT_TO_FAMILY: Record<string, MagicFamily> = {
  ".pdf": "pdf",
  ".png": "png",
  ".jpg": "jpeg",
  ".jpeg": "jpeg",
  ".gif": "gif",
  ".webp": "webp",
  ".bmp": "bmp",
  ".docx": "zip",
  ".xlsx": "zip",
  ".xlsm": "zip",
  ".doc": "ole",
  ".xls": "ole",
};

function hexToBytes(hex: string): number[] {
  return hex.split(" ").map((h) => parseInt(h, 16));
}

/**
 * Verify that `buffer` starts with the magic bytes of the signature family
 * claimed by `ext` (e.g. `.pdf` → `%PDF-`). Returns true when the extension
 * has no known signature (nothing to verify) or the bytes match; false on a
 * mismatch — i.e. the file content does not match its declared type.
 */
export function magicBytesMatch(buffer: Buffer, ext: string): boolean {
  const family = EXT_TO_FAMILY[ext.toLowerCase()];
  if (!family) return true; // no signature known for this extension
  const expected = hexToBytes(MAGIC_SIGNATURES[family]);
  if (buffer.length < expected.length) return false;
  for (let i = 0; i < expected.length; i++) {
    if (buffer[i] !== expected[i]) return false;
  }
  // WebP refinement: "RIFF" containers are common — require the "WEBP" tag
  // at offset 8 so a renamed RIFF WAV/AVI is rejected.
  if (family === "webp") {
    if (buffer.length < 12) return false;
    return (
      buffer[8] === 0x57 && buffer[9] === 0x45 &&
      buffer[10] === 0x42 && buffer[11] === 0x50
    );
  }
  return true;
}

// Valid document categories — used by the document upload/extract feature.
// Production schema has NO `Document` model (uploads live in the `files` table),
// so this list is the local source of truth.
export const VALID_DOCUMENT_CATEGORIES = [
  "PDS", "RESUME", "EDUCATION", "WORK_EXPERIENCE", "TRAINING",
  "ELIGIBILITY", "AWARD", "ACCOMPLISHMENT", "COE",
  "PERFORMANCE_EVALUATION", "SUPPORTING", "PROFILE_PICTURE",
] as const;

export type ValidDocumentCategory = (typeof VALID_DOCUMENT_CATEGORIES)[number];

export function isValidDocumentCategory(s: string): s is ValidDocumentCategory {
  return (VALID_DOCUMENT_CATEGORIES as readonly string[]).includes(s);
}
