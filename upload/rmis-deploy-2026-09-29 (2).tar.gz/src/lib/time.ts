// ============================================================================
// time.ts — shared relative-time + deadline helpers (ported from the
// rmis-minimalist-prod client layer so the frontpage explorer reads exactly
// like the previous RMIS).
// Client-safe: pure functions, no side effects.
// ============================================================================

/** Compact relative age — "just now" / "5m ago" / "3h ago" / "12d ago". */
export function timeAgo(d: string | Date | null | undefined): string {
  if (!d) return "";
  const date = typeof d === "string" ? new Date(d) : d;
  if (Number.isNaN(date.getTime())) return "";
  const mins = Math.floor((Date.now() - date.getTime()) / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 30) return `${days}d ago`;
  return formatDateShort(date);
}

function formatDateShort(d: Date): string {
  return d.toLocaleDateString("en-PH", { year: "numeric", month: "short", day: "numeric" });
}

/** Whole calendar days from today until `d` (negative = past). */
export function daysUntil(d: string | Date | null | undefined): number | null {
  if (!d) return null;
  const date = typeof d === "string" ? new Date(d) : d;
  if (Number.isNaN(date.getTime())) return null;
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  const target = new Date(date);
  target.setHours(0, 0, 0, 0);
  return Math.round((target.getTime() - start.getTime()) / 86400000);
}

/** Deadline badge state — overdue / closing-soon / open, with a label. */
export function deadlineState(d: string | Date | null | undefined): {
  label: string;
  overdue: boolean;
  closingSoon: boolean;
} {
  const days = daysUntil(d);
  if (days === null) return { label: "Open until filled", overdue: false, closingSoon: false };
  if (days < 0) return { label: "Closed", overdue: true, closingSoon: false };
  if (days === 0) return { label: "Closing today", overdue: false, closingSoon: true };
  if (days <= 7)
    return { label: `Closing in ${days} day${days === 1 ? "" : "s"}`, overdue: false, closingSoon: true };
  if (days <= 30) return { label: `${days} days left`, overdue: false, closingSoon: false };
  return { label: "Open", overdue: false, closingSoon: false };
}
