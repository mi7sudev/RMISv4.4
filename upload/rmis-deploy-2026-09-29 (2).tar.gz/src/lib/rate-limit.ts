// Simple in-memory rate limiter for login brute-force protection.
// In production, replace with Redis-based rate limiting (or the API gateway's
// built-in rate limiting). This is a minimum viable protection for the dev/staging
// environment — it resets on server restart.

import { getTrustedClientIp } from "@/lib/access-tier";

type RateLimitEntry = {
  count: number;      // failed attempts since the last success
  lockLevel: number;  // how many lockouts have already been issued (0 = never locked)
  resetAt: number;    // epoch ms — lockout end while locked; window end before first lockout
};

const loginAttempts = new Map<string, RateLimitEntry>();
const MAX_LOGIN_ATTEMPTS = 3;
const WINDOW_MS = 15 * 60 * 1000; // 15 minutes
// Progressive lockout ladder — after MAX_LOGIN_ATTEMPTS (3) consecutive
// failures, the identifier is locked out for 30 seconds. Each subsequent
// failure (post-lockout) steps up the ladder: 30s → 1m → 2m → 3m → 5m → 10m,
// with 10 minutes as the hard maximum. A successful login clears everything.
const LOCKOUT_STEPS_SEC = [
  30,          // first lockout
  60,          // 1 minute
  2 * 60,      // 2 minutes
  3 * 60,      // 3 minutes
  5 * 60,      // 5 minutes
  10 * 60,     // 10 minutes — MAXIMUM (capped here)
];

/**
 * Human-friendly lockout duration, e.g. "30 seconds", "2m 30s", "10 minutes".
 */
export function formatLockDuration(totalSec: number): string {
  const sec = Math.max(1, Math.ceil(totalSec));
  if (sec < 60) return `${sec} second${sec === 1 ? "" : "s"}`;
  const min = Math.floor(sec / 60);
  const rest = sec % 60;
  if (rest === 0) return `${min} minute${min === 1 ? "" : "s"}`;
  return `${min}m ${String(rest).padStart(2, "0")}s`;
}

/**
 * Check if the given identifier (IP + username) is rate-limited.
 * Returns { allowed: boolean, retryAfterMs?: number, remaining?: number }
 */
export function checkLoginRateLimit(identifier: string): {
  allowed: boolean;
  retryAfterMs?: number;
  remaining?: number;
} {
  const key = identifier.toLowerCase();
  const now = Date.now();
  const entry = loginAttempts.get(key);

  if (!entry) {
    return { allowed: true, remaining: MAX_LOGIN_ATTEMPTS };
  }

  // Once an identifier has been locked at least once the escalation level is
  // remembered until a successful login clears it — expiry of one lockout
  // does NOT forgive the escalation progress.
  if (entry.lockLevel > 0 && entry.count >= MAX_LOGIN_ATTEMPTS) {
    if (now < entry.resetAt) {
      // Still serving the current lockout step.
      return { allowed: false, retryAfterMs: entry.resetAt - now };
    }
    // Lockout served — allow the next attempt; the entry is kept so the next
    // failure escalates to the following step in the ladder.
    return { allowed: true, remaining: 0 };
  }

  // Pre-lockout failures live in a rolling 15-minute window — if it lapses
  // without reaching the threshold, the count starts over.
  if (now > entry.resetAt) {
    loginAttempts.delete(key);
    return { allowed: true, remaining: MAX_LOGIN_ATTEMPTS };
  }

  return { allowed: true, remaining: Math.max(0, MAX_LOGIN_ATTEMPTS - entry.count) };
}

/**
 * Record a failed login attempt for the given identifier.
 * The 3rd failure starts a 30-second lockout; every further failure escalates
 * the lockout: 1 → 2 → 3 → 5 → 10 minutes (10 minutes is the maximum).
 * Returns the post-record state so the route can tell the user how many
 * attempts remain, or how long the fresh lockout lasts.
 */
export function recordFailedLogin(identifier: string): {
  locked: boolean;
  retryAfterSec?: number;
  remaining?: number;
} {
  const key = identifier.toLowerCase();
  const now = Date.now();
  const existing = loginAttempts.get(key);

  // Fresh window — first-ever failure, or the pre-lockout window lapsed
  // without reaching the threshold (never-locked identifiers only).
  if (!existing || (existing.lockLevel === 0 && now > existing.resetAt)) {
    loginAttempts.set(key, {
      count: 1,
      lockLevel: 0,
      resetAt: now + WINDOW_MS,
    });
    return { locked: false, remaining: MAX_LOGIN_ATTEMPTS - 1 };
  }

  existing.count += 1;
  if (existing.count >= MAX_LOGIN_ATTEMPTS) {
    // Progressive lockout: step up the ladder each time (capped at 10 minutes).
    const stepSec = LOCKOUT_STEPS_SEC[Math.min(existing.lockLevel, LOCKOUT_STEPS_SEC.length - 1)];
    existing.resetAt = now + stepSec * 1000;
    existing.lockLevel += 1;
    return { locked: true, retryAfterSec: stepSec, remaining: 0 };
  }

  return { locked: false, remaining: MAX_LOGIN_ATTEMPTS - existing.count };
}

/**
 * Clear rate limit on successful login.
 */
export function clearLoginRateLimit(identifier: string): void {
  loginAttempts.delete(identifier.toLowerCase());
}

// ---------------------------------------------------------------------------
// Generic per-action limiter (in-memory, resets on restart) — used for
// sensitive free-form actions such as direct emails to applicants.
// ---------------------------------------------------------------------------

const actionAttempts = new Map<string, RateLimitEntry>();

/**
 * Consume one slot from a generic sliding-window quota. Records the attempt
 * and reports whether the caller is still under the limit.
 * Example: direct emails — 20 sends per user per 10 minutes.
 */
export function consumeRateLimit(
  key: string,
  limit: number,
  windowMs: number
): { allowed: boolean; retryAfterMs?: number } {
  const k = key.toLowerCase();
  const now = Date.now();
  const entry = actionAttempts.get(k);

  if (!entry || now > entry.resetAt) {
    actionAttempts.set(k, { count: 1, lockLevel: 0, resetAt: now + windowMs });
    return { allowed: true };
  }
  if (entry.count >= limit) {
    return { allowed: false, retryAfterMs: entry.resetAt - now };
  }
  entry.count += 1;
  return { allowed: true };
}

/**
 * Get client IP from NextRequest, accounting for the Caddy reverse proxy.
 *
 * SECURITY: delegates to getTrustedClientIp (access-tier.ts), which classifies
 * the LAST X-Forwarded-For entry — the address our own proxy vouches for.
 * Taking the FIRST entry (the previous implementation) let any internet client
 * rotate a spoofed `X-Forwarded-For` header to sidestep the per-IP login
 * lockout and the register throttle, and polluted audit-log IP addresses.
 */
export function getClientIp(req: Request): string {
  return getTrustedClientIp(req);
}
