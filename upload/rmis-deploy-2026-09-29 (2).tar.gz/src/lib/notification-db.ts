import Database from "better-sqlite3";
import { mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { appRoot } from "@/lib/env";

// ============================================================================
// In-app Notification Database — a DEDICATED SQLite file backing the bell in
// the workspace header (db/notifications.db).
//
// WHY A SEPARATE FILE?
//   Same rationale as audit.db: the production database (db/production-data.db)
//   is a PURE MAPPING target — never migrated. The production `notifications`
//   table is a legacy Strapi surface (loosely typed, no per-user read state)
//   that some flows still write to for record-keeping only. This dedicated
//   file is 100% owned by the app and supports a real notification product:
//
//     · TARGETED notifications (user_id)  — personal events: your application
//       was shortlisted, an interview invitation arrived, your application
//       was received.
//     · AUDIENCE notifications (role)     — staff-wide operational alerts:
//       new application submitted, application withdrawn, account registered,
//       sign-in lockouts.
//     · PER-USER READ STATE (notification_reads) — unread badge, mark read,
//       mark all as read. A broadcast row stays unread for each recipient
//       until THAT user reads it.
//
//   Created automatically on first use (idempotent). Never touches the
//   production database. Every write is fire-and-forget — a notification
//   failure NEVER breaks the operation that produced the event.
// ============================================================================

const NOTIF_DB_PATH = join(appRoot(), "db", "notifications.db");

try {
  mkdirSync(dirname(NOTIF_DB_PATH), { recursive: true });
} catch {
  // ignore — directory already exists
}

let _db: Database.Database | null = null;

function getDb(): Database.Database {
  if (_db) return _db;
  _db = new Database(NOTIF_DB_PATH);
  _db.pragma("journal_mode = WAL");
  _db.pragma("synchronous = NORMAL");

  _db.exec(`
    CREATE TABLE IF NOT EXISTS notifications (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      created_at  TEXT    NOT NULL,   -- ISO 8601
      type        TEXT    NOT NULL,   -- NotificationKind (drives icon/tone)
      audience    TEXT,               -- ADMIN / EVALUATOR / APPLICANT broadcast
      user_id     TEXT,               -- targeted recipient (up_users.id as TEXT)
      title       TEXT    NOT NULL,
      body        TEXT,
      link_view   TEXT,               -- hash-router view for click-through
      link_params TEXT,               -- JSON object string of navigate params
      entity_type TEXT,
      entity_id   TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_notifications_created  ON notifications(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_notifications_audience ON notifications(audience);
    CREATE INDEX IF NOT EXISTS idx_notifications_user     ON notifications(user_id);

    CREATE TABLE IF NOT EXISTS notification_reads (
      notification_id INTEGER NOT NULL,
      user_id         TEXT    NOT NULL,
      read_at         TEXT    NOT NULL,
      PRIMARY KEY (notification_id, user_id)
    );
  `);

  return _db;
}

// ----------------------------------------------------------------------------
// Public types
// ----------------------------------------------------------------------------

/** Every kind maps to a fixed icon + tone in the NotificationCenter UI. */
export type NotificationKind =
  | "APPLICATION_SUBMITTED"      // applicant confirmation + staff broadcast
  | "APPLICATION_WITHDRAWN"      // staff broadcast
  | "APPLICATION_SHORTLISTED"    // applicant (decision)
  | "APPLICATION_REJECTED"       // applicant (decision)
  | "APPLICATION_STATUS_CHANGED" // applicant (other status moves)
  | "NOTICE_SENT"                // applicant (interview / skills-exam / regret)
  | "JOB_POSTED"                 // staff broadcast (new vacancy published)
  | "USER_REGISTERED"            // admin broadcast
  | "LOGIN_LOCKED"               // admin broadcast (security)
  | "LOGIN_BLOCKED_EXTERNAL";    // admin broadcast (security)

export type NotificationRow = {
  id: number;
  created_at: string;
  type: string;
  audience: string | null;
  user_id: string | null;
  title: string;
  body: string | null;
  link_view: string | null;
  link_params: string | null;
  entity_type: string | null;
  entity_id: string | null;
  read: number; // 0/1 — resolved per-user via notification_reads
};

export type EmitNotificationInput = {
  type: NotificationKind;
  title: string;
  body?: string | null;
  /** Role broadcast — every signed-in member of the role sees it. */
  audience?: "ADMIN" | "EVALUATOR" | "APPLICANT" | null;
  /** Targeted recipient — only this user sees it (wins over audience). */
  userId?: number | string | null;
  /** Hash-router view for click-through (e.g. "home", "review-queue"). */
  linkView?: string | null;
  /** navigate() params for the click-through view. */
  linkParams?: Record<string, string> | null;
  entityType?: string | null;
  entityId?: number | string | null;
};

// ----------------------------------------------------------------------------
// Emit one notification. Sync (better-sqlite3) — very fast. Never throws:
// failures are logged and the caller's operation continues unaffected.
// ----------------------------------------------------------------------------
export function emitNotification(input: EmitNotificationInput): void {
  try {
    getDb()
      .prepare(
        `INSERT INTO notifications
           (created_at, type, audience, user_id, title, body, link_view, link_params, entity_type, entity_id)
         VALUES (@createdAt, @type, @audience, @userId, @title, @body, @linkView, @linkParams, @entityType, @entityId)`,
      )
      .run({
        createdAt: new Date().toISOString(),
        type: input.type,
        audience: input.audience ?? null,
        userId: input.userId != null ? String(input.userId) : null,
        title: input.title,
        body: input.body ?? null,
        linkView: input.linkView ?? null,
        linkParams: input.linkParams ? JSON.stringify(input.linkParams) : null,
        entityType: input.entityType ?? null,
        entityId: input.entityId != null ? String(input.entityId) : null,
      });
    pruneNotifications();
  } catch (e) {
    console.error("[NOTIF-DB] emit failed:", e);
  }
}

// ----------------------------------------------------------------------------
// Housekeeping — keep the file bounded: drop notifications older than 30 days
// and sweep orphaned read rows. Runs after each emit; failures are non-critical.
// ----------------------------------------------------------------------------
function pruneNotifications(): void {
  try {
    const cutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
    getDb().prepare(`DELETE FROM notifications WHERE created_at < @cutoff`).run({ cutoff });
    getDb()
      .prepare(
        `DELETE FROM notification_reads
          WHERE notification_id NOT IN (SELECT id FROM notifications)`,
      )
      .run();
  } catch {
    // non-critical
  }
}

// ----------------------------------------------------------------------------
// Visibility rule: a row is visible to me when it is TARGETED at me
// (user_id = me) or BROADCAST to my role (audience = my role).
// `read` is resolved per-user from notification_reads (LEFT JOIN).
// ----------------------------------------------------------------------------
export function listNotificationsForUser(
  userId: string,
  role: string,
  limit = 30,
): NotificationRow[] {
  return getDb()
    .prepare(
      `SELECT n.id, n.created_at, n.type, n.audience, n.user_id, n.title, n.body,
              n.link_view, n.link_params, n.entity_type, n.entity_id,
              (r.user_id IS NOT NULL) AS read
         FROM notifications n
         LEFT JOIN notification_reads r
           ON r.notification_id = n.id AND r.user_id = @uid
        WHERE n.user_id = @uid
           OR (n.audience IS NOT NULL AND n.audience = @role)
        ORDER BY n.id DESC
        LIMIT @limit`,
    )
    .all({ uid: userId, role, limit }) as NotificationRow[];
}

export function countUnreadNotifications(userId: string, role: string): number {
  const row = getDb()
    .prepare(
      `SELECT COUNT(*) AS c
         FROM notifications n
         LEFT JOIN notification_reads r
           ON r.notification_id = n.id AND r.user_id = @uid
        WHERE (n.user_id = @uid OR (n.audience IS NOT NULL AND n.audience = @role))
          AND r.user_id IS NULL`,
    )
    .get({ uid: userId, role }) as { c: number };
  return row.c;
}

// ----------------------------------------------------------------------------
// Mark read — an explicit list of ids, or everything visible to me.
// Only rows the user can actually see are marked (no cross-user reads).
// Returns the number of rows newly marked.
// ----------------------------------------------------------------------------
export function markNotificationsRead(
  userId: string,
  role: string,
  opts: { ids?: number[]; all?: boolean },
): number {
  const db = getDb();
  const now = new Date().toISOString();

  try {
    if (opts.all) {
      const info = db
        .prepare(
          `INSERT OR IGNORE INTO notification_reads (notification_id, user_id, read_at)
           SELECT n.id, @uid, @now
             FROM notifications n
             LEFT JOIN notification_reads r
               ON r.notification_id = n.id AND r.user_id = @uid
            WHERE (n.user_id = @uid OR (n.audience IS NOT NULL AND n.audience = @role))
              AND r.user_id IS NULL`,
        )
        .run({ uid: userId, role, now });
      return info.changes;
    }

    const ids = (opts.ids ?? []).map(Number).filter(Number.isFinite);
    if (!ids.length) return 0;
    const placeholders = ids.map(() => "?").join(",");
    const info = db
      .prepare(
        `INSERT OR IGNORE INTO notification_reads (notification_id, user_id, read_at)
         SELECT id, ?, ? FROM notifications
          WHERE id IN (${placeholders})
            AND (user_id = ? OR (audience IS NOT NULL AND audience = ?))`,
      )
      .run(userId, now, ...ids, userId, role);
    return info.changes;
  } catch (e) {
    console.error("[NOTIF-DB] mark-read failed:", e);
    return 0;
  }
}
