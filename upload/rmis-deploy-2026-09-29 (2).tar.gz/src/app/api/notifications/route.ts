import { NextRequest } from "next/server";
import { ok, handleApi } from "@/lib/api";
import { requireAuthFromReq } from "@/lib/auth";
import {
  listNotificationsForUser,
  countUnreadNotifications,
} from "@/lib/notification-db";

// ============================================================================
// GET /api/notifications — the current user's notification feed.
//
// Auth: ANY signed-in role (ADMIN / EVALUATOR / APPLICANT) — the bell is a
// first-class surface for everyone, not an admin-only mock.
//
// Visibility: rows TARGETED at me (user_id) or BROADCAST to my role
// (audience), newest-first, capped at 30. Each row carries its per-user read
// state plus the click-through target (linkView + linkParams) the client
// navigates to when the item is tapped.
// ============================================================================

export const GET = handleApi(async (req: NextRequest) => {
  const user = await requireAuthFromReq(req);

  const rows = listNotificationsForUser(user.id, user.role, 30);
  const unread = countUnreadNotifications(user.id, user.role);

  return ok({
    data: rows.map((r) => ({
      id: r.id,
      type: r.type,
      title: r.title,
      body: r.body,
      linkView: r.link_view,
      linkParams: r.link_params ? safeParse(r.link_params) : null,
      entityType: r.entity_type,
      entityId: r.entity_id,
      createdAt: r.created_at,
      read: !!r.read,
    })),
    unread,
  });
});

function safeParse(json: string): Record<string, string> | null {
  try {
    const v = JSON.parse(json);
    return v && typeof v === "object" ? (v as Record<string, string>) : null;
  } catch {
    return null;
  }
}
