import { NextRequest } from "next/server";
import { z } from "zod";
import { ok, handleApi } from "@/lib/api";
import { requireAuthFromReq } from "@/lib/auth";
import { markNotificationsRead } from "@/lib/notification-db";

// ============================================================================
// POST /api/notifications/read — mark notifications as read for the current
// user. Body: { ids: number[] } (specific items) or { all: true } (everything
// visible to me). Only rows the user can actually see are marked — a targeted
// or role-broadcast row another user "passes" in ids is ignored.
// ============================================================================

const readSchema = z.object({
  ids: z.array(z.number()).optional(),
  all: z.boolean().optional(),
});

export const POST = handleApi(async (req: NextRequest) => {
  const user = await requireAuthFromReq(req);

  const parsed = readSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return ok({ marked: 0 });

  const marked = markNotificationsRead(user.id, user.role, {
    ids: parsed.data.ids,
    all: parsed.data.all,
  });

  return ok({ marked });
});
