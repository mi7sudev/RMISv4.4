// GET /api — API root. Deliberately minimal: the old "Hello, world!" scaffold
// leaked a hand-rolled-dev impression on the public surface. A health-style
// heartbeat with no system details is all a root probe should reveal.
import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({ status: "ok" });
}
