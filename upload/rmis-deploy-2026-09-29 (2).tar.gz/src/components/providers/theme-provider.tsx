"use client";

// ============================================================================
// ThemeProvider — next-themes with the CLASS strategy on <html>.
//
// The RMIS system is LIGHT-first (HR request, 2026): first-open visitors get
// the warm-paper sheet (white canvas, #F1F1EF blocks) with no stored choice,
// and the obsidian sheet (deep cool-dark canvas) is opt-in via the toggle.
// `enableSystem` is off so the toggle is the single source of truth — a
// user's OS preference never fights the app default. next-themes only writes
// localStorage when the toggle is used, so anyone who explicitly chose dark
// keeps it; everyone else lands on light. `suppressHydrationWarning` on
// <html> (see app/layout.tsx) absorbs the class next-themes injects before
// React hydrates.
// ============================================================================

import { ThemeProvider as NextThemesProvider } from "next-themes";

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  return (
    <NextThemesProvider
      attribute="class"
      defaultTheme="light"
      enableSystem={false}
      disableTransitionOnChange
    >
      {children}
    </NextThemesProvider>
  );
}
