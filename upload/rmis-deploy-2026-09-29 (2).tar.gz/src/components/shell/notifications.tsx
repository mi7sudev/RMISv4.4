"use client";

// ============================================================================
// NotificationCenter — REAL event-driven notifications backed by the
// dedicated db/notifications.db store (src/lib/notification-db.ts).
//
// NOT A MOCK: every item is a persisted row written by a real system event
//   · application submitted        → the applicant (confirmation) + staff
//   · application withdrawn        → staff
//   · shortlist / reject / status  → the applicant (decision)
//   · interview / skills-exam / regret notice → the applicant
//   · new job posting published  → staff (admin + evaluators)
//   · new public sign-up           → admins
//   · sign-in locked / blocked external → admins (security)
//
// Functionality: unread badge (caps at 9+), 30s live poll + refetch on open,
// click-through navigation (marks the item read), "Mark all read". Works for
// EVERY signed-in role — targeted rows (user_id) and role broadcasts
// (audience) are resolved server-side per session.
// ============================================================================

import { useCallback, useEffect, useRef, useState } from "react";
import { useSession } from "@/components/session-provider";
import { useNav, type View } from "@/components/nav-provider";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { apiFetch } from "@/lib/client";
import {
  Bell,
  AlertTriangle,
  Briefcase,
  ClipboardList,
  CheckCircle2,
  XCircle,
  ArrowUpRight,
  Megaphone,
  UserPlus,
  Lock,
  ShieldAlert,
  CheckCheck,
  type LucideIcon,
} from "lucide-react";

type NotifItem = {
  id: number;
  type: string;
  title: string;
  body: string | null;
  linkView: string | null;
  linkParams: Record<string, string> | null;
  createdAt: string;
  read: boolean;
};

// Per-kind visual grammar — icon + tone block (token classes only).
const KIND_STYLE: Record<string, { icon: LucideIcon; tone: string }> = {
  APPLICATION_SUBMITTED: { icon: ClipboardList, tone: "border-primary/40 bg-primary/10 text-info-ink" },
  APPLICATION_WITHDRAWN: { icon: ArrowUpRight, tone: "border-warning/40 bg-warning/10 text-warning-ink" },
  APPLICATION_SHORTLISTED: { icon: CheckCircle2, tone: "border-success/40 bg-success/10 text-success-ink" },
  APPLICATION_REJECTED: { icon: XCircle, tone: "border-destructive/40 bg-destructive/10 text-danger-ink" },
  APPLICATION_STATUS_CHANGED: { icon: ClipboardList, tone: "border-info-ink/40 bg-info-ink/10 text-info-ink" },
  NOTICE_SENT: { icon: Megaphone, tone: "border-info-ink/40 bg-info-ink/10 text-info-ink" },
  JOB_POSTED: { icon: Briefcase, tone: "border-primary/40 bg-primary/10 text-info-ink" },
  USER_REGISTERED: { icon: UserPlus, tone: "border-primary/40 bg-primary/10 text-info-ink" },
  LOGIN_LOCKED: { icon: Lock, tone: "border-warning/40 bg-warning/10 text-warning-ink" },
  LOGIN_BLOCKED_EXTERNAL: { icon: ShieldAlert, tone: "border-destructive/40 bg-destructive/10 text-danger-ink" },
};

function kindStyle(type: string): { icon: LucideIcon; tone: string } {
  return KIND_STYLE[type] ?? { icon: AlertTriangle, tone: "border-border bg-secondary text-muted-foreground" };
}

// Compact relative timestamp: "just now" → "5m" → "3h" → "2d" → date.
function relativeTime(iso: string): string {
  const t = new Date(iso).getTime();
  if (isNaN(t)) return "";
  const diff = Date.now() - t;
  if (diff < 60_000) return "just now";
  const mins = Math.floor(diff / 60_000);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(iso).toLocaleDateString("en-PH", { month: "short", day: "numeric" });
}

export function NotificationCenter({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const { user } = useSession();
  const { navigate } = useNav();
  const [items, setItems] = useState<NotifItem[]>([]);
  const [unread, setUnread] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const signedIn = !!user;

  // Load the feed. Guarded against overlapping in-flight requests so the 30s
  // poll and the open-refetch can never stampede.
  const inFlight = useRef(false);
  const load = useCallback(() => {
    if (inFlight.current || !signedIn) return;
    inFlight.current = true;
    apiFetch<{ data: NotifItem[]; unread: number }>("/api/notifications")
      .then((r) => {
        setItems(r.data ?? []);
        setUnread(r.unread ?? 0);
        setLoaded(true);
      })
      .catch(() => {
        // Transient failure keeps the last good feed on screen.
      })
      .finally(() => {
        inFlight.current = false;
      });
  }, [signedIn]);

  // Realtime badge: fetch as soon as the session is known, then keep the feed
  // live with a 30s silent poll (visible tabs only). While signed out the
  // effect simply doesn't subscribe — the header isn't reachable then, and a
  // fresh session replaces the feed via load() + the open-refetch below.
  useEffect(() => {
    if (!signedIn) return;
    load();
    const timer = setInterval(() => {
      if (document.visibilityState === "visible") load();
    }, 30_000);
    return () => clearInterval(timer);
  }, [signedIn, load]);

  // Extra refetch each time the panel opens so the list is never stale.
  useEffect(() => {
    if (open && signedIn) load();
  }, [open, signedIn, load]);

  // Mark read — one item (on click, before navigating) or everything.
  const markRead = useCallback((ids?: number[]) => {
    apiFetch("/api/notifications/read", {
      method: "POST",
      body: JSON.stringify(ids ? { ids } : { all: true }),
    })
      .then(() => load())
      .catch(() => {});
  }, [load]);

  const openItem = useCallback(
    (n: NotifItem) => {
      if (!n.read) markRead([n.id]);
      if (n.linkView) {
        navigate(n.linkView as View, n.linkParams ?? undefined);
        onOpenChange(false);
      }
    },
    [markRead, navigate, onOpenChange],
  );

  const count = unread;

  return (
    <DropdownMenu open={open} onOpenChange={onOpenChange}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-foreground" aria-label={`Notifications${count > 0 ? ` — ${count} unread` : ""}`}>
          <Bell className="size-[18px]" />
          {count > 0 && (
            <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-destructive px-1 text-[10px] font-semibold text-[#e9ebdf] ring-2 ring-background">
              {count > 9 ? "9+" : count}
            </span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 max-w-[calc(100vw-1rem)] p-1">
        <DropdownMenuLabel className="flex items-center justify-between">
          <span className="font-semibold tracking-tight">Notifications</span>
          <span className="text-[11px] font-normal text-muted-foreground">
            {count > 0 ? `${count} unread` : "You're up to date"}
          </span>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {count > 0 && (
          <DropdownMenuItem
            onSelect={(e) => {
              e.preventDefault();
              markRead();
            }}
            className="gap-2 text-xs text-muted-foreground"
          >
            <CheckCheck className="size-3.5" /> Mark all as read
          </DropdownMenuItem>
        )}
        {!loaded ? (
          <div className="space-y-2 px-3 py-4" aria-hidden>
            {[0, 1, 2].map((i) => (
              <div key={i} className="flex items-start gap-3">
                <div className="size-8 shrink-0 animate-pulse bg-muted" />
                <div className="min-w-0 flex-1 space-y-1.5">
                  <div className="h-3.5 w-40 animate-pulse bg-muted" />
                  <div className="h-3 w-24 animate-pulse bg-muted" />
                </div>
              </div>
            ))}
          </div>
        ) : items.length === 0 ? (
          <div className="px-3 py-8 text-center">
            <span className="mx-auto mb-2 grid size-12 place-items-center rounded-none border border-border bg-secondary text-primary/60">
              <Bell className="size-5" />
            </span>
            <p className="text-sm font-medium text-foreground">No new notifications</p>
            <p className="mt-0.5 text-xs text-muted-foreground">
              Recruitment updates, decisions and security alerts will appear here.
            </p>
          </div>
        ) : (
          <div className="max-h-96 overflow-y-auto">
            {items.map((n) => {
              const { icon: Icon, tone } = kindStyle(n.type);
              const clickable = !!n.linkView;
              return (
                <button
                  key={n.id}
                  type="button"
                  onClick={() => openItem(n)}
                  className={`mx-1 my-0.5 flex w-[calc(100%-0.5rem)] items-start gap-3 rounded-xl px-3 py-2.5 text-left transition-colors ${
                    clickable ? "hover:bg-secondary" : "cursor-default"
                  } ${!n.read ? "bg-accent/40" : ""}`}
                >
                  <span className={`mt-0.5 grid size-8 shrink-0 place-items-center rounded-none border ${tone}`}>
                    <Icon className="size-3.5" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-baseline justify-between gap-2">
                      <span className="truncate text-sm font-medium tracking-tight text-foreground">{n.title}</span>
                      <span className="shrink-0 text-[10px] tabular-nums text-muted-foreground">
                        {relativeTime(n.createdAt)}
                      </span>
                    </span>
                    {n.body && <span className="mt-0.5 block text-xs leading-snug text-muted-foreground">{n.body}</span>}
                    {clickable && (
                      <span className="mt-1 inline-flex items-center gap-1 text-[11px] font-medium text-primary">
                        View <ArrowUpRight className="size-3" />
                      </span>
                    )}
                  </span>
                  {!n.read && <span aria-hidden className="mt-2 size-1.5 shrink-0 rounded-full bg-primary" />}
                </button>
              );
            })}
          </div>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
