"use client";

// ============================================================================
// CandidateProfileView — #/candidate-profile?id= — the standalone
// "Complete Profile" page.
//
// Navigated to IN-APP (same tab — exactly like opening a candidate from the
// kanban) via the candidate dossier's breadcrumb-row button ("Candidates /
// Maria Clara Santos · [Complete Profile]"). Renders a
// slim identity strip (back-to-dossier + who this ledger belongs to) followed
// by the EXACT CompleteProfileLedger the dossier shows — same eight read-only
// tabs (Overview / Education / Experience / Training / Eligibility / Awards /
// Documents / Applications) and the same Applications-row ReviewModal.
// Data: GET /api/admin/applicants/:id (both ADMIN and EVALUATOR pass).
// ============================================================================

import { useCallback, useEffect, useState } from "react";
import { useNav } from "@/components/nav-provider";
import { useRefetchOnFocus } from "@/hooks/use-refetch-on-focus";
import { apiFetch, fullName } from "@/lib/client";
import { humanizeName } from "@/lib/humanize";
import { ArrowLeft, ClipboardList } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Monogram, PageShell, Panel, initials } from "@/components/dash/kit";
import { CompleteProfileLedger } from "@/components/dash/views/candidate";
import {
  LoadError,
  type ApplicantDetail,
} from "@/components/dash/views/candidate-bits";

export function CandidateProfileView() {
  const { params, navigate } = useNav();
  const applicantId = params.id;

  const [data, setData] = useState<ApplicantDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(
    async (silent?: boolean) => {
      if (!applicantId) {
        setError("No applicant ID provided");
        setLoading(false);
        return;
      }
      // Silent (focus) refresh keeps the ledger current if a decision is
      // recorded in the dossier while this view is open.
      const isSilent = silent === true;
      if (!isSilent) {
        setLoading(true);
        setError(null);
      }
      try {
        const res = await apiFetch<ApplicantDetail>(
          `/api/admin/applicants/${applicantId}`
        );
        setData(res);
      } catch (e: unknown) {
        if (!isSilent) {
          setError(
            e instanceof Error ? e.message : "Failed to load applicant profile"
          );
        }
      } finally {
        setLoading(false);
      }
    },
    [applicantId]
  );

  useEffect(() => {
    load();
  }, [load]);

  // Realtime-lite: refresh when this tab regains focus.
  useRefetchOnFocus(() => load(true));

  if (loading) {
    return (
      <PageShell>
        <Panel className="flex items-center gap-4">
          <Skeleton className="size-12 shrink-0 rounded-full" />
          <div className="min-w-0 flex-1 space-y-2">
            <Skeleton className="h-5 w-56 max-w-full" />
            <Skeleton className="h-4 w-40 max-w-full" />
          </div>
        </Panel>
        <Panel className="mt-4 space-y-3">
          <Skeleton className="h-8 w-64 max-w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-44 w-full" />
        </Panel>
      </PageShell>
    );
  }

  if (error || !data) {
    return (
      <PageShell>
        <Panel flush>
          <LoadError
            message={error || "Applicant not found"}
            onRetry={() => void load()}
          />
        </Panel>
      </PageShell>
    );
  }

  const name = humanizeName(fullName(data) || "Unnamed Applicant");

  return (
    <PageShell>
      {/* Slim identity strip — back to the dossier + who this ledger is. */}
      <Panel>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() =>
              navigate("candidate", { id: String(applicantId ?? "") })
            }
            className="shrink-0"
          >
            <ArrowLeft className="size-4" />
            Dossier
          </Button>
          <Monogram label={initials(name)} size="md" className="shrink-0" />
          <div className="min-w-0 flex-1">
            <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">
              <ClipboardList className="size-3.5" aria-hidden />
              Complete Profile
            </p>
            <h1 className="truncate text-xl font-semibold tracking-tight text-foreground">
              {name}
            </h1>
          </div>
        </div>
      </Panel>

      {/* The exact full PDS ledger the dossier renders, on its own page. */}
      <CompleteProfileLedger data={data} onDecided={() => void load(true)} />
    </PageShell>
  );
}
