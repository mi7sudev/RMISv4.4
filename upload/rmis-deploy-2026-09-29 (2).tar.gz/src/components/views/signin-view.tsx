"use client";

import { useEffect, useState } from "react";
import { apiFetch, ApiError } from "@/lib/client";
import { useSession } from "@/components/session-provider";
import { useNav } from "@/components/nav-provider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { motion } from "motion/react";
import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { Reveal } from "@/components/ui/motion/reveal";
import { Loader2, Check, Eye, EyeOff, ArrowRight, LockKeyhole } from "lucide-react";
import { toast } from "sonner";
import { SiteHeader } from "@/components/site-header";
import { Footer } from "@/components/footer";

// ============================================================================
// Combined auth page — sign in AND create account on ONE page.
//
// The former separate #/signup page is folded in as a mode of this view:
//   · mode "signin" — identifier + password form (the original panel).
//   · mode "signup" — applicant registration (personal info, credentials,
//     RA 10173 consent) ported verbatim from the old SignUpView.
// The ONLY way to switch modes is the helper link at the bottom of the
// panel ("New to RMIS? Create an account" ⇄ "Already have an account?
// Sign in") — it flips in place, no navigation, and typed values survive
// the flip. Deep links still work:
// #/signin opens in sign-in mode, #/signup preselects create-account
// (the Router passes initialMode). Both modes share the brand editorial
// split (desktop-only) — the right column shows the SAME recruitment hero
// in both modes (unified per user feedback) — and the shared Footer.
// Production surface: no demo hints.
// ============================================================================

type AuthMode = "signin" | "signup";

/** Countdown label — "42s" under a minute, "1:05" beyond it. */
function formatCountdown(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  if (s < 60) return `${s}s`;
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

export function SignInView({ initialMode = "signin" }: { initialMode?: AuthMode }) {
  const { refresh } = useSession();
  const { navigate } = useNav();
  const reduced = useReducedMotion();
  const [mode, setMode] = useState<AuthMode>(initialMode);

  // ---- Sign-in state --------------------------------------------------------
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // ---- Progressive lockout (server-driven) ---------------------------------
  // After 3 failed attempts the server locks the identifier (30s first, then
  // 1m → 2m → 3m → 5m → 10m max on further failures). The 429 response
  // carries a structured retryAfter; the UI mirrors it with a countdown and
  // a disabled submit button. The SERVER is the source of truth — even if
  // the countdown is bypassed, locked requests are rejected server-side.
  const [lockUntil, setLockUntil] = useState<number | null>(null);
  const [lockLeft, setLockLeft] = useState(0);
  const locked = lockUntil !== null;

  useEffect(() => {
    if (lockUntil === null) return;
    const tick = () => {
      const left = Math.max(0, Math.ceil((lockUntil - Date.now()) / 1000));
      setLockLeft(left);
      if (left <= 0) setLockUntil(null);
    };
    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [lockUntil]);

  async function onSignIn(e: React.FormEvent) {
    e.preventDefault();
    if (!identifier || !password) {
      toast.error("Please enter your email/username and password");
      return;
    }
    setLoading(true);
    try {
      // apiFetch owns the error policy: network failures and 4xx/5xx all
      // arrive as user-safe Error messages (the login route always sets a
      // 4xx message, e.g. "Invalid credentials").
      const userData = await apiFetch<{ role: string }>("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ identifier, password }),
      });
      toast.success("Welcome to RMIS");
      await refresh();
      const role = userData?.role;
      if (role === "ADMIN") navigate("operations");
      else if (role === "EVALUATOR") navigate("review-queue");
      else navigate("home");
    } catch (e) {
      // 429 = the progressive lockout kicked in — mirror the server's
      // retryAfter with the inline notice + disabled button (no toast; the
      // panel itself communicates the lock). Other failures toast as usual.
      if (e instanceof ApiError && e.status === 429) {
        const retryAfter = Number(e.details?.retryAfter);
        if (Number.isFinite(retryAfter) && retryAfter > 0) {
          setLockUntil(Date.now() + retryAfter * 1000);
          setLockLeft(Math.ceil(retryAfter));
          return;
        }
      }
      toast.error(e instanceof Error ? e.message : "Sign in failed");
    } finally {
      setLoading(false);
    }
  }

  // ---- Create-account state (ported from the former SignUpView) -------------
  const [form, setForm] = useState({ firstName: "", lastName: "", email: "", password: "", confirm: "" });
  const [agreed, setAgreed] = useState(false);
  const [registering, setRegistering] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  function update(k: keyof typeof form, v: string) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function onSignUp(e: React.FormEvent) {
    e.preventDefault();
    if (!form.firstName || !form.lastName || !form.email || !form.password) {
      toast.error("Please fill in all required fields");
      return;
    }
    if (form.password.length < 10) {
      toast.error("Password must be at least 10 characters");
      return;
    }
    if (form.password !== form.confirm) {
      toast.error("Passwords do not match");
      return;
    }
    if (!agreed) {
      toast.error("Please accept the Privacy Notice to continue");
      return;
    }
    setRegistering(true);
    try {
      await apiFetch("/api/auth/register", {
        method: "POST",
        body: JSON.stringify(form),
      });
      // Auto-login. Deliberately tolerant: if it fails (e.g. session cookie
      // blocked), fall back to the sign-in mode on THIS page — the account
      // exists and the typed identifier carries over.
      try {
        await apiFetch("/api/auth/login", {
          method: "POST",
          body: JSON.stringify({ identifier: form.email, password: form.password }),
        });
      } catch {
        toast.success("Account created. Please sign in to continue.");
        setIdentifier(form.email);
        setPassword("");
        setMode("signin");
        return;
      }
      toast.success("Account created successfully");
      await refresh();
      navigate("profile");
    } catch (e) {
      // apiFetch never throws TypeError (network failures are folded into
      // user-safe Error messages), so no instanceof sniffing is needed.
      toast.error(e instanceof Error ? e.message : "Registration failed. Please try again.");
    } finally {
      setRegistering(false);
    }
  }

  const busy = loading || registering;

  return (
    <div className="flex min-h-dvh flex-col bg-background text-foreground">
      {/* Header — unified SiteHeader (same as frontpage + jobs board) */}
      <SiteHeader />

      {/* Main — split form / brand (form first — left on desktop, alone on
          mobile). The brand editorial is desktop-only: phones see the auth
          panel and the shared Footer, nothing else. The form column is
          proportional at lg with the panel centered inside it; the panel
          widens slightly in create-account mode to give the two-up name and
          password fields room to breathe. Hero type steps down mid-range —
          the longest display line measures ≈5.7em, so the stock 7vw clamp
          overflowed the brand column across the lg band (real horizontal
          scroll at 1024–1279px). */}
      <main className="flex flex-1 flex-col">
        <div className="mx-auto flex w-full max-w-[1400px] flex-1 flex-col 2xl:max-w-[1680px] lg:flex-row lg:px-8">
        {/* ===== Left — the auth panel (the only section on mobile) ===== */}
        <section className="flex w-full items-start justify-center px-4 pb-16 pt-10 sm:px-6 lg:w-[46%] lg:shrink-0 lg:items-center lg:border-r lg:px-0 lg:py-16 xl:w-[44%]">
          <motion.div
            initial={reduced ? false : { opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={reduced ? { duration: 0 } : { duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className={`w-full ${mode === "signup" ? "max-w-[500px]" : "max-w-[440px]"}`}
          >
            {/* Auth panel */}
            <div className="border border-border bg-card p-6 sm:p-8">
              <p className="kicker kicker-gold">{mode === "signin" ? "Sign in" : "Create account"}</p>
              <h2 className="heading-md mt-3 text-foreground">
                {mode === "signin" ? "Access your workspace" : "Create your applicant account"}
              </h2>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {mode === "signin"
                  ? "Use your RMIS credentials — email address or username."
                  : "Register to apply for positions at DOST-MIRDC and track your applications."}
              </p>

              {/* ===== Sign-in mode ===== */}
              {mode === "signin" ? (
                <form onSubmit={onSignIn} className="mt-8 space-y-5">
                  <Reveal delay={0.15} y={16}>
                    <div className="space-y-2">
                      <Label htmlFor="identifier">Email address or username</Label>
                      <Input
                        id="identifier"
                        type="text"
                        value={identifier}
                        onChange={(e) => setIdentifier(e.target.value)}
                        placeholder="juan.delacruz@example.com"
                        autoComplete="username"
                        required
                      />
                    </div>
                  </Reveal>
                  <Reveal delay={0.21} y={16}>
                    <div className="space-y-2">
                      <Label htmlFor="password">Password</Label>
                      <div className="relative">
                        <Input
                          id="password"
                          type={showPassword ? "text" : "password"}
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="Enter your password"
                          autoComplete="current-password"
                          required
                          className="pr-12"
                        />
                        {/* Show/hide toggle — ghost icon button */}
                        <button
                          type="button"
                          onClick={() => setShowPassword((v) => !v)}
                          aria-label={showPassword ? "Hide password" : "Show password"}
                          className="absolute inset-y-0 right-0 inline-flex size-12 items-center justify-center text-muted-foreground transition-colors hover:text-foreground"
                        >
                          {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                        </button>
                      </div>
                    </div>
                  </Reveal>
                  <Reveal delay={0.27} y={16}>
                    {/* Lockout notice — mirrors the server-imposed lockout with
                        a live countdown; the submit button below is disabled
                        until the server-side lock expires. */}
                    {locked && (
                      <div
                        role="alert"
                        aria-live="polite"
                        className="flex items-start gap-2.5 border border-border bg-secondary p-3 text-sm leading-relaxed text-muted-foreground"
                      >
                        <LockKeyhole className="mt-0.5 size-4 shrink-0 text-warning-ink" />
                        <span>
                          Too many failed attempts — sign-in is temporarily locked.
                          Try again in{" "}
                          <span className="font-medium tabular-nums text-foreground">
                            {formatCountdown(lockLeft)}
                          </span>
                          .
                        </span>
                      </div>
                    )}
                    <Button type="submit" size="lg" disabled={busy || locked} className="w-full">
                      {loading ? <Loader2 className="size-5 animate-spin" /> : null}
                      {!loading && locked ? <LockKeyhole className="size-4" /> : null}
                      {loading ? "Signing in…" : locked ? `Locked — retry in ${formatCountdown(lockLeft)}` : "Sign in"}
                      {!loading && !locked && <ArrowRight className="size-4" />}
                    </Button>
                  </Reveal>
                </form>
              ) : (
                /* ===== Create-account mode (ported from the former #/signup
                   page — same fields, validation and API contract) ===== */
                <form onSubmit={onSignUp} className="mt-8 space-y-5">
                  <Reveal delay={0.15} y={16}>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="firstName">
                          First name <span className="text-danger-ink">*</span>
                        </Label>
                        <Input id="firstName" value={form.firstName} onChange={(e) => update("firstName", e.target.value)} required placeholder="Juan" autoComplete="given-name" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName">
                          Last name <span className="text-danger-ink">*</span>
                        </Label>
                        <Input id="lastName" value={form.lastName} onChange={(e) => update("lastName", e.target.value)} required placeholder="Dela Cruz" autoComplete="family-name" />
                      </div>
                    </div>
                  </Reveal>
                  <Reveal delay={0.21} y={16}>
                    <div className="space-y-2">
                      <Label htmlFor="email">
                        Email address <span className="text-danger-ink">*</span>
                      </Label>
                      <Input id="email" type="email" value={form.email} onChange={(e) => update("email", e.target.value)} required placeholder="juan.delacruz@example.com" autoComplete="email" />
                    </div>
                  </Reveal>
                  <Reveal delay={0.27} y={16}>
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="new-password">
                          Password <span className="text-danger-ink">*</span>
                        </Label>
                        <div className="relative">
                          <Input
                            id="new-password"
                            type={showNewPassword ? "text" : "password"}
                            value={form.password}
                            onChange={(e) => update("password", e.target.value)}
                            required
                            placeholder="Min. 10 characters"
                            className="pr-10"
                            autoComplete="new-password"
                          />
                          <button
                            type="button"
                            onClick={() => setShowNewPassword((v) => !v)}
                            aria-label={showNewPassword ? "Hide password" : "Show password"}
                            className="absolute inset-y-0 right-0 inline-flex size-10 items-center justify-center text-muted-foreground transition-colors hover:text-foreground"
                          >
                            {showNewPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                          </button>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="confirm-password">
                          Confirm <span className="text-danger-ink">*</span>
                        </Label>
                        <div className="relative">
                          <Input
                            id="confirm-password"
                            type={showConfirm ? "text" : "password"}
                            value={form.confirm}
                            onChange={(e) => update("confirm", e.target.value)}
                            required
                            placeholder="Re-enter password"
                            className="pr-10"
                            autoComplete="new-password"
                          />
                          <button
                            type="button"
                            onClick={() => setShowConfirm((v) => !v)}
                            aria-label={showConfirm ? "Hide password" : "Show password"}
                            className="absolute inset-y-0 right-0 inline-flex size-10 items-center justify-center text-muted-foreground transition-colors hover:text-foreground"
                          >
                            {showConfirm ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                          </button>
                        </div>
                      </div>
                    </div>
                  </Reveal>
                  <Reveal delay={0.33} y={16}>
                    {/* Data privacy consent — notice + checkbox (RA 10173) */}
                    <div className="border border-border bg-secondary p-4">
                      <p className="kicker text-muted-foreground">Privacy notice · RA 10173</p>
                      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                        By registering, you consent to the collection, processing, and
                        storage of your personal data for recruitment purposes. Your
                        information will be handled confidentially and used solely for
                        evaluation of your application at DOST-MIRDC.
                      </p>
                    </div>
                    {/* Consent checkbox — sr-only native input inside the label, so the
                        WHOLE sentence is the tap target. The styled sharp square below
                        is purely visual, driven by `agreed`. */}
                    <label className="mt-3 flex cursor-pointer items-start gap-3 border border-border p-4 transition-colors hover:border-input-hover hover:bg-secondary">
                      <input
                        type="checkbox"
                        className="sr-only"
                        checked={agreed}
                        onChange={(e) => setAgreed(e.target.checked)}
                      />
                      <span
                        aria-hidden
                        className={`mt-0.5 flex size-5 shrink-0 items-center justify-center border transition-colors ${
                          agreed ? "border-primary bg-primary text-primary-foreground" : "border-input bg-transparent"
                        }`}
                      >
                        {agreed && <Check className="size-3.5" strokeWidth={3} />}
                      </span>
                      <span className="text-sm leading-relaxed text-foreground">
                        I have read and understand the Privacy Notice. I consent to the
                        processing of my personal data for recruitment purposes in
                        accordance with the Data Privacy Act of 2012.
                      </span>
                    </label>
                  </Reveal>
                  <Reveal delay={0.39} y={16}>
                    <Button type="submit" size="lg" disabled={busy} className="w-full">
                      {registering ? <Loader2 className="size-5 animate-spin" /> : null}
                      {registering ? "Creating account…" : "Create account"}
                      {!registering && <ArrowRight className="size-4" />}
                    </Button>
                  </Reveal>
                </form>
              )}

              {/* Footer helper — the ONLY mode switch: the bottom link is the
                  single path to the other mode (no toggle tabs above the
                  form); flips in place, no page navigation. */}
              <p className="mt-6 border-t border-border pt-5 text-sm text-muted-foreground">
                {mode === "signin" ? (
                  <>
                    New to RMIS?{" "}
                    <button onClick={() => setMode("signup")} className="font-medium text-primary transition-colors hover:text-brand-light">
                      Create an account
                    </button>
                  </>
                ) : (
                  <>
                    Already have an account?{" "}
                    <button onClick={() => setMode("signin")} className="font-medium text-primary transition-colors hover:text-brand-light">
                      Sign in
                    </button>
                  </>
                )}
              </p>
            </div>
          </motion.div>
        </section>

        {/* ===== Right — brand editorial (desktop only — hidden on mobile).
            UNIFIED per user feedback: both sign-in AND create-account show
            the same recruitment hero — no per-mode headline swap. ===== */}
        <section className="hidden flex-1 flex-col justify-between px-4 pb-12 pt-12 sm:px-6 sm:pt-16 lg:flex lg:pb-16 lg:pl-16 lg:pr-0 lg:pt-24 xl:pl-24">
          <div>
            <p className="kicker kicker-gold">RMIS — Recruitment portal</p>
            {/* lg override needs `!`: .display-hero is declared later in the
                utilities layer, so a plain responsive utility loses the tie.
                Longest line ≈ 5.68em → 6vw+0.5rem fits the brand column from
                1024px up (was 7vw → real horizontal overflow at lg). */}
            <h1 className="display-hero mt-6 text-foreground lg:text-[clamp(2.75rem,6vw+0.5rem,6.25rem)]!">
              Molding
              <br />
              the future
              <br />
              of metal
              <br />
              industries
            </h1>
          </div>

          {/* Sharp accent blocks — colour-blocking depth, sparingly */}
          <div aria-hidden className="mt-12 flex items-end gap-2">
            <div className="block-primary h-20 w-1.5" />
            <div className="block-gold size-3" />
            <div className="block-ink size-3" />
          </div>
        </section>

        </div>
      </main>

      {/* Footer — the shared theme-aware app footer (same as the jobs board
          and workspace shells): mt-auto pins it to the viewport bottom on
          short viewports and it pushes down naturally when the split grows. */}
      <Footer />
    </div>
  );
}
