"use client";

// ============================================================================
// apply-flow — shared "apply to a posting" flow hook, extracted from the jobs
// board's requestApply/doApply so the frontpage explorer and any other public
// surface can drive the SAME government apply gate without duplicating state:
//
//   1. Anonymous visitor          → info toast + redirect to sign-in.
//   2. Non-applicant session      → error toast (staff cannot apply).
//   3. Incomplete applicant       → "Finish Your Profile First" dialog (the
//                                    PDS fast-track was retired — the profile
//                                    PDS upload card still auto-fills).
//   4. Complete applicant         → Confirm dialog → MQR verification →
//                                    success toast, or the MQR failure panel.
//
// Render `dialogs` once alongside the calling view. Dialogs are the app's
// standard shadcn AlertDialogs (portal-mounted, theme-aware — consistent with
// the rest of the app, not the frontpage's fixed-light canvas).
// ============================================================================

import { useState } from "react";
import {
  AlertCircle,
  ArrowRight,
  Briefcase,
  CheckCircle2,
  ClipboardCheck,
  Loader2,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useSession } from "@/components/session-provider";
import { useNav } from "@/components/nav-provider";
import { apiFetch } from "@/lib/client";
import type { Job } from "@/lib/wire";

const MQR_LABELS: Record<string, string> = {
  education: "Education",
  workExperience: "Work Experience",
  training: "Training",
  eligibility: "Eligibility",
};

/** The job shape the flow needs — the wire Job satisfies it directly. */
export type ApplyFlowJob = Pick<Job, "id" | "title" | "position">;

type MqrFailure = { jobTitle: string; results: Record<string, string> };

export function useApplyFlow() {
  const { user, refresh: refreshSession } = useSession();
  const { navigate } = useNav();

  const [confirmJob, setConfirmJob] = useState<ApplyFlowJob | null>(null);
  const [profileRequiredJob, setProfileRequiredJob] = useState<ApplyFlowJob | null>(null);
  const [mqrFailure, setMqrFailure] = useState<MqrFailure | null>(null);
  const [applying, setApplying] = useState(false);

  /** Entry point — runs the government gate, then opens the right dialog. */
  function requestApply(job: ApplyFlowJob) {
    if (!user) {
      toast.info("Please sign in to apply");
      navigate("signin");
      return;
    }
    if (String(user.role) !== "APPLICANT") {
      toast.error("Only applicants can apply for positions");
      return;
    }
    // Government gate: applying requires a complete profile (enforced again
    // server-side). Incomplete applicants are asked to finish their profile
    // first — the PDS fast-track was retired (the profile's PDS upload card
    // still auto-fills). Job browsing stays open to all.
    if (user.applicant && !user.applicant.isProfileComplete) {
      setProfileRequiredJob(job);
      return;
    }
    setConfirmJob(job);
  }

  async function doApply(job: ApplyFlowJob) {
    // Safety net for a stale session: profile incomplete → finish-profile
    // dialog (and refresh the session so the next attempt sees the truth).
    if (user?.applicant && !user.applicant.isProfileComplete) {
      setProfileRequiredJob(job);
      refreshSession();
      return;
    }
    setApplying(true);
    try {
      const mqr = await apiFetch<{ mqrResults: Record<string, string>; allMet: boolean }>(
        "/api/jobs/verify-mqr",
        { method: "POST", body: JSON.stringify({ jobId: job.id }) }
      );
      if (!mqr.allMet) {
        setMqrFailure({
          jobTitle: job.position?.positionTitle || job.title || "this position",
          results: mqr.mqrResults,
        });
        return;
      }
      await apiFetch("/api/jobs/apply", {
        method: "POST",
        body: JSON.stringify({ jobId: job.id }),
      });
      toast.success("Application submitted successfully!");
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Failed to submit application.";
      // Fallback: the server still considers the profile incomplete →
      // finish-profile dialog (refresh the session — it may be stale).
      if (/complete your profile/i.test(msg)) {
        setProfileRequiredJob(job);
        refreshSession();
        return;
      }
      toast.error(msg);
    } finally {
      setApplying(false);
    }
  }

  const dialogs = (
    <>
      {/* ===== Apply Confirmation ===== */}
      <AlertDialog
        open={!!confirmJob}
        onOpenChange={(open) => {
          if (!open && !applying) setConfirmJob(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader className="shrink-0">
            <div className="flex items-start gap-3">
              <div className="grid size-10 shrink-0 place-items-center rounded-xl border border-border bg-secondary text-primary">
                <ClipboardCheck className="size-5" strokeWidth={1.5} />
              </div>
              <div className="min-w-0 flex-1">
                <AlertDialogTitle className="text-lg font-medium tracking-[-0.01em] text-foreground">
                  Confirm Application
                </AlertDialogTitle>
                <AlertDialogDescription className="mt-1 leading-relaxed">
                  You are about to submit your application. Please confirm to proceed.
                </AlertDialogDescription>
              </div>
            </div>
          </AlertDialogHeader>
          {confirmJob && (
            <div className="space-y-1.5 rounded-xl border border-border bg-secondary px-4 py-3">
              <div className="flex items-center gap-2">
                <Briefcase className="size-4 shrink-0 text-foreground" strokeWidth={1.5} />
                <p className="truncate text-sm font-medium text-foreground">
                  {confirmJob.position?.positionTitle || confirmJob.title || "Position Title Unavailable"}
                </p>
              </div>
              {confirmJob.position?.itemNumber && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span>Item</span>
                  <span>{confirmJob.position.itemNumber}</span>
                </div>
              )}
            </div>
          )}
          <AlertDialogFooter className="shrink-0">
            <AlertDialogCancel disabled={applying}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (confirmJob) void doApply(confirmJob);
                setConfirmJob(null);
              }}
              disabled={applying}
            >
              {applying && <Loader2 className="size-4 animate-spin" />}
              {applying ? "Submitting…" : "Yes, Submit"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ===== MQR Failure ===== */}
      <AlertDialog open={!!mqrFailure} onOpenChange={(open) => { if (!open) setMqrFailure(null); }}>
        <AlertDialogContent className="sm:max-w-lg">
          <AlertDialogHeader className="shrink-0">
            <div className="flex items-start gap-3">
              <div className="grid size-10 shrink-0 place-items-center rounded-xl border border-destructive/40 bg-destructive/10 text-destructive">
                <AlertCircle className="size-5" strokeWidth={1.5} />
              </div>
              <div className="min-w-0 flex-1">
                <AlertDialogTitle className="text-lg font-medium tracking-[-0.01em] text-foreground">
                  Requirements Not Met
                </AlertDialogTitle>
                <AlertDialogDescription className="mt-1 leading-relaxed">
                  You don&apos;t yet meet the Minimum Qualification Requirements for{" "}
                  <strong className="text-foreground">{mqrFailure?.jobTitle}</strong>. Please update
                  your profile.
                </AlertDialogDescription>
              </div>
            </div>
          </AlertDialogHeader>
          <div className="-mx-1 flex-1 overflow-y-auto px-1">
            <div className="space-y-2">
              {mqrFailure &&
                Object.entries(mqrFailure.results).map(([key, value]) => {
                  const isMet = value.includes("Meets");
                  const label = MQR_LABELS[key] || key;
                  const detail = isMet ? null : value.split(" — ")[1] || null;
                  return (
                    <div
                      key={key}
                      className={`flex items-start gap-2.5 rounded-lg border px-3.5 py-2.5 ${
                        isMet ? "border-border bg-secondary" : "border-destructive/40 bg-destructive/10"
                      }`}
                    >
                      {isMet ? (
                        <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-success" strokeWidth={1.5} />
                      ) : (
                        <XCircle className="mt-0.5 size-4 shrink-0 text-destructive" strokeWidth={1.5} />
                      )}
                      <div className="min-w-0 flex-1">
                        <p className={`text-xs font-semibold ${isMet ? "text-foreground" : "text-destructive"}`}>
                          {label}
                        </p>
                        <p className="mt-0.5 text-xs text-muted-foreground">
                          {isMet ? (
                            "Meets the minimum requirements"
                          ) : (
                            <>
                              Does not meet the minimum requirements
                              {detail && <span className="font-medium text-destructive"> — {detail}</span>}
                            </>
                          )}
                        </p>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
          <AlertDialogFooter className="shrink-0">
            <AlertDialogCancel>Close</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                setMqrFailure(null);
                navigate("profile");
              }}
            >
              Update Profile <ArrowRight className="size-4" />
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ===== Profile Incomplete (government apply gate) — the fast-track
           was retired; incomplete applicants finish their profile first. ===== */}
      <AlertDialog
        open={!!profileRequiredJob}
        onOpenChange={(open) => {
          if (!open) setProfileRequiredJob(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader className="shrink-0">
            <div className="flex items-start gap-3">
              <div className="grid size-10 shrink-0 place-items-center rounded-xl border border-border bg-secondary text-primary">
                <AlertCircle className="size-5" strokeWidth={1.5} />
              </div>
              <div className="min-w-0 flex-1">
                <AlertDialogTitle className="text-lg font-medium tracking-[-0.01em] text-foreground">
                  Finish Your Profile First
                </AlertDialogTitle>
                <AlertDialogDescription className="mt-1 leading-relaxed">
                  Government recruitment rule: your profile must be complete before you
                  can apply
                  {profileRequiredJob
                    ? ` for ${profileRequiredJob.position?.positionTitle || profileRequiredJob.title || "this position"}`
                    : ""}
                  . Use the PDS upload in your Profile — an Excel (.xlsx) PDS (CS Form
                  212) extracts best — or fill the sections manually, then come back to
                  apply.
                </AlertDialogDescription>
              </div>
            </div>
          </AlertDialogHeader>
          <AlertDialogFooter className="shrink-0">
            <AlertDialogCancel>Close</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                setProfileRequiredJob(null);
                navigate("profile");
              }}
            >
              Go to My Profile <ArrowRight className="size-4" />
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );

  return { requestApply, dialogs, applying };
}
