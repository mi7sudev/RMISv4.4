"use client";

// ============================================================================
// Tour — spotlight onboarding overlay (adapted from the Devsloka tour,
// hardened for RMIS):
//
//   · The spotlight is a fixed cutout div with a huge box-shadow (the
//     classic technique) instead of a clip-path polygon — and it ANIMATES
//     between steps and FOLLOWS the target while the page scrolls. The
//     original computed getBoundingClientRect() at render time only, so the
//     cutout drifted away from the target on any scroll.
//   · NO target DOM mutation. The original set position:relative + zIndex:60
//     on the target, which silently fails inside framer-motion stacking
//     contexts (RMIS uses Reveal/motion everywhere). Here the target is
//     revealed by the see-through center of the spotlight — nothing to trap.
//   · Scroll/resize tracked with CAPTURE-phase listeners + rAF throttle, so
//     nested scroll containers (application rails, ledger sheets) are covered.
//   · Keyboard: Esc closes, ←/→ navigate steps.
//   · Reduced motion → instant repositioning, no springs.
//   · Missing target (conditional UI not rendered) → full-dim fallback with
//     the card centered — the tour never dead-ends.
// ============================================================================

import * as React from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "motion/react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { cn } from "@/lib/utils";

export interface TourStep {
  /** CSS selector of the element to spotlight. Omit for a centered card. */
  target?: string;
  title: string;
  description: string;
  placement?: "top" | "bottom" | "left" | "right";
  offset?: { x?: number; y?: number };
}

export interface TourProps {
  steps: TourStep[];
  open: boolean;
  onClose?: () => void;
  onFinish?: () => void;
  className?: string;
  defaultPlacement?: TourStep["placement"];
}

const SPACING = 12; // gap between the spotlight ring and the card
const RING = 8; // spotlight padding around the target rect
const EDGE = 8; // minimum card margin to the viewport edge
const SPOT_SPREAD = 9999; // box-shadow spread — must exceed any viewport

type Rect = {
  top: number;
  left: number;
  width: number;
  height: number;
  bottom: number;
  right: number;
};

export function Tour({
  steps,
  open,
  onClose,
  onFinish,
  className,
  defaultPlacement = "bottom",
}: TourProps) {
  const reduced = useReducedMotion();
  const [mounted, setMounted] = React.useState(false);
  const [stepIndex, setStepIndex] = React.useState(0);
  const [targetRect, setTargetRect] = React.useState<Rect | null>(null);
  const [cardSize, setCardSize] = React.useState({ width: 340, height: 190 });
  const [position, setPosition] = React.useState<{ top: number; left: number } | null>(null);
  const cardRef = React.useRef<HTMLDivElement>(null);
  const rafRef = React.useRef<number | null>(null);

  const clampedIndex = Math.min(stepIndex, Math.max(0, steps.length - 1));
  const step = steps[clampedIndex];

  React.useEffect(() => setMounted(true), []);

  // Reset transient state whenever the tour closes.
  React.useEffect(() => {
    if (!open) {
      setStepIndex(0);
      setTargetRect(null);
      setPosition(null);
    }
  }, [open]);

  // ---- Spotlight: measure the current target --------------------------------
  const measure = React.useCallback(() => {
    if (!open) return;
    const el = step?.target ? (document.querySelector(step.target) as HTMLElement | null) : null;
    if (el) {
      const r = el.getBoundingClientRect();
      // A display:none element (responsive classes) reports a zero-area rect
      // at (0,0) — treat it as missing so the centered fallback engages
      // instead of cutting a spotlight hole into the viewport's corner.
      if (r.width === 0 || r.height === 0) {
        setTargetRect(null);
        return;
      }
      setTargetRect((prev) =>
        prev &&
        prev.top === r.top &&
        prev.left === r.left &&
        prev.width === r.width &&
        prev.height === r.height
          ? prev
          : {
              top: r.top,
              left: r.left,
              width: r.width,
              height: r.height,
              bottom: r.bottom,
              right: r.right,
            }
      );
    } else {
      setTargetRect(null);
    }
  }, [open, step]);

  // On open / step change — measure now and bring the target into view.
  React.useEffect(() => {
    if (!open) return;
    measure();
    const el = step?.target ? document.querySelector(step.target) : null;
    el?.scrollIntoView({
      behavior: reduced ? "auto" : "smooth",
      block: "center",
      inline: "nearest",
    });
  }, [open, step, measure, reduced]);

  // Follow the target through ANY scroll (capture phase catches nested
  // scroll containers) and through window resizes — rAF-throttled.
  React.useEffect(() => {
    if (!open) return;
    const schedule = () => {
      if (rafRef.current !== null) return;
      rafRef.current = window.requestAnimationFrame(() => {
        rafRef.current = null;
        measure();
      });
    };
    window.addEventListener("scroll", schedule, true);
    window.addEventListener("resize", schedule);
    return () => {
      window.removeEventListener("scroll", schedule, true);
      window.removeEventListener("resize", schedule);
      if (rafRef.current !== null) window.cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    };
  }, [open, measure]);

  // ---- Card: measure its rendered size (content-driven) ---------------------
  React.useLayoutEffect(() => {
    if (!open) return;
    const el = cardRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    setCardSize((prev) =>
      prev.width === r.width && prev.height === r.height ? prev : { width: r.width, height: r.height }
    );
  });

  // ---- Card: compute the anchored position ----------------------------------
  React.useLayoutEffect(() => {
    if (!open) return;
    const placement = step?.placement ?? defaultPlacement;
    const off = step?.offset ?? {};
    const vh = window.innerHeight;
    const vw = window.innerWidth;
    let top: number;
    let left: number;

    if (targetRect) {
      switch (placement) {
        case "top":
          top = targetRect.top - cardSize.height - SPACING + (off.y ?? 0);
          left = targetRect.left + (targetRect.width - cardSize.width) / 2 + (off.x ?? 0);
          break;
        case "left":
          top = targetRect.top + (targetRect.height - cardSize.height) / 2 + (off.y ?? 0);
          left = targetRect.left - cardSize.width - SPACING + (off.x ?? 0);
          break;
        case "right":
          top = targetRect.top + (targetRect.height - cardSize.height) / 2 + (off.y ?? 0);
          left = targetRect.right + SPACING + (off.x ?? 0);
          break;
        case "bottom":
        default:
          top = targetRect.bottom + SPACING + (off.y ?? 0);
          left = targetRect.left + (targetRect.width - cardSize.width) / 2 + (off.x ?? 0);
          break;
      }
    } else {
      // No target — centered fallback.
      top = (vh - cardSize.height) / 2;
      left = (vw - cardSize.width) / 2;
    }

    top = Math.max(EDGE, Math.min(vh - cardSize.height - EDGE, top));
    left = Math.max(EDGE, Math.min(vw - cardSize.width - EDGE, left));
    // Hard guarantee: never let a non-finite value reach style.top/left
    // (React dev mode logs `NaN is an invalid value` — and a NaN position
    // would render the card off-screen). Skip the frame instead.
    if (!Number.isFinite(top) || !Number.isFinite(left)) {
      setPosition(null);
      return;
    }
    setPosition((prev) => (prev && prev.top === top && prev.left === left ? prev : { top, left }));
  }, [open, step, targetRect, cardSize, defaultPlacement]);

  // ---- Navigation -----------------------------------------------------------
  const finishRef = React.useRef({ onClose, onFinish });
  React.useEffect(() => {
    finishRef.current = { onClose, onFinish };
  }, [onClose, onFinish]);

  const handleNext = React.useCallback(() => {
    if (clampedIndex >= steps.length - 1) {
      finishRef.current.onFinish?.();
      return;
    }
    setStepIndex(clampedIndex + 1);
  }, [clampedIndex, steps.length]);

  const handlePrev = React.useCallback(() => {
    setStepIndex((prev) => Math.max(0, Math.min(prev, steps.length - 1) - 1));
  }, [steps.length]);

  const handleClose = React.useCallback(() => {
    finishRef.current.onClose?.();
  }, []);

  // Keyboard: Esc closes, arrows navigate.
  React.useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        handleClose();
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        handleNext();
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        handlePrev();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, handleClose, handleNext, handlePrev]);

  if (!mounted || !step) return null;

  const arrowClass = cn(
    "absolute h-0 w-0 border-8 border-transparent",
    (step.placement ?? defaultPlacement) === "top" && "bottom-[-16px] left-1/2 -translate-x-1/2 border-t-card",
    (step.placement ?? defaultPlacement) === "bottom" && "top-[-16px] left-1/2 -translate-x-1/2 border-b-card",
    (step.placement ?? defaultPlacement) === "left" && "right-[-16px] top-1/2 -translate-y-1/2 border-l-card",
    (step.placement ?? defaultPlacement) === "right" && "left-[-16px] top-1/2 -translate-y-1/2 border-r-card"
  );

  const spring = reduced ? { duration: 0 } : { type: "spring" as const, damping: 30, stiffness: 380 };

  return createPortal(
    <AnimatePresence>
      {open && (
        <>
          {/* Click blocker — transparent, covers everything (header z-50 and
              modals included); the tour card is the only interactive surface. */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: reduced ? 0 : 0.2 }}
            className="fixed inset-0 z-[90]"
          />

          {/* Spotlight cutout — transparent center + huge box-shadow dims
              everything else; animates and follows the target on scroll. */}
          {targetRect ? (
            <motion.div
              aria-hidden
              /* Numeric initial top/left/width/height: motion springs an
                 unset `top: auto` computed style to NaN on first paint (the
                 console `NaN is an invalid value for top` warning). The
                 spotlight only mounts once targetRect exists, so seeding
                 initial from it always yields real numbers. */
              initial={{
                opacity: 0,
                top: targetRect.top - RING,
                left: targetRect.left - RING,
                width: targetRect.width + RING * 2,
                height: targetRect.height + RING * 2,
              }}
              animate={{
                opacity: 1,
                top: targetRect.top - RING,
                left: targetRect.left - RING,
                width: targetRect.width + RING * 2,
                height: targetRect.height + RING * 2,
              }}
              exit={{ opacity: 0 }}
              transition={spring}
              className="pointer-events-none fixed z-[95] rounded-[12px] ring-2 ring-primary/70"
              style={{ boxShadow: `0 0 0 ${SPOT_SPREAD}px rgba(0, 0, 0, 0.55)` }}
            />
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: reduced ? 0 : 0.2 }}
              className="fixed inset-0 z-[95] bg-black/55"
            />
          )}

          {/* Tour card */}
          <motion.div
            ref={cardRef}
            role="dialog"
            aria-modal="true"
            aria-label={step.title}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: reduced ? 0 : 0.22, ease: [0.22, 1, 0.36, 1] }}
            style={position ? { top: position.top, left: position.left } : { visibility: "hidden" }}
            className={cn(
              "fixed z-[100] w-[min(340px,calc(100vw-2rem))] rounded-[20px] border border-border bg-card shadow-lg",
              className
            )}
          >
            <div className={arrowClass} aria-hidden />
            <div className="flex items-center justify-between border-b border-border px-4 py-2.5">
              <span className="text-xs font-medium tabular-nums text-muted-foreground">
                Step {clampedIndex + 1} of {steps.length}
              </span>
              <Button
                variant="ghost"
                size="icon"
                className="size-7 rounded-lg"
                onClick={handleClose}
                aria-label="Close tour"
              >
                <X className="size-4" />
              </Button>
            </div>
            <div className="px-4 pb-4 pt-3.5">
              <h4 className="font-semibold leading-tight tracking-[-0.01em] text-foreground">
                {step.title}
              </h4>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {step.description}
              </p>
            </div>
            <div className="flex items-center justify-between border-t border-border px-4 py-3">
              <Button
                variant="outline"
                size="sm"
                onClick={handlePrev}
                disabled={clampedIndex === 0}
                className="h-8"
              >
                <ChevronLeft className="size-4" />
                Previous
              </Button>
              {/* progress dots */}
              <div className="flex items-center gap-1.5" aria-hidden>
                {steps.map((_, i) => (
                  <span
                    key={i}
                    className={cn(
                      "size-1.5 rounded-full transition-colors",
                      i === clampedIndex ? "bg-primary" : "bg-border"
                    )}
                  />
                ))}
              </div>
              <Button size="sm" onClick={handleNext} className="h-8">
                {clampedIndex === steps.length - 1 ? (
                  "Finish"
                ) : (
                  <>
                    Next
                    <ChevronRight className="size-4" />
                  </>
                )}
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>,
    document.body
  );
}
