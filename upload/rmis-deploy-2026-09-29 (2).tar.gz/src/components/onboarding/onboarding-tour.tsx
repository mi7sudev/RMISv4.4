"use client";

// ============================================================================
// OnboardingTour — auto-opens the <Tour> ONCE per user per surface.
//
// Gating contract ("new users after logging in"):
//   · Keyed per USER + per SURFACE in localStorage
//     (`rmis-onboarding-v1:<userId>:<tourKey>`), so a fresh account on a
//     shared office machine still gets its tour, while a returning user on
//     their own machine never sees it again.
//   · Dismissing the tour counts as done (X, Esc, or Finish) — it never
//     nags. Re-seeing a tour after a content update: bump STORAGE_VERSION.
//   · Waits until every step target is actually in the DOM (the workspace
//     views render skeletons while data loads) before opening; if a target
//     never appears, opens anyway after a cap — the Tour's centered
//     fallback keeps it graceful.
//   · Mounted inside a home view, so navigating away cancels cleanly (the
//     effect timer dies with the view) and the tour never opens over an
//     unrelated surface.
// ============================================================================

import { useCallback, useEffect, useRef, useState } from "react";
import { useSession } from "@/components/session-provider";
import { Tour, type TourStep } from "@/components/ui/tour";

const STORAGE_VERSION = "v1";
const TARGET_POLL_MS = 250;
const TARGET_WAIT_MAX_MS = 10_000;
const OPEN_DELAY_MS = 900; // let the view's entrance motion settle first

export function OnboardingTour({
  tourKey,
  steps,
  delayMs = OPEN_DELAY_MS,
}: {
  tourKey: string;
  steps: TourStep[];
  delayMs?: number;
}) {
  const { user } = useSession();
  const [open, setOpen] = useState(false);
  const stepsRef = useRef(steps);
  useEffect(() => {
    stepsRef.current = steps;
  }, [steps]);

  const userId = user?.id != null ? String(user.id) : null;
  const storageKey = userId ? `${STORAGE_VERSION}:${userId}:${tourKey}` : null;

  // Arm once per signed-in user + surface.
  useEffect(() => {
    if (!storageKey || stepsRef.current.length === 0) return;
    let seen = false;
    try {
      seen = window.localStorage.getItem(`rmis-onboarding-${storageKey}`) === "1";
    } catch {
      // Storage unavailable (private mode etc.) — tour simply shows each visit.
    }
    if (seen) return;

    const startedAt = Date.now();
    const poll = window.setInterval(() => {
      const stepsNow = stepsRef.current;
      const allPresent =
        stepsNow.length > 0 &&
        stepsNow.every((s) => !s.target || document.querySelector(s.target));
      if (allPresent || Date.now() - startedAt > TARGET_WAIT_MAX_MS) {
        window.clearInterval(poll);
        window.setTimeout(() => setOpen(true), delayMs);
      }
    }, TARGET_POLL_MS);
    return () => window.clearInterval(poll);
  }, [storageKey, delayMs]);

  // Any exit path (X, Esc, Finish) marks the tour as seen — never nag.
  const finish = useCallback(() => {
    setOpen(false);
    if (!storageKey) return;
    try {
      window.localStorage.setItem(`rmis-onboarding-${storageKey}`, "1");
    } catch {
      // Non-fatal — worst case the tour re-shows next visit.
    }
  }, [storageKey]);

  return <Tour steps={steps} open={open} onClose={finish} onFinish={finish} />;
}
