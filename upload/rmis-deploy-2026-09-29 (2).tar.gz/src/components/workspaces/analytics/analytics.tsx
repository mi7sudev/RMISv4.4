"use client";

// ============================================================================
// RMIS 2.0 — Analytics Workspace (ADMIN — the combined Insights page, #/analytics)
// A recruitment analytics PRODUCT — not "four metric cards + a pie chart".
//
// The former "Analytics" (pipeline health) and "Reports" (deep-dive) sidebar
// pages are merged into ONE admin page, top to bottom:
//   1. KPI band — Applications / Applicants / Active jobs / Shortlisted,
//      each with a quiet context sub-line (7-day intake, profile quality,
//      closing posts, pipeline share).
//   2. Pipeline funnel (2/3) — the SINGLE pipeline-composition view: stage
//      rows with conversion % + share bars, plus an overall-ratio footer
//      (shortlist rate · rejected · decided). Absorbs the two views it used
//      to be duplicated by (Pipeline Overview donut band + status chart).
//   3. Health rail (1/3) — Requirements match + Time in pipeline.
//   4. Pipeline by position (NEW, full width) — per-active-posting stage
//      distribution bar, application count, candidates-per-opening ratio and
//      closing date; coverage strip above (positions · openings ·
//      applications · per-opening). Click a row → job workspace.
//   5. Application volume — gradient area chart with a REAL 7/30/90-day
//      period filter, 7-day average overlay (30/90 windows) and avg/day +
//      peak-day captions.
//   6. Oldest pending applications (NEW, 2/3) — an aging ledger of the
//      applications waiting longest for a decision (oversight view: admin
//      monitors pace and can step in as the second/last reviewer) beside the
//      Recent activity audit feed (1/3, ADMIN only).
//
// The former "Drill-down candidates" stage-filter list was REMOVED — record
// browsing belongs to the Candidates workspace; this page keeps the metrics
// that lead back to records via deep links instead of duplicating a list.
//
// Visual register: dash-kit premium — PageShell/PageHeader frame, rounded-[20px]
// panels (hairline border + shadow-xs), tone-tinted icon chips, tabular
// figures, rounded-row hover lists, 150ms colour-only transitions. No
// editorial hero type, no gold kickers, no ghost numerals, no staggered
// entrances. Chart tokens untouched.
//
// API contracts preserved EXACTLY:
//   - GET /api/admin/stats          → useAdminStats (byStatus + recent + totals)
//   - GET /api/jobs?limit=200       → useJobs (active-posting table)
//   - GET /api/evaluator/queue      → Paginated<QueueItem> (funnel + volume +
//                                     position rows + aging ledger; admin allowed)
//   - GET /api/admin/audit-logs     → { data, total, actions, summary } (timeline,
//                                     ADMIN only — the feed is hidden for
//                                     evaluators rather than erroring)
// ============================================================================

import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import { useNav } from "@/components/nav-provider";
import { useSession } from "@/components/session-provider";
import {
  useAdminStats,
  useJobs,
  isJobActive,
  appCount,
  type JobRow,
} from "@/lib/hooks/use-admin-data";
import { apiFetch, formatDate, formatDateTime, fullName } from "@/lib/client";
import { useRefetchOnFocus } from "@/hooks/use-refetch-on-focus";
import { humanizeTitle, humanizeName } from "@/lib/humanize";
import { getActionMeta, ACTION_TONE_CLS } from "@/lib/audit-meta";
import {
  StatusIndicator,
  EmptyState,
  ErrorState,
} from "@/components/primitives/workspace";
import { stageForStatus, type Tone } from "@/lib/status";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
} from "recharts";
import {
  RefreshCw,
  TrendingUp,
  Activity as ActivityIcon,
  ArrowUpRight,
  ArrowRight,
  ChevronRight,
  Users,
  FileStack,
  Briefcase,
  UserCheck,
  Target,
  Hourglass,
  Clock3,
  Layers,
} from "lucide-react";
import type { Paginated } from "@/lib/validation";
import {
  PageShell,
  PageHeader,
  Panel,
  PanelHead,
  KpiTile,
  StageMeters,
  Sparkline,
  Dot,
  Monogram,
  Pill,
} from "@/components/dash/kit";
import { STAGE_TONE, type QueueItem as DashQueueItem } from "@/components/dash/views/queue-bits";
import { cn } from "@/lib/utils";

// ---------- Types ----------
// The queue payload is the same shape the Review Queue uses — reuse the dash
// QueueItem type so the match figures (which require `match`) are
// type-compatible with the single fetch below.
type QueueItem = DashQueueItem;

type AuditLogRow = {
  id: number;
  timestamp: string;
  user_id: string | null;
  user_label: string | null;
  user_role: string | null;
  action: string;
  entity_type: string | null;
  entity_id: string | null;
  description: string | null;
  ip_address: string | null;
};

type AuditResponse = {
  data: AuditLogRow[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
  actions: string[];
  summary: {
    totalEvents: number;
    onPage: number;
    topActions: { action: string; count: number }[];
    byRole: { role: string; count: number }[];
  };
};

// One active posting in the "Pipeline by position" table — the job plus its
// application counts split by funnel stage (computed from the queue).
type PositionRow = {
  job: JobRow;
  count: number;
  applied: number;
  review: number;
  shortlisted: number;
  rejected: number;
};

// Stage → segment colour for the position stage-distribution bar. Same tone
// grammar as the funnel dots (STAGE_TONE) expressed as bar fills.
const STAGE_BAR_CLS: Record<string, string> = {
  Applied: "bg-primary",
  "Under Review": "bg-info",
  Shortlisted: "bg-success",
  Rejected: "bg-danger",
};

// Friendly label for each stage in the conversion funnel.
function funnelLabel(stageKey: string): string {
  switch (stageKey) {
    case "Applied":
      return "Applied";
    case "Under Review":
      return "Under Review";
    case "Shortlisted":
      return "Shortlisted";
    case "Rejected":
      return "Rejected";
    default:
      return stageKey;
  }
}

// Convert an ISO date string to a YYYY-MM-DD key (for grouping by day).
function dayKey(iso: string): string {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  return d.toISOString().slice(0, 10);
}

// Whole days an application has been waiting since it was submitted.
function waitingDays(iso: string): number {
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return 0;
  return Math.max(0, Math.floor((Date.now() - t) / 86_400_000));
}

// Aging chip tone — quiet until it isn't: a week is a nudge, two weeks is a flag.
function waitTone(days: number): Tone {
  return days >= 14 ? "danger" : days >= 7 ? "warning" : "neutral";
}

// Typographic middot between row vitals — quiet punctuation, no icons.
function DotSep() {
  return <span aria-hidden className="select-none text-foreground/25">·</span>;
}

// ============================================================================
// MiniStat — one figure + uppercase label cell, used in the hairline-divided
// coverage strips (gap-px over a border background = enterprise table rule).
// ============================================================================

function MiniStat({ value, label }: { value: ReactNode; label: string }) {
  return (
    <div className="bg-card px-4 py-3">
      <p className="text-lg font-semibold leading-tight tabular-nums text-foreground">{value}</p>
      <p className="mt-0.5 truncate text-[11px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
        {label}
      </p>
    </div>
  );
}

// ============================================================================
// StageBar — stacked per-posting stage distribution (Applied/Under Review/
// Shortlisted/Rejected). Collapses to a muted track when there is no data.
// ============================================================================

function StageBar({ row }: { row: PositionRow }) {
  const segs = [
    { key: "Applied", value: row.applied },
    { key: "Under Review", value: row.review },
    { key: "Shortlisted", value: row.shortlisted },
    { key: "Rejected", value: row.rejected },
  ].filter((s) => s.value > 0);
  if (segs.length === 0 || row.count <= 0) {
    return <span aria-hidden className="block h-1.5 w-full rounded-full bg-muted" />;
  }
  return (
    <span
      role="img"
      aria-label={`${row.applied} applied, ${row.review} under review, ${row.shortlisted} shortlisted, ${row.rejected} rejected`}
      className="flex h-1.5 w-full overflow-hidden rounded-full bg-muted"
    >
      {segs.map((s) => (
        <span
          key={s.key}
          style={{ width: `${(s.value / row.count) * 100}%` }}
          className={cn("h-full", STAGE_BAR_CLS[s.key])}
        />
      ))}
    </span>
  );
}

export function AnalyticsWorkspace() {
  const { navigate } = useNav();
  const { user } = useSession();
  const isAdmin = !!user && String(user.role) === "ADMIN";
  const { stats, loading, error, reload: reloadStats } = useAdminStats();
  const { jobs, loading: jobsLoading, reload: reloadJobs } = useJobs();

  const [queue, setQueue] = useState<QueueItem[]>([]);
  const [queueLoading, setQueueLoading] = useState(true);
  const [queueError, setQueueError] = useState<string | null>(null);

  const [audit, setAudit] = useState<AuditLogRow[]>([]);
  const [auditLoading, setAuditLoading] = useState(true);
  const [auditError, setAuditError] = useState<string | null>(null);

  const [volumeDays, setVolumeDays] = useState<7 | 30 | 90>(30);
  const [reloadKey, setReloadKey] = useState(0);

  // ---- Fetch /api/evaluator/queue (admin-allowed) ----
  const loadQueue = useCallback(async (silent?: boolean) => {
    const isSilent = silent === true;
    if (!isSilent) {
      setQueueLoading(true);
      setQueueError(null);
    }
    try {
      const r = await apiFetch<Paginated<QueueItem> | QueueItem[]>(
        "/api/evaluator/queue?page=1&pageSize=100",
      );
      setQueue(Array.isArray(r) ? r : r.data ?? []);
    } catch (e) {
      // Silent refresh keeps the last good data on a transient failure.
      if (!isSilent) {
        setQueueError(
          e instanceof Error ? e.message : "Failed to load applications",
        );
      }
    } finally {
      setQueueLoading(false);
    }
  }, []);

  // ---- Fetch /api/admin/audit-logs (ADMIN only — evaluators have no audit
  // access, so the fetch is skipped rather than surfacing a 403 card) ----
  const loadAudit = useCallback(async (silent?: boolean) => {
    if (!isAdmin) {
      setAuditLoading(false);
      return;
    }
    const isSilent = silent === true;
    if (!isSilent) {
      setAuditLoading(true);
      setAuditError(null);
    }
    try {
      const r = await apiFetch<AuditResponse>(
        "/api/admin/audit-logs?page=1&pageSize=20",
      );
      setAudit(r.data ?? []);
    } catch (e) {
      if (!isSilent) {
        setAuditError(
          e instanceof Error ? e.message : "Failed to load activity feed",
        );
      }
    } finally {
      setAuditLoading(false);
    }
  }, [isAdmin]);

  useEffect(() => {
    loadQueue();
    loadAudit();
  }, [loadQueue, loadAudit, reloadKey]);

  // Realtime-lite: new applications and audit entries recorded elsewhere
  // (evaluator decisions, sign-ins) stream in without a manual reload.
  // Stats + jobs refresh themselves via their hooks' internal realtime wiring.
  useRefetchOnFocus(() => { void loadQueue(true); void loadAudit(true); }, { pollMs: 30_000 });

  const reload = useCallback(() => {
    reloadStats();
    reloadJobs();
    setReloadKey((k) => k + 1);
  }, [reloadStats, reloadJobs]);

  // ---- Pipeline funnel (4 stages — Applied · Under Review · Shortlisted ·
  // Rejected; the offline hand-off after the decision means the funnel ends
  // there). The single pipeline-composition view on this page. ----
  const funnel = useMemo(() => {
    const FUNNEL_STAGES = [
      "Applied",
      "Under Review",
      "Shortlisted",
      "Rejected",
    ] as const;
    const counts = FUNNEL_STAGES.map((key) => ({
      key,
      label: funnelLabel(key),
      count: queue.filter((q) => stageForStatus(q.status) === key).length,
    }));
    const max = Math.max(1, ...counts.map((c) => c.count));
    return { counts, max };
  }, [queue]);

  // ---- Overall funnel ratios — the footer strip under the stage rows ----
  const funnelRatios = useMemo(() => {
    const total = funnel.counts.reduce((s, c) => s + c.count, 0);
    if (total === 0) return null;
    const shortlisted = funnel.counts.find((c) => c.key === "Shortlisted")?.count ?? 0;
    const rejected = funnel.counts.find((c) => c.key === "Rejected")?.count ?? 0;
    return {
      shortlistRate: Math.round((shortlisted / total) * 100),
      rejectedRate: Math.round((rejected / total) * 100),
      decidedRate: Math.round(((shortlisted + rejected) / total) * 100),
    };
  }, [funnel]);

  // ---- Application volume (selectable window — 7 / 30 / 90 days; a REAL
  // period filter, not a decorative select) + 7-day moving average ----
  const volumeData = useMemo(() => {
    const now = Date.now();
    const days: { date: string; label: string; count: number; ma7: number }[] = [];
    for (let i = volumeDays - 1; i >= 0; i--) {
      const d = new Date(now - i * 86400000);
      const key = d.toISOString().slice(0, 10);
      days.push({
        date: key,
        label: d.toLocaleDateString("en-PH", {
          month: "short",
          day: "numeric",
        }),
        count: 0,
        ma7: 0,
      });
    }
    const byDate = new Map(days.map((d) => [d.date, d]));
    for (const q of queue) {
      const key = dayKey(q.dateApplied);
      const entry = byDate.get(key);
      if (entry) entry.count += 1;
    }
    // Trailing 7-day average (window clipped at the series start).
    for (let i = 0; i < days.length; i++) {
      const from = Math.max(0, i - 6);
      let sum = 0;
      for (let j = from; j <= i; j++) sum += days[j].count;
      days[i].ma7 = sum / (i - from + 1);
    }
    return days;
  }, [queue, volumeDays]);

  const volumeTotal = useMemo(
    () => volumeData.reduce((s, d) => s + d.count, 0),
    [volumeData],
  );
  const volumeAvg = volumeTotal / volumeDays;
  const volumePeak = useMemo(
    () =>
      volumeData.reduce<{ label: string; count: number } | null>(
        (best, d) => (d.count > (best?.count ?? 0) ? { label: d.label, count: d.count } : best),
        null,
      ),
    [volumeData],
  );

  // ---- Requirements match — average % + verdict mix (carried over from the
  // former Pipeline Overview band; same figures, new home in the side rail) ----
  const matchStats = useMemo(() => {
    let sum = 0;
    let n = 0;
    const verdicts = { met: 0, partial: 0, unmet: 0, review: 0 };
    for (const i of queue) {
      const m = i.match;
      if (!m || m.requiredCount <= 0) continue;
      sum += (m.metCount / m.requiredCount) * 100;
      n += 1;
      if (m.verdict === "ALL_MET") verdicts.met += 1;
      else if (m.verdict === "PARTIAL") verdicts.partial += 1;
      else if (m.verdict === "NONE_MET") verdicts.unmet += 1;
      else verdicts.review += 1;
    }
    return { avg: n ? Math.round(sum / n) : null, n, verdicts };
  }, [queue]);

  // ---- Time in pipeline — average days awaiting decision (undecided stages
  // only) + 14-day application volume sparkline ----
  const pipelineTime = useMemo(() => {
    let sum = 0;
    let n = 0;
    for (const i of queue) {
      const stage = stageForStatus(i.status || "");
      if (stage !== "Applied" && stage !== "Under Review") continue;
      const d = i.dateApplied ? new Date(i.dateApplied).getTime() : NaN;
      if (Number.isNaN(d)) continue;
      sum += Math.max(0, (Date.now() - d) / 86_400_000);
      n += 1;
    }
    return { avg: n ? Math.round(sum / n) : null, n };
  }, [queue]);

  const sparkVolume = useMemo(() => {
    const days = 14;
    const out = new Array<number>(days).fill(0);
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);
    for (const i of queue) {
      if (!i.dateApplied) continue;
      const d = new Date(i.dateApplied);
      if (Number.isNaN(d.getTime())) continue;
      d.setHours(0, 0, 0, 0);
      const diff = Math.round((startOfToday.getTime() - d.getTime()) / 86_400_000);
      if (diff >= 0 && diff < days) out[days - 1 - diff] += 1;
    }
    return out;
  }, [queue]);

  // ---- Pipeline by position — every ACTIVE posting with its application
  // counts split by stage (from the queue), ranked by volume ----
  const positionRows = useMemo<PositionRow[]>(() => {
    return jobs
      .filter(isJobActive)
      .map((job) => {
        const apps = queue.filter((q) => q.job?.id === job.id);
        const inStage = (key: string) =>
          apps.filter((a) => stageForStatus(a.status || "") === key).length;
        return {
          job,
          count: appCount(job) ?? apps.length,
          applied: inStage("Applied"),
          review: inStage("Under Review"),
          shortlisted: inStage("Shortlisted"),
          rejected: inStage("Rejected"),
        };
      })
      .sort((a, b) => b.count - a.count);
  }, [jobs, queue]);

  // Coverage summary for the strip above the position rows.
  const positionSummary = useMemo(() => {
    const positions = positionRows.length;
    const openings = positionRows.reduce((s, r) => s + (r.job.numberOfVacancy || 0), 0);
    const apps = positionRows.reduce((s, r) => s + r.count, 0);
    return {
      positions,
      openings,
      apps,
      perOpening: openings > 0 ? (apps / openings).toFixed(1) : null,
      quiet: positionRows.filter((r) => r.count === 0).length,
    };
  }, [positionRows]);

  // ---- Oldest pending applications — the aging ledger (oversight view):
  // undecided applications ordered by wait time, longest first ----
  const pendingApps = useMemo(
    () =>
      queue.filter((q) => {
        const s = stageForStatus(q.status || "");
        return s === "Applied" || s === "Under Review";
      }),
    [queue],
  );
  const agingList = useMemo(
    () =>
      [...pendingApps]
        .sort(
          (a, b) =>
            new Date(a.dateApplied).getTime() - new Date(b.dateApplied).getTime(),
        )
        .slice(0, 8),
    [pendingApps],
  );

  // Headline metrics (KPI tiles + toolbar count)
  const totalApps = queue.length;
  const totalShortlisted = queue.filter((q) => /shortlisted/i.test(q.status)).length;
  const shortlistedPct =
    totalApps > 0
      ? Math.round(((stats?.shortlisted ?? totalShortlisted) / totalApps) * 100)
      : 0;
  const newApps7d = useMemo(
    () =>
      queue.filter((q) => {
        const t = new Date(q.dateApplied).getTime();
        return !Number.isNaN(t) && Date.now() - t <= 7 * 86_400_000;
      }).length,
    [queue],
  );

  const pageError = error ?? queueError;

  const refreshButton = (
    <Button
      variant="outline"
      size="sm"
      className="h-8 rounded-lg text-xs"
      onClick={reload}
      disabled={loading}
    >
      <RefreshCw className={cn("size-3.5", loading && "animate-spin")} aria-hidden />
      Refresh
    </Button>
  );

  if (loading) {
    return (
      <PageShell>
        <PageHeader eyebrow="Insights" title="Analytics" actions={refreshButton} />
        <AnalyticsSkeleton />
      </PageShell>
    );
  }

  return (
    <PageShell>
      {/* ===== Page header — eyebrow + title + live chip + pipeline count. ===== */}
      <PageHeader
        eyebrow="Insights"
        title="Analytics"
        chip={
          <>
            <span aria-hidden className="relative flex size-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-success opacity-60" />
              <span className="relative inline-flex size-2 rounded-full bg-success" />
            </span>
            Live pipeline
          </>
        }
        chipTone="success"
        sub={`${totalApps} ${totalApps === 1 ? "application" : "applications"} across the recruitment pipeline`}
        actions={refreshButton}
      />

      {pageError && <ErrorState message={pageError} onRetry={reload} />}

      {/* ===== KPI band — headline totals as kit KpiTiles, each with a quiet
          context sub-line so the figures answer "compared to what?" ===== */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiTile
          icon={FileStack}
          tone="primary"
          label="Applications"
          value={stats?.totalApplications ?? totalApps}
          sub={`+${newApps7d} in the last 7 days`}
        />
        <KpiTile
          icon={Users}
          tone="neutral"
          label="Applicants"
          value={stats?.applicants ?? 0}
          sub={`${stats?.incompleteProfiles ?? 0} ${stats?.incompleteProfiles === 1 ? "profile" : "profiles"} incomplete`}
        />
        <KpiTile
          icon={Briefcase}
          tone="info"
          label="Active jobs"
          value={stats?.activeJobs ?? 0}
          sub={`${stats?.deadlinesThisWeek ?? 0} closing within 7 days`}
        />
        <KpiTile
          icon={UserCheck}
          tone="success"
          label="Shortlisted"
          value={stats?.shortlisted ?? totalShortlisted}
          sub={`${shortlistedPct}% of the pipeline`}
        />
      </div>

      {/* ===== FUNNEL + HEALTH RAIL — the funnel is the page's single
          pipeline-composition view (donut + status chart were its duplicates
          and are gone), now with an overall-ratio footer; Requirements match
          + Time in pipeline stack beside it. ===== */}
      <div className="grid grid-cols-1 gap-4 sm:gap-5 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
        {/* Pipeline funnel — composition ledger with conversion per stage and
            overall ratios in the footer strip. */}
        <Panel flush className="self-start overflow-hidden">
          <div className="flex items-center justify-between gap-3 border-b border-border px-4 py-3.5 sm:px-5">
            <h2 className="text-sm font-semibold text-foreground">Pipeline funnel</h2>
            <span className="shrink-0 text-xs font-medium tabular-nums text-muted-foreground">
              {totalApps} {totalApps === 1 ? "application" : "applications"} in pipeline
            </span>
          </div>
          {queueLoading ? (
            <div className="space-y-1 p-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="flex items-center gap-3 rounded-xl px-3 py-2.5">
                  <div className="size-2 shrink-0 animate-pulse rounded-full bg-muted" />
                  <div className="min-w-0 flex-1 space-y-1.5">
                    <div className="h-3.5 w-24 animate-pulse bg-muted" />
                    <div className="h-3 w-20 animate-pulse bg-muted" />
                  </div>
                  <div className="h-1.5 w-16 shrink-0 animate-pulse bg-muted sm:w-36" />
                </div>
              ))}
            </div>
          ) : funnel.counts.every((c) => c.count === 0) ? (
            <EmptyState
              icon={<TrendingUp className="size-8" />}
              title="No applications yet"
              description="Applications will appear here as candidates apply."
            />
          ) : (
            <>
              <div className="space-y-0.5 p-1.5 sm:p-2">
                {funnel.counts.map((stage, i) => {
                  const prev = i > 0 ? funnel.counts[i - 1] : null;
                  const conversion =
                    prev && prev.count > 0
                      ? Math.round((stage.count / prev.count) * 100)
                      : null;
                  const widthPct = (stage.count / funnel.max) * 100;
                  const tone = STAGE_TONE[stage.key];
                  return (
                    <div
                      key={stage.key}
                      className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5"
                    >
                      {/* Stage tone dot + label + quiet conversion note */}
                      <Dot tone={tone} className="shrink-0" />
                      <span className="min-w-0 flex-1">
                        <span className="block text-sm font-medium text-foreground">
                          {stage.label}
                        </span>
                        {conversion != null && (
                          <span className="mt-0.5 block text-xs text-muted-foreground">
                            {prev?.label} →{" "}
                            <span className="font-medium tabular-nums text-foreground">
                              {conversion}%
                            </span>
                          </span>
                        )}
                      </span>
                      {/* Stage count — plain figure, right-aligned */}
                      <span className="shrink-0 text-sm font-semibold tabular-nums text-foreground">
                        {stage.count}
                      </span>
                      {/* Share-of-pipeline bar — chart token fill */}
                      <span className="h-1.5 w-16 shrink-0 overflow-hidden rounded-full bg-muted sm:w-36">
                        <span
                          className="block h-full rounded-full"
                          style={{
                            width: `${Math.max(2, widthPct)}%`,
                            backgroundColor: "var(--chart-1)",
                          }}
                        />
                      </span>
                    </div>
                  );
                })}
              </div>
              {funnelRatios && (
                <div className="grid grid-cols-3 gap-px border-t border-border bg-border">
                  <MiniStat value={`${funnelRatios.shortlistRate}%`} label="Shortlist rate" />
                  <MiniStat value={`${funnelRatios.rejectedRate}%`} label="Rejected" />
                  <MiniStat value={`${funnelRatios.decidedRate}%`} label="Decided" />
                </div>
              )}
            </>
          )}
        </Panel>

        {/* Health rail — Requirements match + Time in pipeline */}
        <div className="grid content-start gap-4 sm:gap-5">
          <Panel className="flex flex-col">
            <PanelHead
              title={
                <span className="flex items-center gap-1.5">
                  <Target className="size-4 text-primary" aria-hidden />
                  Requirements match
                </span>
              }
              right={
                <span className="text-xs font-medium tabular-nums text-muted-foreground">
                  {matchStats.n} {matchStats.n === 1 ? "application" : "applications"}
                </span>
              }
            />
            <div className="flex items-baseline gap-2">
              <span className="text-[32px] font-semibold leading-none tabular-nums tracking-[-0.03em] text-foreground">
                {matchStats.avg ?? "—"}
              </span>
              <span className="text-sm font-medium text-muted-foreground">Out of 100</span>
            </div>
            {matchStats.n > 0 ? (
              <>
                <div
                  className="mt-4"
                  role="img"
                  aria-label={`${matchStats.verdicts.met} fully qualified, ${matchStats.verdicts.partial} partially met, ${matchStats.verdicts.unmet} unmet, ${matchStats.verdicts.review} need review`}
                >
                  <StageMeters
                    counts={[
                      { tone: "success", value: matchStats.verdicts.met },
                      { tone: "warning", value: matchStats.verdicts.partial },
                      { tone: "danger", value: matchStats.verdicts.unmet },
                    ]}
                  />
                </div>
                <p className="mt-2 text-xs text-muted-foreground">
                  {matchStats.verdicts.met} fully qualified
                  {matchStats.verdicts.partial > 0 && <> · {matchStats.verdicts.partial} partial</>}
                  {matchStats.verdicts.unmet > 0 && <> · {matchStats.verdicts.unmet} unmet</>}
                  {matchStats.verdicts.review > 0 && <> · {matchStats.verdicts.review} to verify</>}
                </p>
              </>
            ) : (
              <p className="mt-3 text-xs text-muted-foreground">No requirements data yet</p>
            )}
          </Panel>

          <Panel className="flex flex-col">
            <PanelHead
              title={
                <span className="flex items-center gap-1.5">
                  <Hourglass className="size-4 text-primary" aria-hidden />
                  Time in pipeline
                </span>
              }
              right={
                <span className="text-xs font-medium tabular-nums text-muted-foreground">
                  {pipelineTime.n} awaiting decision
                </span>
              }
            />
            <div className="flex items-baseline gap-2">
              <span className="text-[32px] font-semibold leading-none tabular-nums tracking-[-0.03em] text-foreground">
                {pipelineTime.avg ?? "—"}
              </span>
              <span className="text-sm font-medium text-muted-foreground">Days</span>
            </div>
            <div className="mt-auto pt-4">
              <Sparkline points={sparkVolume} />
              <p className="mt-1 text-[11px] text-muted-foreground/70">
                Applications received · last 14 days
              </p>
            </div>
          </Panel>
        </div>
      </div>

      {/* ===== PIPELINE BY POSITION — the enterprise per-posting table:
          coverage strip on top, then each active posting with its stage
          distribution, application count, candidates-per-opening ratio and
          closing date. Row click → job workspace. ===== */}
      <Panel flush className="overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-4 py-3.5 sm:px-5">
          <h2 className="flex items-center gap-1.5 text-sm font-semibold text-foreground">
            <Layers className="size-4 text-primary" aria-hidden />
            Pipeline by position
          </h2>
          <div className="flex shrink-0 items-center gap-3">
            {positionSummary.quiet > 0 && (
              <span className="hidden text-xs font-medium tabular-nums text-muted-foreground sm:inline">
                {positionSummary.quiet} active {positionSummary.quiet === 1 ? "position" : "positions"} with no applications
              </span>
            )}
            <Button
              variant="ghost"
              size="sm"
              className="h-7 rounded-lg px-2 text-xs text-muted-foreground"
              onClick={() => navigate("recruitment")}
            >
              View all <ArrowRight className="size-3.5" />
            </Button>
          </div>
        </div>
        {/* Coverage strip — hairline-divided summary cells */}
        <div className="grid grid-cols-2 gap-px border-b border-border bg-border sm:grid-cols-4">
          <MiniStat value={positionSummary.positions} label="Active positions" />
          <MiniStat value={positionSummary.openings} label="Openings" />
          <MiniStat value={positionSummary.apps} label="Applications" />
          <MiniStat
            value={positionSummary.perOpening ? `${positionSummary.perOpening}×` : "—"}
            label="Candidates per opening"
          />
        </div>
        {jobsLoading || queueLoading ? (
          <div className="space-y-1 p-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex items-center gap-4 rounded-xl px-3 py-2.5">
                <div className="min-w-0 flex-1 space-y-1.5">
                  <div className="h-3.5 w-44 animate-pulse bg-muted" />
                  <div className="h-3 w-32 max-w-full animate-pulse bg-muted" />
                </div>
                <div className="hidden h-1.5 w-40 shrink-0 animate-pulse bg-muted md:block" />
                <div className="hidden h-8 w-24 shrink-0 animate-pulse bg-muted sm:block" />
              </div>
            ))}
          </div>
        ) : positionRows.length === 0 ? (
          <EmptyState
            icon={<Briefcase className="size-8" />}
            title="No active positions"
            description="Publish a job posting to see its pipeline here."
          />
        ) : (
          <ul className="space-y-0.5 p-1.5 sm:p-2">
            {positionRows.slice(0, 6).map((row, i) => (
              <PositionRowItem key={row.job.id} row={row} index={i} />
            ))}
          </ul>
        )}
      </Panel>

      {/* ===== Application volume — REAL period filter; gradient area chart
          with a 7-day average overlay on the longer windows. ===== */}
      <Panel>
        <PanelHead
          title="Application volume"
          right={
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
              <span className="text-xs font-medium tabular-nums text-muted-foreground">
                {volumeTotal} in period
                {" · "}avg {volumeAvg.toFixed(1)}/day
                {volumePeak && volumePeak.count > 0 && (
                  <> · peak {volumePeak.count} on {volumePeak.label}</>
                )}
              </span>
              <Select
                value={String(volumeDays)}
                onValueChange={(v) => setVolumeDays(Number(v) as 7 | 30 | 90)}
              >
                <SelectTrigger className="h-8 w-32 rounded-lg text-xs" aria-label="Volume period">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">Last 7 days</SelectItem>
                  <SelectItem value="30">Last 30 days</SelectItem>
                  <SelectItem value="90">Last 90 days</SelectItem>
                </SelectContent>
              </Select>
            </div>
          }
        />
        {queueLoading ? (
          <div className="h-56 w-full animate-pulse bg-muted" />
        ) : volumeData.every((d) => d.count === 0) ? (
          <EmptyState
            icon={<TrendingUp className="size-8" />}
            title={`No applications in the last ${volumeDays} days`}
          />
        ) : (
          <ResponsiveContainer width="100%" height={280}>
            <ComposedChart
              data={volumeData}
              margin={{ top: 8, right: 16, left: 0, bottom: 0 }}
            >
              <defs>
                <linearGradient id="analyticsVolumeGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.28} />
                  <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="var(--border)"
                vertical={false}
              />
              <XAxis
                dataKey="label"
                stroke="var(--muted-foreground)"
                fontSize={11}
                tickLine={false}
                axisLine={false}
                interval={4}
              />
              <YAxis
                stroke="var(--muted-foreground)"
                fontSize={11}
                tickLine={false}
                axisLine={false}
                allowDecimals={false}
                width={28}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "var(--card)",
                  border: "1px solid var(--border)",
                  borderRadius: "12px",
                  fontSize: "12px",
                }}
                labelStyle={{ color: "var(--foreground)" }}
              />
              <Area
                type="monotone"
                dataKey="count"
                name="Applications"
                stroke="var(--chart-1)"
                strokeWidth={2}
                fill="url(#analyticsVolumeGradient)"
                dot={false}
                activeDot={{ r: 3 }}
              />
              {volumeDays >= 30 && (
                <Line
                  type="monotone"
                  dataKey="ma7"
                  name="7-day average"
                  stroke="var(--muted-foreground)"
                  strokeWidth={1.5}
                  strokeDasharray="4 3"
                  dot={false}
                />
              )}
            </ComposedChart>
          </ResponsiveContainer>
        )}
      </Panel>

      {/* ===== FOLLOW-THROUGH — the aging ledger (undecided applications,
          longest wait first — the oversight view for the second/last-pass
          reviewer) beside the Recent activity audit feed. The audit feed is
          ADMIN-only (the API is) — for evaluators the aging ledger takes the
          full width instead of a 403 error card. ===== */}
      <section
        className={cn(
          "grid grid-cols-1 gap-4 sm:gap-5",
          isAdmin && "lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]"
        )}
      >
        {/* Oldest pending applications — rows keep the navigate("candidate")
            interaction so a figure leads straight back to the record. */}
        <Panel flush className="flex max-h-[60vh] flex-col overflow-hidden lg:h-[65vh] lg:max-h-[65vh]">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-4 py-3.5 sm:px-5">
            <h2 className="flex items-center gap-1.5 text-sm font-semibold text-foreground">
              <Clock3 className="size-4 text-primary" aria-hidden />
              Oldest pending applications
            </h2>
            <span className="shrink-0 text-xs font-medium tabular-nums text-muted-foreground">
              {pendingApps.length} awaiting decision
            </span>
          </div>
          {queueLoading ? (
            <div className="min-h-0 flex-1 space-y-1 overflow-y-auto p-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="flex items-center gap-3 rounded-xl px-3 py-2.5">
                  <div className="size-9 shrink-0 animate-pulse rounded-full bg-muted" />
                  <div className="min-w-0 flex-1 space-y-1.5">
                    <div className="h-3.5 w-40 animate-pulse bg-muted" />
                    <div className="h-3 w-56 max-w-full animate-pulse bg-muted" />
                  </div>
                </div>
              ))}
            </div>
          ) : agingList.length === 0 ? (
            <div className="flex flex-1 items-center justify-center">
              <EmptyState
                icon={<Clock3 className="size-8" />}
                title="No pending applications"
                description="Every application has reached a decision."
              />
            </div>
          ) : (
            <ol className="min-h-0 flex-1 space-y-0.5 overflow-y-auto p-1.5 sm:p-2">
              {agingList.map((q) => {
                const days = waitingDays(q.dateApplied);
                return (
                  <li key={q.id}>
                    <button
                      onClick={() =>
                        q.applicant &&
                        navigate("candidate", {
                          id: String(q.applicant.id),
                        })
                      }
                      className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-colors duration-150 hover:bg-accent/60"
                    >
                      <Monogram label={applicantInitials(q.applicant)} size="sm" />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-medium text-foreground">
                          {humanizeName(applicantName(q.applicant))}
                        </span>
                        <span className="mt-0.5 block truncate text-xs text-muted-foreground">
                          {humanizeTitle(
                            q.job?.title ||
                              q.job?.position?.positionTitle ||
                              "Untitled position",
                          )}{" "}
                          <DotSep />{" "}
                          <span className="tabular-nums">
                            Applied {formatDate(q.dateApplied)}
                          </span>
                        </span>
                      </span>
                      <Pill tone={waitTone(days)} className="shrink-0">
                        {days === 0 ? "today" : `${days}d waiting`}
                      </Pill>
                      <span className="hidden shrink-0 sm:inline-flex">
                        <StatusIndicator status={q.status} size="sm" />
                      </span>
                      <ArrowUpRight className="size-4 shrink-0 text-foreground/30" />
                    </button>
                  </li>
                );
              })}
            </ol>
          )}
        </Panel>

        {/* Recent activity — action pills use the SAME friendly labels/tones
            as Settings → Audit Log via the shared audit-meta registry. */}
        {isAdmin && (
        <Panel flush className="flex max-h-[60vh] flex-col overflow-hidden lg:h-[65vh] lg:max-h-[65vh]">
          <div className="flex items-center justify-between gap-3 border-b border-border px-4 py-3.5 sm:px-5">
            <h2 className="text-sm font-semibold text-foreground">Recent activity</h2>
            <span className="shrink-0 text-xs font-medium tabular-nums text-muted-foreground">
              {audit.length} {audit.length === 1 ? "event" : "events"}
            </span>
          </div>
          {auditLoading ? (
            <div className="min-h-0 flex-1 divide-y divide-border overflow-y-auto">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="px-4 py-3.5 sm:px-5">
                  <div className="h-3.5 w-40 animate-pulse bg-muted" />
                  <div className="mt-2 h-3 w-24 animate-pulse bg-muted" />
                </div>
              ))}
            </div>
          ) : auditError ? (
            <div className="flex min-h-[120px] flex-1 items-center justify-center p-5">
              <p className="text-sm text-muted-foreground">{auditError}</p>
            </div>
          ) : audit.length === 0 ? (
            <div className="flex flex-1 items-center justify-center">
              <EmptyState
                icon={<ActivityIcon className="size-8" />}
                title="No recent activity"
              />
            </div>
          ) : (
            <ol className="min-h-0 flex-1 divide-y divide-border overflow-y-auto">
              {audit.map((log) => {
                // user_label is stored as "username (email)" — split it so the
                // actor reads on TWO stacked lines (name over email + time)
                // instead of one truncated line in the narrow rail. Display
                // parse only; the audit data and feed wiring are untouched.
                const actor = splitUserLabel(log.user_label || "System");
                return (
                  <li key={log.id} className="px-4 py-3.5 sm:px-5">
                    <span className="block truncate text-sm font-medium text-foreground">
                      {humanizeName(actor.name)}
                    </span>
                    <span className="mt-0.5 block truncate text-xs text-muted-foreground">
                      {actor.email && (
                        <>
                          {actor.email} <DotSep />{" "}
                        </>
                      )}
                      <span className="tabular-nums">
                        {formatDateTime(log.timestamp)}
                      </span>
                    </span>
                    <div className="mt-1.5 flex flex-wrap items-center gap-2">
                      <Badge
                        variant="outline"
                        className={`border text-xs font-medium ${
                          ACTION_TONE_CLS[getActionMeta(log.action).tone].bg
                        } ${
                          ACTION_TONE_CLS[getActionMeta(log.action).tone].text
                        }`}
                      >
                        {getActionMeta(log.action).label}
                      </Badge>
                      {log.user_role && (
                        <span className="text-xs font-medium uppercase tracking-[0.08em] text-muted-foreground">
                          {log.user_role}
                        </span>
                      )}
                    </div>
                    {log.description && (
                      <p className="mt-1 text-xs text-muted-foreground">
                        {log.description}
                      </p>
                    )}
                  </li>
                );
              })}
            </ol>
          )}
        </Panel>
        )}
      </section>
    </PageShell>
  );
}

// ============================================================================
// PositionRowItem — one active posting in the per-position table: rank,
// title + place/closes, stage distribution bar (md+), applications, and
// candidates-per-opening ratio. Click → job workspace.
// ============================================================================

function PositionRowItem({ row, index }: { row: PositionRow; index: number }) {
  const { navigate } = useNav();
  const title = row.job.title || row.job.position?.positionTitle || "Untitled position";
  const place = row.job.position?.placeOfAssignment?.name;
  const perOpening =
    row.job.numberOfVacancy > 0
      ? `${(row.count / row.job.numberOfVacancy).toFixed(1)}×`
      : "—";
  return (
    <li>
      <button
        onClick={() => navigate("job", { id: String(row.job.id) })}
        className="flex w-full items-center gap-4 rounded-xl px-3 py-2.5 text-left transition-colors duration-150 hover:bg-accent/60"
      >
        {/* Rank — quiet, desktop only */}
        <span
          aria-hidden
          className="hidden shrink-0 text-xs tabular-nums text-muted-foreground/60 sm:inline"
        >
          {String(index + 1).padStart(2, "0")}
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="truncate text-sm font-medium text-foreground">
            {humanizeTitle(title)}
          </h3>
          <p className="mt-0.5 truncate text-xs text-muted-foreground">
            {place || "—"}
            {row.job.deadlineDate && (
              <>
                {" "}
                <DotSep /> Closes {formatDate(row.job.deadlineDate)}
              </>
            )}
          </p>
        </div>
        {/* Stage distribution bar — md+ only */}
        <div className="hidden w-40 shrink-0 md:block">
          <StageBar row={row} />
        </div>
        {/* Applications + per-opening ratio */}
        <div className="hidden w-14 shrink-0 flex-col items-end sm:flex">
          <span className="text-sm font-semibold leading-none tabular-nums text-foreground">
            {row.count}
          </span>
          <span className="mt-1 text-[11px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
            Apps
          </span>
        </div>
        <div className="hidden w-16 shrink-0 flex-col items-end lg:flex">
          <span className="text-sm font-semibold leading-none tabular-nums text-foreground">
            {perOpening}
          </span>
          <span className="mt-1 text-[11px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
            Per post
          </span>
        </div>
        <ChevronRight aria-hidden className="size-4 shrink-0 text-muted-foreground/40" />
      </button>
    </li>
  );
}

// ---- Helpers --------------------------------------------------------------
// The audit DB stores user_label as "username (email)" (see src/lib/audit-db.ts)
// for quick display. Split into name + email for the stacked activity rows;
// strings without a "… (…)" tail pass through untouched.
function splitUserLabel(label: string): { name: string; email: string | null } {
  const m = label.match(/^(.*?)\s*\(([^)]+)\)\s*$/);
  if (!m || !m[1].trim()) return { name: label.trim(), email: null };
  return { name: m[1].trim(), email: m[2].trim() || null };
}

function applicantName(a: QueueItem["applicant"]): string {
  if (!a) return "Unknown applicant";
  return (
    fullName({ firstName: a.firstName, lastName: a.lastName }) || "Unnamed"
  );
}

function applicantInitials(a: QueueItem["applicant"]): string {
  if (!a) return "?";
  const f = (a.firstName || "").trim().charAt(0);
  const l = (a.lastName || "").trim().charAt(0);
  return (f + l).toUpperCase() || "?";
}

// ---- Skeleton (raw bg-muted pulse divs) — mirrors the premium layout:
// header + KPI tiles + funnel/health rail + position table + volume card +
// aging/activity ledgers. ----------------------------------------------------
function AnalyticsSkeleton() {
  return (
    <>
      {/* KPI tiles */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="flex items-center gap-3.5 rounded-[20px] border border-border/70 bg-card p-4 shadow-xs">
            <div className="size-10 shrink-0 animate-pulse rounded-xl bg-muted" />
            <div className="min-w-0 space-y-1.5">
              <div className="h-3 w-20 animate-pulse bg-muted" />
              <div className="h-5 w-12 animate-pulse bg-muted" />
              <div className="h-2.5 w-24 animate-pulse bg-muted" />
            </div>
          </div>
        ))}
      </div>
      {/* Funnel + health rail */}
      <div className="grid grid-cols-1 gap-4 sm:gap-5 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
        <div className="self-start overflow-hidden rounded-[20px] border border-border bg-card shadow-xs">
          <div className="border-b border-border px-4 py-3.5 sm:px-5">
            <div className="h-3.5 w-32 animate-pulse bg-muted" />
          </div>
          <div className="space-y-1 p-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 rounded-xl px-3 py-2.5">
                <div className="size-2 shrink-0 animate-pulse rounded-full bg-muted" />
                <div className="min-w-0 flex-1 space-y-1.5">
                  <div className="h-3.5 w-24 animate-pulse bg-muted" />
                  <div className="h-3 w-20 animate-pulse bg-muted" />
                </div>
                <div className="h-1.5 w-16 shrink-0 animate-pulse bg-muted sm:w-36" />
              </div>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-px border-t border-border bg-border">
            {[0, 1, 2].map((i) => (
              <div key={i} className="bg-card px-4 py-3">
                <div className="h-4 w-10 animate-pulse bg-muted" />
                <div className="mt-1.5 h-2.5 w-16 animate-pulse bg-muted" />
              </div>
            ))}
          </div>
        </div>
        <div className="grid content-start gap-4 sm:gap-5">
          {[0, 1].map((p) => (
            <div key={p} className="rounded-[20px] border border-border bg-card p-4 shadow-xs sm:p-5">
              <div className="h-4 w-32 animate-pulse bg-muted" />
              <div className="mt-4 h-9 w-24 animate-pulse bg-muted" />
              <div className="mt-4 h-3 w-full animate-pulse bg-muted" />
            </div>
          ))}
        </div>
      </div>
      {/* Position table */}
      <div className="overflow-hidden rounded-[20px] border border-border bg-card shadow-xs">
        <div className="flex items-center justify-between border-b border-border px-4 py-3.5 sm:px-5">
          <div className="h-3.5 w-40 animate-pulse bg-muted" />
          <div className="h-3 w-16 animate-pulse bg-muted" />
        </div>
        <div className="grid grid-cols-2 gap-px border-b border-border bg-border sm:grid-cols-4">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="bg-card px-4 py-3">
              <div className="h-4 w-10 animate-pulse bg-muted" />
              <div className="mt-1.5 h-2.5 w-20 animate-pulse bg-muted" />
            </div>
          ))}
        </div>
        <div className="space-y-1 p-2">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="flex items-center gap-4 rounded-xl px-3 py-2.5">
              <div className="min-w-0 flex-1 space-y-1.5">
                <div className="h-3.5 w-44 animate-pulse bg-muted" />
                <div className="h-3 w-32 max-w-full animate-pulse bg-muted" />
              </div>
              <div className="hidden h-1.5 w-40 shrink-0 animate-pulse bg-muted md:block" />
            </div>
          ))}
        </div>
      </div>
      {/* Volume card */}
      <div className="rounded-[20px] border border-border bg-card p-4 shadow-xs sm:p-5">
        <div className="h-4 w-36 animate-pulse bg-muted" />
        <div className="mt-4 h-56 w-full animate-pulse bg-muted" />
      </div>
      {/* Aging ledger + activity feed */}
      <div className="grid grid-cols-1 gap-4 sm:gap-5 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
        <div className="overflow-hidden rounded-[20px] border border-border bg-card shadow-xs">
          <div className="border-b border-border px-4 py-3.5 sm:px-5">
            <div className="h-3.5 w-44 animate-pulse bg-muted" />
          </div>
          <div className="space-y-1 p-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 rounded-xl px-3 py-2.5">
                <div className="size-9 shrink-0 animate-pulse rounded-full bg-muted" />
                <div className="min-w-0 flex-1 space-y-1.5">
                  <div className="h-3.5 w-40 animate-pulse bg-muted" />
                  <div className="h-3 w-56 max-w-full animate-pulse bg-muted" />
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="overflow-hidden rounded-[20px] border border-border bg-card shadow-xs">
          <div className="border-b border-border px-4 py-3.5 sm:px-5">
            <div className="h-3.5 w-28 animate-pulse bg-muted" />
          </div>
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="border-b border-border px-4 py-3.5 last:border-b-0 sm:px-5">
              <div className="h-3.5 w-40 animate-pulse bg-muted" />
              <div className="mt-2 h-3 w-24 animate-pulse bg-muted" />
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
