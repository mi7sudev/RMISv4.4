"use client";

// ============================================================================
// RMIS — Public landing, PORTED 1:1 from the previous RMIS
// (rmis-minimalist-prod · src/components/views/public-landing.tsx) so the
// frontpage keeps the exact same look: a two-pane job explorer in the
// reference-board style — LEFT: the register of rounded job cards
// (title · company · place · salary · clamped snippet · posted age · chevron
// quick-view + bookmark) which the PAGE scroll moves; RIGHT: the full posting
// pane (display title,
// verified company row + "View all jobs", icon meta rows, posted age,
// RMIS-blue Quick apply + soft-blue Save, description, Responsibilities /
// Qualifications / Compensation sections). The selected card carries the
// RMIS electric-blue ring (#1591DC, the old RMIS primary) and a deep-blue
// title. Mobile swaps panes (list → detail with back), and the card body is
// inert there — the chevron quick view's "Read full description" is the only
// path into the posting; on desktop the quick view drops that action because
// the right pane already IS the full description.
// Data from GET /api/jobs (30s silent poll + refetch on focus); visitors
// without a session are routed to sign-in by the shared apply gate; saves
// persist in localStorage.
//
// PORT ADAPTATIONS (data/API seam only — zero visual deltas):
//   * framer-motion → motion/react (the motion package's React entry).
//   * JobWire → the current wire `Job` (@/lib/wire): place of assignment is a
//     JOB-level field, the richtext aliases are dutiesResponsibilitiesHtml /
//     compensationPackageHtml, and the salary step column is positionSalaryStep.
//   * humanize → humanizeTitle (@/lib/humanize — proper-cases the ALL-CAPS
//     production titles, keeps Roman numerals + house acronyms).
//   * timeAgo / deadlineState → @/lib/time (ported from the minimalist client).
//   * navigate / view → the NavProvider seam; the apply gate → the shared
//     useApplyFlow hook (same sign-in gate, fast-track, MQR panel as the board).
//   * Footer → landing-local FrontpageFooter (the previous RMIS chrome). The
//     header is the UNIFIED SiteHeader — the exact same bar as the sign-in
//     page — and the page header uses the sign-in typography voice (gold
//     kicker → display-hero headline → quiet standfirst). Every custom class
//     is scoped under `.fp-root` in globals.css so the rest of the app is
//     untouched; .fp-root pins the app-theme tokens the shared header reads
//     to the light palette so the bar renders identically in both themes.
// ============================================================================

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import {
  AlertCircle,
  ArrowRight,
  BadgeCheck,
  Banknote,
  Bookmark,
  Briefcase,
  Building2,
  ChevronDown,
  ChevronLeft,
  Clock,
  Inbox,
  MapPin,
} from "lucide-react";
import { toast } from "sonner";
import { SiteHeader } from "@/components/site-header";
import { SafeHtml } from "@/components/common/safe-html";
import { FrontpageFooter } from "@/components/workspaces/public/frontpage-footer";
import { useApplyFlow } from "@/components/apply/apply-flow";
import { apiFetch, formatCurrency, formatDate } from "@/lib/client";
import { humanizeTitle } from "@/lib/humanize";
import { deadlineState, timeAgo } from "@/lib/time";
import { useNav } from "@/components/nav-provider";
import { useRefetchOnFocus } from "@/hooks/use-refetch-on-focus";
import type { Job } from "@/lib/wire";
import { cn } from "@/lib/utils";

// ── Reference-board accents ─────────────────────────────────────────────────

const RING_SELECTED = "border-transparent ring-2 ring-[#1591dc] shadow-e2";
const TITLE_SELECTED = "text-[#0e7abf] dark:text-[#5db6ec]";
const QUICK_APPLY_BTN =
  "focus-ring inline-flex min-h-[44px] items-center justify-center gap-2 rounded-[8px] bg-[#1591dc] px-6 text-sm font-semibold text-white transition-colors hover:bg-[#0e7abf] disabled:cursor-not-allowed disabled:opacity-50";
const SAVE_BTN =
  "focus-ring inline-flex min-h-[44px] items-center justify-center gap-2 rounded-[8px] bg-[#e9f5fc] px-7 text-sm font-semibold text-[#0e7abf] transition-colors hover:bg-[#d2ebfa] dark:bg-[#1591dc]/15 dark:text-[#7cc4ea] dark:hover:bg-[#1591dc]/25";

// ── Helpers ─────────────────────────────────────────────────────────────────

const PLACE_FALLBACK = "DOST Compound, Taguig";

/** Display place — job-level place of assignment, then the agency address. */
function jobPlace(job: Job): string {
  return job.placeOfAssignment?.name ?? PLACE_FALLBACK;
}

/** Posting age source — editorial publish date, else the record timestamp. */
function postedAt(job: Job): string | null {
  return job.publishDate ?? job.publishedAt;
}

const SAVED_KEY = "rmis-frontpage-saved-jobs";

/** Client-persisted bookmark list for the frontpage explorer. */
function useSavedJobs() {
  const [saved, setSaved] = useState<number[]>(() => {
    if (typeof window === "undefined") return [];
    try {
      const raw = window.localStorage.getItem(SAVED_KEY);
      const parsed = raw ? (JSON.parse(raw) as unknown) : [];
      return Array.isArray(parsed) ? parsed.filter((x): x is number => typeof x === "number") : [];
    } catch {
      return [];
    }
  });

  const toggle = useCallback((id: number) => {
    setSaved((prev) => {
      const next = prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id];
      try {
        window.localStorage.setItem(SAVED_KEY, JSON.stringify(next));
      } catch {
        /* storage unavailable — in-session state still works */
      }
      return next;
    });
  }, []);

  return { saved, toggle };
}

// ── Empty state (minimalist EmptyState, inlined — chip classes are scoped
//    under .fp-root in globals.css) ──────────────────────────────────────────

function EmptyState({
  icon: Icon,
  title,
  description,
}: {
  icon: typeof Inbox;
  title: string;
  description?: string;
}) {
  return (
    <div className="flex min-h-[176px] flex-col items-center justify-center px-6 py-10 text-center">
      <span className="chip chip-slate mb-4 grid h-14 w-14 place-items-center">
        <Icon className="h-6 w-6" aria-hidden="true" />
      </span>
      <p className="text-sm font-semibold text-ink">{title}</p>
      {description ? <p className="mt-1.5 max-w-sm text-[13px] leading-5 text-stone">{description}</p> : null}
    </div>
  );
}

// ── Quick-view cell (shared card expansion facts) ───────────────────────────

/** One definition-list cell of the quick view: micro-kicker label over a
 *  semibold tabular value. `danger` flags a passed deadline. */
function QuickFact({ label, value, danger }: { label: string; value: string; danger?: boolean }) {
  return (
    <div>
      <dt className="text-[11px] font-semibold uppercase tracking-[0.12em] text-pebble">{label}</dt>
      <dd
        className={cn(
          "num mt-1.5 break-words text-base font-semibold tracking-[-0.01em]",
          danger ? "text-[var(--bad)]" : "text-ink"
        )}
      >
        {value}
      </dd>
    </div>
  );
}

// ── Job card (left register) ────────────────────────────────────────────────

function JobListCard({
  job,
  selected,
  expanded,
  saved,
  desktop,
  onSelect,
  onToggle,
  onSave,
}: {
  job: Job;
  selected: boolean;
  expanded: boolean;
  saved: boolean;
  /** True on lg+ — the card body selects into the right pane and the quick
   *  view drops the "Read full description" action (the pane IS the full
   *  description). False on mobile — the body is inert and the quick view's
   *  action is the only way into the posting. */
  desktop: boolean;
  onSelect: () => void;
  onToggle: () => void;
  onSave: () => void;
}) {
  const reduced = useReducedMotion();
  const pos = job.position;
  const title = pos?.positionTitle || job.title || "Position Title Unavailable";
  const company = pos?.division || "DOST-MIRDC";
  const salary = pos?.salaryAmount ?? null;
  const deadline = job.deadlineDate;
  const overdue = deadline ? new Date(deadline).getTime() < Date.now() : false;

  // Card summary — shared by the desktop select-target button and the mobile
  // inert body (see the select target below).
  const summary = (
    <>
      <h3
        className={cn(
          "text-[17px] font-semibold leading-snug",
          selected ? TITLE_SELECTED : "text-ink"
        )}
      >
        {humanizeTitle(title)}
      </h3>
      <p className="mt-1 text-[15px] text-ink">{company}</p>
      <p className="mt-2.5 text-sm text-stone">{jobPlace(job)}</p>
      {salary != null && <p className="num mt-0.5 text-sm text-stone">{formatCurrency(salary)} per month</p>}
      {job.briefDescription && (
        <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-stone">{job.briefDescription}</p>
      )}
    </>
  );

  return (
    <article
      className={cn(
        "rounded-[12px] border bg-card transition-colors",
        selected ? RING_SELECTED : "border-black/[0.08] hover:border-black/[0.16] dark:border-white/10 dark:hover:border-white/20"
      )}
    >
      {/* Select target — desktop only: the summary picks the posting into
          the right pane. Mobile keeps the body inert so the chevron quick
          view + its "Read full description" action is the ONLY path into
          the full posting. */}
      {desktop ? (
        <button
          type="button"
          onClick={onSelect}
          aria-current={selected ? "true" : undefined}
          aria-label={`View ${humanizeTitle(title)}`}
          className="focus-ring block w-full px-4 pt-4 text-left sm:px-5 sm:pt-5"
        >
          {summary}
        </button>
      ) : (
        <div className="block w-full px-4 pt-4 text-left sm:px-5 sm:pt-5">{summary}</div>
      )}

      {/* Bottom register — posted age left, quick-view + bookmark right */}
      <div className="flex items-center justify-between gap-2 px-2.5 pb-2 sm:px-3.5">
        {desktop ? (
          <button
            type="button"
            onClick={onSelect}
            className="focus-ring num rounded-full px-2 py-1.5 text-xs text-pebble transition-colors hover:text-stone"
            aria-label={`Open ${humanizeTitle(title)}`}
          >
            {timeAgo(postedAt(job))}
          </button>
        ) : (
          <span className="num px-2 py-1.5 text-xs text-pebble">{timeAgo(postedAt(job))}</span>
        )}
        <div className="flex items-center">
          <button
            type="button"
            onClick={onToggle}
            aria-expanded={expanded}
            aria-label={expanded ? `Collapse — ${humanizeTitle(title)}` : `Quick view — ${humanizeTitle(title)}`}
            className="focus-ring grid h-9 w-9 place-items-center rounded-full text-stone transition-colors hover:bg-fog hover:text-ink"
          >
            <ChevronDown
              className={cn("h-[18px] w-[18px] transition-transform duration-200", expanded && "rotate-180")}
            />
          </button>
          <button
            type="button"
            onClick={onSave}
            aria-pressed={saved}
            aria-label={saved ? `Remove ${humanizeTitle(title)} from saved` : `Save ${humanizeTitle(title)}`}
            className="focus-ring grid h-9 w-9 place-items-center rounded-full text-stone transition-colors hover:bg-fog hover:text-ink"
          >
            <Bookmark className={cn("h-[18px] w-[18px]", saved && "fill-current text-[#0e7abf] dark:text-[#5db6ec]")} />
          </button>
        </div>
      </div>

      {/* Quick view — inline expansion with the house ease (reduced-motion
          users get a plain opacity crossfade). */}
      <AnimatePresence initial={false}>
        {expanded && (
          <motion.div
            key="quickview"
            initial={reduced ? { opacity: 0 } : { height: 0, opacity: 0 }}
            animate={reduced ? { opacity: 1 } : { height: "auto", opacity: 1 }}
            exit={reduced ? { opacity: 0 } : { height: 0, opacity: 0 }}
            transition={
              reduced
                ? { duration: 0.15, ease: "linear" }
                : { duration: 0.34, ease: [0.22, 1, 0.36, 1] }
            }
            className="overflow-hidden"
          >
            <div className="border-t border-black/[0.06] px-4 pb-6 pt-4 sm:px-5 sm:pt-5 dark:border-white/[0.08]">
              {job.briefDescription && (
                <div>
                  <h4 className="font-display text-lg text-ink">Job description</h4>
                  <p className="mt-2 line-clamp-5 text-sm leading-relaxed text-stone">
                    {job.briefDescription}
                  </p>
                </div>
              )}
              {/* 3-up everywhere — a 6-up row wraps currency mid-number. */}
              <dl className="mt-6 grid grid-cols-2 gap-x-6 gap-y-5 sm:grid-cols-3 sm:gap-x-8">
                <QuickFact label="Item No." value={pos?.itemNumber ?? "—"} />
                <QuickFact label="Vacancies" value={String(job.numberOfVacancy ?? "—")} />
                <QuickFact
                  label="Salary Grade"
                  value={
                    pos?.salaryGrade
                      ? `SG ${pos.salaryGrade}${pos.positionSalaryStep ? `/${pos.positionSalaryStep}` : ""}`
                      : "—"
                  }
                />
                <QuickFact label="Monthly Salary" value={salary != null ? formatCurrency(salary) : "—"} />
                <QuickFact label="Published" value={formatDate(job.publishDate)} />
                <QuickFact label="Deadline" value={formatDate(deadline)} danger={overdue} />
              </dl>
              {/* Action row — MOBILE only: "Read full description" is the
                  sole path into the posting (the card body is inert).
                  Desktop drops the action — the right pane IS the full
                  description — and keeps only the deadline warning. */}
              {(!desktop || overdue) && (
                <div className="mt-6 flex flex-wrap items-center gap-3">
                  {!desktop && (
                    <button
                      type="button"
                      onClick={onSelect}
                      className="focus-ring group/link inline-flex min-h-[44px] items-center gap-3 text-sm font-medium text-ink transition-colors hover:text-[#0e7abf] dark:hover:text-[#5db6ec]"
                    >
                      Read full description
                      <span className="dlg-cta grid h-8 w-8 place-items-center">
                        <ArrowRight
                          className="h-4 w-4 transition-transform duration-200 group-hover/link:translate-x-0.5"
                          strokeWidth={2.5}
                          aria-hidden="true"
                        />
                      </span>
                    </button>
                  )}
                  {overdue && (
                    <span className="flex items-center gap-1.5 text-xs font-semibold text-[var(--bad)]">
                      <AlertCircle className="h-3.5 w-3.5" aria-hidden="true" /> Deadline passed
                    </span>
                  )}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </article>
  );
}

// ── Detail pane (right) ─────────────────────────────────────────────────────

/** Plain-text posting section rendered as a disc bullet list. */
function TextBullets({ text }: { text: string }) {
  const items = text
    .split(/\r?\n/)
    .map((l) => l.replace(/^[-•*]\s*/, "").trim())
    .filter(Boolean);
  if (items.length === 0) return null;
  return (
    <ul className="list-disc space-y-2 pl-5 text-[15px] leading-relaxed text-stone">
      {items.map((item, i) => (
        <li key={i}>{item}</li>
      ))}
    </ul>
  );
}

/** Posting section: sanitized rich HTML when present, else text bullets. */
function PostingSection({ title, html, text }: { title: string; html: string | null; text: string | null }) {
  if (html && html.trim()) {
    return (
      <section className="space-y-3">
        <h3 className="text-[17px] font-semibold text-ink">{title}</h3>
        {/* SafeHtml sanitizes at render time (defense in depth against stored XSS) */}
        <SafeHtml html={html} className="rich-text text-[15px] leading-relaxed text-stone" />
      </section>
    );
  }
  if (text && text.trim()) {
    return (
      <section className="space-y-3">
        <h3 className="text-[17px] font-semibold text-ink">{title}</h3>
        <TextBullets text={text} />
      </section>
    );
  }
  return null;
}

function JobDetail({
  job,
  saved,
  onApply,
  onSave,
  onBack,
}: {
  job: Job;
  saved: boolean;
  onApply: () => void;
  onSave: () => void;
  onBack: () => void;
}) {
  const { navigate } = useNav();
  const pos = job.position;
  const title = pos?.positionTitle || job.title || "Position Title Unavailable";
  const salary = pos?.salaryAmount ?? null;
  const deadline = job.deadlineDate;
  const overdue = deadline ? new Date(deadline).getTime() < Date.now() : false;

  const meta: { icon: typeof MapPin; label: string; num?: boolean; danger?: boolean }[] = [];
  if (job.position?.division) meta.push({ icon: Building2, label: job.position.division });
  if (job.positionType) meta.push({ icon: Briefcase, label: humanizeTitle(job.positionType) });
  if (salary != null)
    meta.push({
      icon: Banknote,
      label: `${formatCurrency(salary)} per month${
        pos?.salaryGrade ? ` · SG ${pos.salaryGrade}${pos.positionSalaryStep ? `/${pos.positionSalaryStep}` : ""}` : ""
      }`,
      num: true,
    });
  meta.push({
    icon: Clock,
    label: overdue ? "Closed — deadline passed" : deadline ? `Closes ${formatDate(deadline)}` : "Open until filled",
    num: !overdue && !deadline,
    danger: overdue,
  });

  return (
    <div>
      {/* Mobile — back to the register */}
      <button
        type="button"
        onClick={onBack}
        className="focus-ring mb-4 inline-flex items-center gap-1.5 text-sm font-medium text-[#0e7abf] lg:hidden dark:text-[#5db6ec]"
      >
        <ChevronLeft className="h-4 w-4" aria-hidden="true" /> Back to job list
      </button>

      <h2 className="text-[26px] font-semibold leading-tight tracking-[-0.01em] text-ink sm:text-[28px]">
        {humanizeTitle(title)}
      </h2>
      <div className="mt-2.5 flex flex-wrap items-center gap-x-2.5 gap-y-1.5">
        <span className="text-[15px] font-medium text-ink">DOST-MIRDC</span>
        <BadgeCheck className="h-[18px] w-[18px] shrink-0 text-stone" aria-label="Verified agency" />
        <button
          type="button"
          onClick={() => navigate("jobs")}
          className="focus-ring text-[15px] text-stone underline underline-offset-4 transition-colors hover:text-ink"
        >
          View all jobs
        </button>
      </div>

      <ul className="mt-4 space-y-2.5">
        <li className="flex items-start gap-2.5 text-[15px] text-stone">
          <MapPin className="mt-0.5 h-[18px] w-[18px] shrink-0 text-pebble" aria-hidden="true" />
          {jobPlace(job)}
        </li>
        {meta.map((m, i) => (
          <li
            key={i}
            className={cn(
              "flex items-start gap-2.5 text-[15px]",
              m.danger ? "font-semibold text-[var(--bad)]" : "text-stone"
            )}
          >
            <m.icon className="mt-0.5 h-[18px] w-[18px] shrink-0 text-pebble" aria-hidden="true" />
            <span className={cn(m.num && "num")}>{m.label}</span>
          </li>
        ))}
      </ul>

      <p className="num mt-4 text-sm text-stone">Posted {timeAgo(postedAt(job))}</p>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <button type="button" onClick={onApply} disabled={overdue} className={QUICK_APPLY_BTN}>
          Quick apply
        </button>
        <button
          type="button"
          onClick={onSave}
          aria-pressed={saved}
          className={SAVE_BTN}
        >
          <Bookmark className={cn("h-4 w-4", saved && "fill-current")} aria-hidden="true" />
          {saved ? "Saved" : "Save"}
        </button>
        {overdue && (
          <span className="flex items-center gap-1.5 text-xs font-semibold text-[var(--bad)]">
            <AlertCircle className="h-3.5 w-3.5" aria-hidden="true" /> Deadline passed
          </span>
        )}
      </div>

      {/* Posting body */}
      <div className="mt-8 space-y-8 border-t border-black/[0.06] pt-8 dark:border-white/[0.08]">
        {job.briefDescription &&
          job.briefDescription
            .split(/\n{2,}/)
            .filter((p) => p.trim())
            .map((p, i) => (
              <p key={i} className="text-[15px] leading-relaxed text-stone">
                {p}
              </p>
            ))}
        <PostingSection title="Responsibilities" html={job.dutiesResponsibilitiesHtml} text={job.dutiesResponsibilities} />
        <PostingSection
          title="Qualifications"
          html={job.otherQualificationsHtml}
          text={job.otherQualifications}
        />
        <PostingSection title="Compensation" html={job.compensationPackageHtml} text={job.compensationPackage} />
      </div>
    </div>
  );
}

// ── View ────────────────────────────────────────────────────────────────────

export function PublicLanding() {
  const { navigate } = useNav();
  const [jobs, setJobs] = useState<Job[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [isDesktop, setIsDesktop] = useState(
    // The landing only renders after the app's hydration gate (the Router
    // shows a skeleton until mounted), so a client-only lazy init is safe —
    // no SSR/hydration divergence.
    () => window.matchMedia("(min-width: 1024px)").matches
  );
  const lastJson = useRef("");
  const paneRef = useRef<HTMLDivElement>(null);
  const { saved, toggle: toggleSave } = useSavedJobs();
  // Shared apply gate — anonymous visitors get the sign-in prompt, complete
  // applicants get the confirm flow (same as the board), incomplete profiles
  // are sent to finish their profile first (the fast-track was retired).
  const { requestApply, dialogs } = useApplyFlow();

  const load = useCallback(async (silent: boolean) => {
    try {
      const data = await apiFetch<Job[]>("/api/jobs?limit=200");
      const json = JSON.stringify(data);
      if (!silent || json !== lastJson.current) {
        lastJson.current = json;
        setJobs(data);
      }
      setError(null);
    } catch (e) {
      if (!silent) setError(e instanceof Error ? e.message : "Failed to load positions");
    }
  }, []);

  // Mount load — deferred one microtask off the effect body so the fetch's
  // state updates never synchronously cascade inside the effect itself
  // (react-hooks/set-state-in-effect). Cancellation guards a fast unmount.
  useEffect(() => {
    let cancelled = false;
    queueMicrotask(() => {
      if (!cancelled) void load(false);
    });
    return () => {
      cancelled = true;
    };
  }, [load]);

  // Realtime-lite: newly published postings and deadline crossings stay
  // fresh without a manual reload — 30s silent poll + refetch on focus,
  // with the hook's overlap guard against stacked in-flight requests.
  useRefetchOnFocus(() => load(true), { pollMs: 30_000 });

  // Breakpoint sync — desktop keeps both panes; mobile swaps list ↔ detail.
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 1024px)");
    const onChange = () => setIsDesktop(mq.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  const openJobs = useMemo(
    () => (jobs ?? []).filter((j) => !deadlineState(j.deadlineDate).overdue),
    [jobs]
  );

  const selectedJob = useMemo(
    () => openJobs.find((j) => j.id === selectedId) ?? null,
    [openJobs, selectedId]
  );

  // Desktop opens with the first posting pre-selected (reference-board
  // behavior); a stale selection after a poll snaps back to the top card.
  // Render-phase state adjustment (react.dev "you might not need an effect")
  // — React re-renders immediately with the corrected value before commit.
  if (selectedId !== null && !openJobs.some((j) => j.id === selectedId)) {
    setSelectedId(openJobs[0]?.id ?? null);
  } else if (isDesktop && selectedId === null && openJobs.length > 0) {
    setSelectedId(openJobs[0].id);
  }

  // Reference-board behavior — a freshly picked posting opens from the top,
  // even when the previous posting was scrolled deep into its body.
  useEffect(() => {
    if (paneRef.current) paneRef.current.scrollTop = 0;
  }, [selectedId]);

  const select = useCallback(
    (id: number) => {
      setSelectedId(id);
      if (!window.matchMedia("(min-width: 1024px)").matches) {
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    },
    []
  );

  const saveAndToast = useCallback(
    (job: Job) => {
      const wasSaved = saved.includes(job.id);
      toggleSave(job.id);
      toast.success(
        wasSaved
          ? "Removed from your saved jobs"
          : `Saved ${humanizeTitle(job.position?.positionTitle || job.title || "Position Title Unavailable")}`
      );
    },
    [saved, toggleSave]
  );

  const showList = isDesktop || selectedId === null;
  const showDetail = isDesktop || selectedId !== null;

  return (
    // Growable shell on lg (min-h-dvh, not a fixed h-dvh): the board flex-fills
    // the viewport when it is tall, but the register's minimum-height floors
    // (see the grid below) can push the page past the fold instead of squeezing
    // the positions list on wide-but-short desktop windows.
    <div className="fp-root flex min-h-screen flex-col bg-background text-ink lg:min-h-dvh">
      <SiteHeader />

      <main className="mx-auto w-full max-w-[1600px] flex-1 px-4 pb-10 pt-8 sm:px-6 lg:flex lg:min-h-0 lg:flex-col lg:px-8">
        {/* Editorial page header — the sign-in page's type voice: gold kicker
            → display-hero headline → quiet standfirst, with the open-roles
            count set as a sharp tabular chip on the closing baseline. */}
        <div className="flex flex-wrap items-end justify-between gap-x-6 gap-y-4">
          <div className="min-w-0">
            <p className="kicker kicker-gold">MIRDC — Careers</p>
            <h1 className="display-hero mt-3 text-ink">Open positions</h1>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-stone sm:text-base">
              Current vacancies at the Metals Industry Research and Development
              Center. Review a posting, then apply with your RMIS profile.
            </p>
          </div>
          {openJobs.length > 0 && (
            <span className="num shrink-0 border border-divider bg-card px-3 py-1.5 text-xs font-medium text-stone">
              {openJobs.length} open
            </span>
          )}
        </div>

        {error !== null ? (
          <div className="mt-6 rounded-[12px] border border-dusty-rose/30 bg-dusty-rose/10 p-4">
            <p className="text-sm text-ink">{error}</p>
            <button
              onClick={() => void load(false)}
              className="mt-2 text-sm text-stone underline underline-offset-4"
            >
              Try again
            </button>
          </div>
        ) : jobs === null ? (
          <div className="mt-6 space-y-3.5" aria-hidden="true">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-28 animate-pulse rounded-[12px] bg-fog" />
            ))}
          </div>
        ) : openJobs.length === 0 ? (
          <div className="mt-6 rounded-[12px] border border-black/[0.08] bg-card dark:border-white/10">
            <EmptyState
              icon={Inbox}
              title="No open positions right now"
              description="Check back soon or explore the full board for upcoming announcements."
            />
            <div className="pb-8 text-center">
              <button
                onClick={() => navigate("jobs")}
                className="inline-flex min-h-[44px] items-center gap-2 text-sm text-stone underline underline-offset-4 hover:text-ink"
              >
                Go to the full positions board
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>
          </div>
        ) : (
          // STICKY BOARD — the register is a natural-height list: the PAGE
          // scroll is what moves the job cards (no inner scroll traps), while
          // the posting pane pins below the sticky header (lg:sticky top-24 —
          // the header condenses 84px → 64px once scrolled, so 96px always
          // clears it) and internally scrolls any posting taller than the
          // viewport (max-h leaves a 24px gutter above the fold). The pane no
          // longer stretches with the row (lg:items-start) — a stretched pane
          // is exactly as tall as its grid area, which leaves sticky zero
          // room to move. On short desktop windows the shell now grows with
          // the list instead of squeezing it, and the footer stays reachable
          // at the natural end of the page. Mobile keeps the pane swap.
          <div className="mt-5 grid gap-8 lg:min-h-0 lg:flex-1 lg:items-start lg:grid-cols-[minmax(340px,430px)_minmax(0,1fr)]">
            {/* Left · the register — the scrolling column. Natural height:
                the page scroll moves the cards while the posting stays put. */}
            {showList && (
              <div
                aria-label="Open positions list"
                className="space-y-3.5"
              >
                {openJobs.map((job) => (
                  <JobListCard
                    key={job.id}
                    job={job}
                    selected={selectedId === job.id}
                    expanded={expandedId === job.id}
                    saved={saved.includes(job.id)}
                    desktop={isDesktop}
                    onSelect={() => select(job.id)}
                    onToggle={() => setExpandedId(expandedId === job.id ? null : job.id)}
                    onSave={() => saveAndToast(job)}
                  />
                ))}
              </div>
            )}

            {/* Right · the posting — pinned while the page scrolls; a posting
                taller than the viewport scrolls inside this pane (Lenis yields
                to nested scrollers via allowNestedScroll). No overscroll
                containment: an exhausted pane hands scrolling back to the
                page so the cards keep moving. */}
            {showDetail && (
              <div
                ref={paneRef}
                className="scroll-thin lg:sticky lg:top-24 lg:max-h-[calc(100dvh-7.5rem)] lg:overflow-y-auto lg:pr-2"
              >
                {selectedJob ? (
                  <JobDetail
                    job={selectedJob}
                    saved={saved.includes(selectedJob.id)}
                    onApply={() => requestApply(selectedJob)}
                    onSave={() => saveAndToast(selectedJob)}
                    onBack={() => setSelectedId(null)}
                  />
                ) : (
                  <div className="rounded-[12px] border border-black/[0.08] bg-card dark:border-white/10">
                    <EmptyState
                      icon={Briefcase}
                      title="Select a position"
                      description="Choose a role from the list to read the full posting."
                    />
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </main>

      <FrontpageFooter />
      {/* Shared apply dialog (confirm / MQR / done), mounted once. */}
      {dialogs}
    </div>
  );
}

export default PublicLanding;
