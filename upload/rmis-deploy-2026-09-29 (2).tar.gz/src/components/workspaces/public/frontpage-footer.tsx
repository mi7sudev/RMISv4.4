"use client";

// ============================================================================
// FrontpageFooter — the PREVIOUS RMIS shell footer (ported 1:1 from
// rmis-minimalist-prod, which itself was ported from rmis-main-ui's Footer):
// hairline top rule, generous padding, and the GovPH seal anchored
// bottom-left as a 10%-opacity watermark BEHIND the footer contents
// (seal z-0, contents z-10). Sharp square icon chip in the electric-blue
// accent; muted stone ink for the note.
//
// Landing-local ON PURPOSE — the rest of the app keeps the current theme-aware
// Footer. Rendered as the last child of the min-h-screen flex column landing —
// `mt-auto` keeps it pinned to the bottom on short pages and pushed down
// naturally on long ones. DO NOT remove mt-auto / relative / overflow-hidden.
// ============================================================================

import Image from "next/image";
import { ShieldCheck } from "lucide-react";

export function FrontpageFooter() {
  return (
    <footer className="relative mt-auto overflow-hidden border-t border-divider/70 bg-card">
      {/* GovPH seal — bottom-left watermark behind the contents */}
      <div className="pointer-events-none absolute bottom-0 left-0 z-0 opacity-10">
        <Image
          src="/govph-seal-mono-footer.jpg"
          alt=""
          width={320}
          height={320}
          className="h-40 w-40 object-contain sm:h-56 sm:w-56"
          aria-hidden
        />
      </div>

      {/* Footer content — z-10 so it sits above the seal. max-w matches the
          frontpage's 1600px container so contents align with the page grid. */}
      {/* pb respects the iOS home-indicator safe area (viewportFit=cover). */}
      <div className="relative z-10 mx-auto w-full max-w-[1600px] px-4 py-8 pb-[max(2rem,env(safe-area-inset-bottom))] sm:px-6 sm:py-10 sm:pb-[max(2.5rem,env(safe-area-inset-bottom))] lg:px-8">
        <div className="flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:justify-between sm:gap-6">
          <div className="flex max-w-2xl items-start gap-3 text-xs leading-relaxed text-stone">
            {/* Icon chip — sharp square block */}
            <span className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-[4px] border border-divider bg-background text-[#1591dc]">
              <ShieldCheck className="size-4" />
            </span>
            <p>
              Protected under the Data Privacy Act of 2012 (RA 10173). Personal
              information is used solely for recruitment and is accessible only
              to authorized DOST-MIRDC personnel.
            </p>
          </div>
          <p className="shrink-0 text-xs font-semibold uppercase tracking-[0.08em] text-stone">
            © {new Date().getFullYear()} RMIS
          </p>
        </div>
      </div>
    </footer>
  );
}

export default FrontpageFooter;
