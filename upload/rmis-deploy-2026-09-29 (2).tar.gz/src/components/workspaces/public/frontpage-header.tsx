"use client";

// ============================================================================
// FrontpageHeader — the PREVIOUS RMIS public header (ported 1:1 from
// rmis-minimalist-prod's SiteHeader so the frontpage keeps its exact look):
// a full-width sticky enterprise bar anchored to the top edge — hairline
// bottom border, frosted glass, two-seal brand lockup left; Positions link +
// primary sign-in CTA right.
//
// Landing-local ON PURPOSE: the rest of the app (jobs board, auth, workspaces)
// keeps the current unified SiteHeader; only the frontpage wears this chrome.
// All custom classes here (glass / dlg-cta / dlg-ghost / focus-ring / ink)
// are defined scoped under `.fp-root` in globals.css.
// ============================================================================

import { useSession } from "@/components/session-provider";
import { BrandLogo } from "@/components/brand-logo";
import { useNav } from "@/components/nav-provider";
import { homeViewForRole } from "@/config/navigation";

export function FrontpageHeader() {
  const { navigate, view } = useNav();
  const { user } = useSession();
  const onSignInView = view === "signin";
  const onJobsView = view === "jobs";

  return (
    <header className="glass sticky top-0 z-40 border-b border-black/[0.07] shadow-e1">
      <div className="mx-auto flex h-16 w-full max-w-[1600px] items-center justify-between gap-3 px-4 sm:px-6 lg:px-8">
        {/* Brand */}
        <button
          onClick={() => navigate(user ? homeViewForRole(user.role) : "home")}
          className="focus-ring flex min-h-[44px] items-center gap-3"
          aria-label="RMIS home"
        >
          {/* Official two-logo lockup — DOST seal + MIRDC emblem. The emblems'
              art carries transparent backgrounds and floats on the header. */}
          <BrandLogo logoSize={34} />
          <span className="hidden text-lg font-semibold tracking-[-0.01em] text-ink sm:inline">
            RMIS
          </span>
        </button>

        {/* Right cluster */}
        <nav className="flex items-center gap-2" aria-label="Primary">
          {!onJobsView && (
            <button
              onClick={() => navigate("jobs")}
              className="dlg-ghost inline-flex min-h-[44px] items-center px-4 text-sm sm:px-5"
            >
              Positions
            </button>
          )}

          {user ? (
            <button
              onClick={() => navigate(homeViewForRole(user.role))}
              className="dlg-cta inline-flex min-h-[44px] items-center whitespace-nowrap px-6 text-sm"
            >
              Dashboard
            </button>
          ) : (
            !onSignInView && (
              <button
                onClick={() => navigate("signin")}
                className="dlg-cta inline-flex min-h-[44px] items-center whitespace-nowrap px-4 text-sm sm:px-6"
                aria-label="Sign in to RMIS"
              >
                Sign in
              </button>
            )
          )}
        </nav>
      </div>
    </header>
  );
}

export default FrontpageHeader;
