"use client";

// ============================================================================
// Admin Dashboard (#/operations — the role's home view).
//
// Renamed from "Command Center" → "Dashboard". A premium, enterprise staff
// landing page built from the shared dash kit (PageShell / PageHeader /
// Panel / tone-soft icon chips) so it reads as the same product family as
// Review Queue, Candidates and Analytics.
//
// Answers two questions and nothing else:
//   1. "What requires my attention?"  — Needs-attention band (4 tone tiles)
//   2. "What is happening right now?" — Active recruitment (2/3) + Latest
//      applications (1/3, internally scrolled) side by side.
//
// Attention cards render count + label ONLY — the explanatory hint lines
// under "Awaiting review" and "Failed logins (24h)" were removed on purpose:
// the shortlist-decision hint framed the admin as the PRIMARY reviewer
// (reviewing is the evaluators' job — admins are the second/last pass via
// the sidebar Review Queue), and the brute-force hint was security-team
// framing. The figures still deep-link to the surface that resolves them.
//
// The former "Quick actions" right rail is GONE — every destination it
// linked to is already one click away in the sidebar, so the rail was
// navigation debt, not a feature.
//
// Design language: dash-kit premium — rounded-[20px] panels with hairline
// borders + shadow-xs, tone-tinted icon chips, tabular figures, rounded-row
// hover lists (no full-bleed dividers on interactive rows), 150ms colour
// transitions. No editorial hero type, no staggered entrances.
//
// Data wiring preserved EXACTLY from the Command Center:
//   - GET /api/admin/stats           → useAdminStats (realtime-lite internal)
//   - GET /api/jobs?limit=200        → useJobs (realtime-lite internal)
//   - GET /api/evaluator/queue       → per-job stage breakdown (admin allowed)
//   - useRefetchOnFocus + 30s silent poll on the queue
// ============================================================================

import { useNav } from "@/components/nav-provider";
import { useAdminStats, useJobs, isJobActive, appCount, type JobRow } from "@/lib/hooks/use-admin-data";
import { apiFetch, formatDate, fullName } from "@/lib/client";
import { humanizeTitle, humanizeName } from "@/lib/humanize";
import { StatusIndicator, EmptyState, ErrorState } from "@/components/primitives/workspace";
import { Button } from "@/components/ui/button";
import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import { useRefetchOnFocus } from "@/hooks/use-refetch-on-focus";
import { OnboardingTour } from "@/components/onboarding/onboarding-tour";
import type { TourStep } from "@/components/ui/tour";
import {
  ArrowRight,
  ArrowUpRight,
  Briefcase,
  CalendarClock,
  ClipboardCheck,
  RefreshCw,
  ShieldAlert,
  TrendingUp,
  UserX,
  ChevronRight,
  type LucideIcon,
} from "lucide-react";
import {
  PageShell,
  PageHeader,
  Panel,
  Monogram,
  initials,
} from "@/components/dash/kit";
import type { Tone } from "@/lib/status";
import { cn } from "@/lib/utils";

type QueueItem = {
  id: string;
  status: string;
  dateApplied: string;
  applicant: { id: number; firstName: string | null; lastName: string | null; emailAddress: string | null };
  job: { id: number; title: string | null; position: { positionTitle: string | null } | null } | null;
};

// Typographic middot between row vitals — quiet punctuation, no icons.
function Dot() {
  return <span aria-hidden className="select-none text-foreground/25">·</span>;
}

// ============================================================================
// Dashboard
// ============================================================================

export function Dashboard() {
  const { navigate } = useNav();
  const { stats, loading, error, reload } = useAdminStats();
  // useAdminStats + useJobs are realtime-lite internally (focus refetch +
  // 30s silent poll) — only the queue fetch below needs its own wiring.
  const { jobs, reload: reloadJobs } = useJobs();
  const [queue, setQueue] = useState<QueueItem[]>([]);

  // Initial mount load — cancel-guarded fetch (state updates only while the
  // view is still mounted). Realtime ticks go through useRefetchOnFocus.
  useEffect(() => {
    let cancelled = false;
    apiFetch<{ data: QueueItem[] } | QueueItem[]>("/api/evaluator/queue")
      .then((r) => {
        if (!cancelled) setQueue(Array.isArray(r) ? r : r.data ?? []);
      })
      .catch(() => {
        if (!cancelled) setQueue([]);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const loadQueue = useCallback(async (silent?: boolean) => {
    const isSilent = silent === true;
    try {
      const r = await apiFetch<{ data: QueueItem[] } | QueueItem[]>("/api/evaluator/queue");
      setQueue(Array.isArray(r) ? r : r.data ?? []);
    } catch {
      // Silent refresh keeps the last good queue on a transient failure;
      // manual reloads clear it (matches the original behavior).
      if (!isSilent) setQueue([]);
    }
  }, []);

  useRefetchOnFocus(() => loadQueue(true), { pollMs: 30_000 });

  // The header Refresh button refreshes EVERYTHING on the page — previously
  // it only reloaded stats, leaving jobs and the queue stale until remount.
  const reloadAll = useCallback(() => {
    reload();
    reloadJobs();
    void loadQueue();
  }, [reload, reloadJobs, loadQueue]);

  const activeJobs = jobs.filter(isJobActive);
  const attentionTotal =
    (stats?.pendingReview ?? 0) +
    (stats?.deadlinesThisWeek ?? 0) +
    (stats?.incompleteProfiles ?? 0) +
    (stats?.failedLogins24h ?? 0);

  const today = new Date().toLocaleDateString("en-PH", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  // First-visit tour script — the operations dashboard walkthrough.
  const tourSteps: TourStep[] = useMemo(
    () => [
      {
        target: "#tour-admin-welcome",
        title: "Welcome to the Recruitment Dashboard",
        description:
          "Your recruitment operations at a glance — live status, today's date, and a one-click refresh of every figure on this page.",
        placement: "bottom",
      },
      {
        target: "#tour-admin-attention",
        title: "Needs Attention",
        description:
          "Live counters for work that needs action: applications awaiting review, upcoming deadlines, incomplete applicant profiles, and security alerts. Click any card to jump straight to the surface that resolves it.",
        placement: "bottom",
      },
      {
        target: "#tour-admin-recruitment",
        title: "Active Recruitment",
        description:
          "Every currently open job posting with its application queue. Use View all to manage postings in the recruitment workspace.",
        placement: "top",
      },
      {
        target: "#tour-admin-applications",
        title: "Latest Applications",
        description:
          "The most recent applications submitted by applicants, newest first. Click a row to open the applicant's profile.",
        placement: "top",
      },
    ],
    []
  );

  return (
    <PageShell>
      {/* ===== Page header — eyebrow + title + live chip; date context below;
          Refresh flush right. ===== */}
      <div id="tour-admin-welcome">
      <PageHeader
        eyebrow="Operations"
        title="Dashboard"
        chip={
          <>
            <span aria-hidden className="relative flex size-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-success opacity-60" />
              <span className="relative inline-flex size-2 rounded-full bg-success" />
            </span>
            Live
          </>
        }
        chipTone="success"
        sub={`${today} · Recruitment operations at a glance`}
        actions={
          <Button
            variant="outline"
            size="sm"
            className="h-8 rounded-lg text-xs"
            onClick={reloadAll}
            disabled={loading}
          >
            <RefreshCw className={cn("size-3.5", loading && "animate-spin")} aria-hidden />
            Refresh
          </Button>
        }
      />
      </div>

      {error && <ErrorState message={error} onRetry={reload} />}

      {/* ===== NEEDS ATTENTION — four tone-tinted attention cards, count +
          label only (no hint sub-lines). Each is a direct jump to the
          surface that resolves the number; zero-count cards are dimmed and
          inert. ===== */}
      <section id="tour-admin-attention">
        <SectionHead
          title="Needs attention"
          right={
            <span className="text-xs font-medium tabular-nums text-muted-foreground">
              {attentionTotal} {attentionTotal === 1 ? "item" : "items"} require action
            </span>
          }
        />
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <AttentionCard
            icon={ClipboardCheck}
            tone="primary"
            count={stats?.pendingReview ?? 0}
            label="Awaiting review"
            onClick={() => navigate("review-queue")}
          />
          <AttentionCard
            icon={CalendarClock}
            tone="warning"
            count={stats?.deadlinesThisWeek ?? 0}
            label="Deadlines this week"
            hint="Job postings closing soon"
            onClick={() => navigate("recruitment")}
          />
          <AttentionCard
            icon={UserX}
            tone="neutral"
            count={stats?.incompleteProfiles ?? 0}
            label="Incomplete profiles"
            hint="Applicants who haven't finished"
            onClick={() => navigate("candidates", { status: "incomplete" })}
          />
          <AttentionCard
            icon={ShieldAlert}
            tone="danger"
            count={stats?.failedLogins24h ?? 0}
            label="Failed logins (24h)"
            onClick={() => navigate("settings", { tab: "audit" })}
          />
        </div>
      </section>

      {/* ===== ACTIVE RECRUITMENT + LATEST APPLICATIONS — the two work
          ledgers side by side (2/3 + 1/3). Both use rounded-row hover lists
          inside flush panels; the applications ledger scrolls internally so
          the page height stays predictable. ===== */}
      <section className="grid grid-cols-1 gap-4 sm:gap-5 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
        {/* Active recruitment */}
        <Panel id="tour-admin-recruitment" flush className="flex flex-col overflow-hidden">
          <div className="flex items-center justify-between gap-3 border-b border-border px-4 py-3.5 sm:px-5">
            <h2 className="text-sm font-semibold text-foreground">Active recruitment</h2>
            <div className="flex shrink-0 items-center gap-1.5">
              <span className="text-xs font-medium tabular-nums text-muted-foreground">
                {activeJobs.length} {activeJobs.length === 1 ? "process" : "processes"}
              </span>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 rounded-lg px-2 text-xs text-muted-foreground"
                onClick={() => navigate("recruitment")}
              >
                View all <ArrowRight className="size-3.5" />
              </Button>
            </div>
          </div>
          {activeJobs.length === 0 ? (
            <EmptyState
              icon={<Briefcase className="size-10" />}
              title="No active recruitment"
              description="There are no open job postings at the moment."
              action={<Button size="sm" onClick={() => navigate("recruitment")}>View all jobs</Button>}
            />
          ) : (
            <ul className="flex-1 space-y-0.5 p-1.5 sm:p-2">
              {activeJobs.slice(0, 6).map((job, i) => (
                <ActiveRecruitmentRow key={job.id} job={job} queue={queue} index={i} />
              ))}
            </ul>
          )}
        </Panel>

        {/* Latest applications — internally scrolled ledger */}
        <Panel id="tour-admin-applications" flush className="flex flex-col overflow-hidden">
          <div className="flex items-center justify-between gap-3 border-b border-border px-4 py-3.5 sm:px-5">
            <h2 className="text-sm font-semibold text-foreground">Latest applications</h2>
            <span className="shrink-0 text-xs font-medium tabular-nums text-muted-foreground">
              {stats?.recent.length ?? 0} {stats?.recent.length === 1 ? "entry" : "entries"}
            </span>
          </div>
          {stats?.recent.length === 0 ? (
            <EmptyState icon={<TrendingUp className="size-8" />} title="No recent applications" />
          ) : (
            <ul className="max-h-[420px] flex-1 space-y-0.5 overflow-y-auto p-1.5 sm:p-2">
              {stats?.recent.map((r) => (
                <ActivityRow
                  key={r.id}
                  name={r.applicant ? fullName(r.applicant) : "Unknown applicant"}
                  jobTitle={r.job?.title || "Untitled position"}
                  date={r.dateApplied}
                  status={r.status}
                  applicantId={r.applicantId}
                />
              ))}
            </ul>
          )}
        </Panel>
      </section>

      {/* ===== First-visit guided tour — once per admin, auto-opens on the
             dashboard after sign-in; any dismissal marks it as seen. ===== */}
      <OnboardingTour tourKey="admin-dashboard" steps={tourSteps} />
    </PageShell>
  );
}

// ============================================================================
// Section head — the slim grouping label above card grids
// ============================================================================

function SectionHead({ title, right }: { title: string; right?: ReactNode }) {
  return (
    <div className="mb-3 flex items-center justify-between gap-3">
      <h2 className="text-sm font-semibold text-foreground">{title}</h2>
      {right && <div className="shrink-0 text-xs text-muted-foreground">{right}</div>}
    </div>
  );
}

// ============================================================================
// AttentionCard — tone chip + count + label + hint + hover arrow
// ============================================================================

function AttentionCard({
  icon: Icon,
  tone,
  count,
  label,
  hint,
  onClick,
}: {
  icon: LucideIcon;
  tone: Tone;
  count: number;
  label: string;
  /** Optional quiet sub-line — omitted on cards whose hint would mis-frame
   * the role (kept off "Awaiting review" and "Failed logins"). */
  hint?: string;
  onClick: () => void;
}) {
  const hasItems = count > 0;
  const chip =
    tone === "neutral"
      ? "bg-muted text-muted-foreground"
      : tone === "primary"
        ? "bg-primary/10 text-primary"
        : tone === "warning"
          ? "bg-warning/10 text-warning-ink"
          : "bg-destructive/10 text-danger-ink";
  return (
    <button
      onClick={onClick}
      disabled={!hasItems}
      className={cn(
        "group flex items-start gap-3.5 rounded-[20px] border border-border/70 bg-card p-4 text-left shadow-xs transition-all duration-200 sm:p-5",
        hasItems
          ? "hover:border-foreground/25 hover:shadow-sm focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:outline-none"
          : "cursor-default opacity-60"
      )}
    >
      <span
        aria-hidden
        className={cn(
          "grid size-11 shrink-0 place-items-center rounded-xl ring-1 ring-inset ring-black/[0.04]",
          chip
        )}
      >
        <Icon className="size-5" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-2xl font-semibold leading-tight tabular-nums tracking-[-0.02em] text-foreground">
          {count}
        </span>
        <span className="mt-0.5 block truncate text-sm font-medium text-foreground">{label}</span>
        {hint && (
          <span className="mt-0.5 block truncate text-xs text-muted-foreground">{hint}</span>
        )}
      </span>
      <ArrowUpRight
        aria-hidden
        className="mt-1 size-4 shrink-0 text-muted-foreground/40 transition-colors duration-200 group-hover:text-primary"
      />
    </button>
  );
}

// ============================================================================
// Ledger rows — rounded-row hover lists (no full-bleed dividers)
// ============================================================================

// ---- Activity row (latest applications) ------------------------------------
function ActivityRow({
  name,
  jobTitle,
  date,
  status,
  applicantId,
}: {
  name: string;
  jobTitle: string;
  date: string;
  status?: string | null;
  applicantId?: number | null;
}) {
  const { navigate } = useNav();
  return (
    <li>
      <button
        onClick={() => applicantId && navigate("candidate", { id: String(applicantId) })}
        className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-colors duration-150 hover:bg-accent/60"
      >
        <Monogram label={initials(name)} size="sm" />
        <span className="min-w-0 flex-1">
          <span className="block truncate text-sm font-medium text-foreground">
            {humanizeName(name)}
          </span>
          <span className="mt-0.5 block truncate text-xs text-muted-foreground">
            {humanizeTitle(jobTitle)} <Dot /> Applied {formatDate(date)}
          </span>
        </span>
        {status && <StatusIndicator status={status} size="sm" />}
      </button>
    </li>
  );
}

// ---- Active recruitment row -------------------------------------------------
function ActiveRecruitmentRow({ job, queue, index }: { job: JobRow; queue: QueueItem[]; index: number }) {
  const { navigate } = useNav();
  const count = appCount(job) ?? 0;
  const title = job.title || job.position?.positionTitle || "Untitled Position";
  const place = job.position?.placeOfAssignment?.name;

  // Match queue items to this job to compute stage breakdown.
  // REVISED WORKFLOW: there is no evaluation stage — applications are either
  // awaiting the shortlist decision, shortlisted (email sent, face-to-face
  // next), or not qualified.
  const jobApps = queue.filter((q) => q.job?.id === job.id);
  const inReview = jobApps.filter((a) =>
    /applied|pending|screening|under review|for evaluation|evaluation|evaluated|final review/i.test(a.status)
  ).length;
  const shortlisted = jobApps.filter((a) => /shortlisted/i.test(a.status)).length;
  const rejected = jobApps.filter((a) => /rejected|declined/i.test(a.status)).length;

  return (
    <li>
      <button
        onClick={() => navigate("job", { id: String(job.id) })}
        className="flex w-full items-center gap-4 rounded-xl px-3 py-2.5 text-left transition-colors duration-150 hover:bg-accent/60"
      >
        {/* Row index — quiet, desktop only */}
        <span
          aria-hidden
          className="hidden shrink-0 text-xs tabular-nums text-muted-foreground/60 sm:inline"
        >
          {String(index + 1).padStart(2, "0")}
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="truncate text-sm font-medium text-foreground">
            {humanizeTitle(title)}
          </h3>
          <p className="mt-0.5 truncate text-xs text-muted-foreground">
            {job.positionType || "Permanent"} <Dot /> {place || "—"}
            {job.deadlineDate && (
              <>
                {" "}
                <Dot /> Closes {formatDate(job.deadlineDate)}
              </>
            )}
          </p>
        </div>
        {/* Stage breakdown — inline pipeline, plain foreground figures */}
        <div className="hidden items-center gap-5 md:flex">
          <StageMetric label="Apps" value={count} />
          <StageMetric label="Review" value={inReview} />
          <StageMetric label="Shortlist" value={shortlisted} />
          <StageMetric label="Rejected" value={rejected} />
        </div>
        <ChevronRight aria-hidden className="size-4 shrink-0 text-muted-foreground/40" />
      </button>
    </li>
  );
}

function StageMetric({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex w-16 flex-col items-center gap-1">
      <span className="text-sm font-semibold tabular-nums leading-none text-foreground">{value}</span>
      <span className="text-[11px] font-medium uppercase tracking-[0.08em] text-muted-foreground">{label}</span>
    </div>
  );
}

// ============================================================================
// Loading skeleton — mirrors the premium layout: header, attention grid,
// two flush ledger panels.
// ============================================================================

export function DashboardSkeleton() {
  return (
    <PageShell>
      {/* Header skeleton */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 space-y-2">
          <div className="h-3 w-24 animate-pulse bg-muted" />
          <div className="h-8 w-44 animate-pulse bg-muted" />
          <div className="h-4 w-72 animate-pulse bg-muted" />
        </div>
        <div className="h-8 w-24 shrink-0 animate-pulse bg-muted" />
      </div>
      {/* Needs attention */}
      <div>
        <div className="mb-3 flex items-center justify-between">
          <div className="h-4 w-28 animate-pulse bg-muted" />
          <div className="h-3 w-24 animate-pulse bg-muted" />
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="flex items-start gap-3.5 rounded-[20px] border border-border/70 bg-card p-4 shadow-xs sm:p-5">
              <div className="size-11 shrink-0 animate-pulse rounded-xl bg-muted" />
              <div className="min-w-0 flex-1 space-y-2 pt-0.5">
                <div className="h-6 w-10 animate-pulse bg-muted" />
                <div className="h-3.5 w-24 animate-pulse bg-muted" />
                <div className="h-3 w-32 animate-pulse bg-muted" />
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Two ledger panels */}
      <div className="grid grid-cols-1 gap-4 sm:gap-5 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
        {[0, 1].map((p) => (
          <div key={p} className="overflow-hidden rounded-[20px] border border-border bg-card shadow-xs">
            <div className="flex items-center justify-between border-b border-border px-4 py-3.5 sm:px-5">
              <div className="h-4 w-36 animate-pulse bg-muted" />
              <div className="h-3 w-20 animate-pulse bg-muted" />
            </div>
            <div className="space-y-1 p-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="flex items-center gap-3 rounded-xl px-3 py-2.5">
                  {p === 1 && <div className="size-9 shrink-0 animate-pulse rounded-full bg-muted" />}
                  <div className="min-w-0 flex-1 space-y-1.5">
                    <div className="h-3.5 w-44 animate-pulse bg-muted" />
                    <div className="h-3 w-64 max-w-full animate-pulse bg-muted" />
                  </div>
                  {p === 0 && <div className="hidden h-8 w-56 shrink-0 animate-pulse bg-muted md:block" />}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </PageShell>
  );
}
