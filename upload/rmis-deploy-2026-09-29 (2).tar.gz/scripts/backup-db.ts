// ============================================================================
// backup-db.ts — Safe, consistent backups of ALL RMIS SQLite databases.
//
//   bun run backup                 → ./backups/YYYYMMDD-HHMMSS/
//   BACKUP_DIR=/var/backups/rmis bun run backup
//
// Uses better-sqlite3's `serialize()` — a consistent snapshot of the database
// INCLUDING WAL content, taken under a read lock. Safe to run while the app is
// live. Plain `cp` of a WAL-mode DB can capture a torn state, so it is only
// used as a fallback when serialize is unavailable.
//
// Schedule nightly (see DEPLOYMENT.md §Backups):
//   crontab -e
//   30 2 * * * cd /opt/rmis cd /opt/rmis && ./node_modules/.bin/bun run backupcd /opt/rmis && ./node_modules/.bin/bun run backup npm run backup >> /var/log/rmis-backup.log 2>&1
//
// Retention: keeps the last BACKUP_KEEP (default 14) timestamped runs per DB.
// ============================================================================

import Database from "better-sqlite3";
import { readdirSync, mkdirSync, rmSync, existsSync, cpSync, statSync, writeFileSync } from "node:fs";
import { join, resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const dbDir = join(projectRoot, "db");
const uploadDirPath = process.env.UPLOAD_DIR || join(projectRoot, "upload");
const backupRoot = process.env.BACKUP_DIR || join(projectRoot, "backups");
const keep = Number(process.env.BACKUP_KEEP ?? "14");

/** The databases that carry real state. custom.db / rmis.db are dev scratch — skipped. */
const DB_FILES = ["production-data.db", "audit.db", "notifications.db"] as const;

const stamp = new Date().toISOString().replace(/[:T]/g, "-").slice(0, 19);
const destDir = join(backupRoot, stamp);
mkdirSync(destDir, { recursive: true });

let failures = 0;

for (const name of DB_FILES) {
  const src = join(dbDir, name);
  if (!existsSync(src)) {
    console.warn(`[backup] SKIP ${name} — not found at ${src}`);
    continue;
  }
  const dest = join(destDir, name);
  try {
    // serialize() gives a byte-for-byte consistent snapshot (read lock, WAL included).
    const srcDb = new Database(src, { readonly: true });
    const snapshot: Buffer = srcDb.serialize();
    srcDb.close();
    writeFileSync(dest, snapshot);
    const kb = Math.round(statSync(dest).size / 1024);
    console.log(`[backup] OK   ${name} → ${dest} (${kb} KB)`);
  } catch (err) {
    failures += 1;
    console.error(`[backup] FAIL ${name}:`, err);
  }
}

// Uploaded applicant documents (PDS, certificates) — plain file copy.
if (existsSync(uploadDirPath)) {
  try {
    cpSync(uploadDirPath, join(destDir, "upload"), { recursive: true });
    console.log(`[backup] OK   upload/ → ${join(destDir, "upload")}`);
  } catch (err) {
    failures += 1;
    console.error("[backup] FAIL upload/:", err);
  }
} else {
  console.warn(`[backup] SKIP upload/ — not found at ${uploadDirPath}`);
}

// Retention — prune old timestamped runs, oldest first.
try {
  const runs = readdirSync(backupRoot)
    .filter((d) => /^\d{4}-\d{2}-\d{2}/.test(d))
    .sort();
  const excess = runs.length - keep;
  for (let i = 0; i < excess; i++) {
    rmSync(join(backupRoot, runs[i]), { recursive: true, force: true });
    console.log(`[backup] pruned old run ${runs[i]}`);
  }
} catch {
  // retention is best-effort; never fail the backup for pruning
}

console.log(`[backup] done → ${destDir}`);
process.exit(failures ? 1 : 0);
